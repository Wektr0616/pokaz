﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Buro.Entity;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace Buro.Pages
{
    public partial class CandidateDashboardPage : Page
    {
        private EmploymentBureauEntities _context;
        private User _currentUser;
        private Candidate _currentCandidate;
        private string _currentView = "Dashboard";
        private int? _editingResumeId = null;
        private int? _deletingResumeId = null;
        private Vacancy _selectedVacancy = null;
        private CandidateRespons _selectedResponse = null;
        private EmployerRespons _selectedEmployerResponse = null;

        public CandidateDashboardPage()
        {
            InitializeComponent();
            _context = EmploymentBureauEntities.GetContext();
            Loaded += CandidateDashboardPage_Loaded;
        }

        private async void CandidateDashboardPage_Loaded(object sender, RoutedEventArgs e)
        {
            _currentUser = App.Current.Properties["CurrentUser"] as User;
            if (_currentUser == null)
            {
                Manager.MainFrame.Navigate(new LoginPage());
                return;
            }

            _currentCandidate = await _context.Candidates.FindAsync(_currentUser.UserID);
            if (_currentCandidate != null)
            {
                CandidateNameText.Text = _currentCandidate.FullName;
            }

            await LoadDashboardDataAsync();
        }

        #region Навигация по меню

        private async void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;

            ResetMenuStyles();

            button.Style = (Style)FindResource("MenuButtonActive");

            _currentView = button.Tag.ToString();
            await SwitchViewAsync(_currentView);
        }

        private void ResetMenuStyles()
        {
            DashboardMenu.Style = (Style)FindResource("MenuButton");
            ResumesMenu.Style = (Style)FindResource("MenuButton");
            VacanciesMenu.Style = (Style)FindResource("MenuButton");
            ResponsesMenu.Style = (Style)FindResource("MenuButton");
            ProfileMenu.Style = (Style)FindResource("MenuButton");
        }

        private async Task SwitchViewAsync(string viewName)
        {
            HideAllPanels();

            switch (viewName)
            {
                case "Dashboard":
                    DashboardPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Обзор";
                    PageSubtitle.Text = "Добро пожаловать в личный кабинет";
                    await LoadDashboardDataAsync();
                    break;

                case "Resumes":
                    ResumesPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Мои резюме";
                    PageSubtitle.Text = "Управление резюме";
                    await LoadResumesAsync();
                    break;

                case "Vacancies":
                    VacanciesPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Поиск вакансий";
                    PageSubtitle.Text = "Найдите подходящую работу";
                    await LoadVacanciesAsync();
                    break;

                case "Responses":
                    ResponsesPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Мои отклики";
                    PageSubtitle.Text = "Отслеживание статуса откликов";

                    await LoadResponsesAsync();
                    await LoadEmployerResponsesAsync();
                    break;

                case "Profile":
                    ProfilePanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Профиль";
                    PageSubtitle.Text = "Редактирование личных данных";

                    LoadProfile();
                    break;
            }
        }

        private void HideAllPanels()
        {
            DashboardPanel.Visibility = Visibility.Collapsed;
            ResumesPanel.Visibility = Visibility.Collapsed;
            VacanciesPanel.Visibility = Visibility.Collapsed;
            ResponsesPanel.Visibility = Visibility.Collapsed;
            ProfilePanel.Visibility = Visibility.Collapsed;
            EditPanel.Visibility = Visibility.Collapsed;
            ViewVacancyPanel.Visibility = Visibility.Collapsed;
            ViewResponsePanel.Visibility = Visibility.Collapsed;
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            ViewEmployerResponsePanel.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region Загрузка данных

        private async Task LoadDashboardDataAsync()
        {
            try
            {
                var resumesCount = await _context.Resumes
                    .CountAsync(r => r.CandidateID == _currentUser.UserID);
                StatResumes.Text = resumesCount.ToString();

                var responsesCount = await _context.CandidateResponses
                    .CountAsync(r => r.CandidateID == _currentUser.UserID);
                StatResponses.Text = responsesCount.ToString();

                var activeResumes = await _context.Resumes
                    .CountAsync(r => r.CandidateID == _currentUser.UserID && r.IsVisible == true && r.Status == "Активно");
                StatActiveResumes.Text = activeResumes.ToString();

                var interviewsCount = await _context.EmployerResponses
                    .CountAsync(r => r.CandidateID == _currentUser.UserID && r.Status == "Приглашен на собеседование");
                StatInterviews.Text = interviewsCount.ToString();

                var recentResponsesRaw = await _context.CandidateResponses
                    .Where(r => r.CandidateID == _currentUser.UserID)
                    .OrderByDescending(r => r.ResponseDate)
                    .Take(5)
                    .Select(r => new
                    {
                        r.ResponseID,
                        VacancyName = r.Vacancy.Position,
                        CompanyName = r.Vacancy.Employer.CompanyName,
                        r.ResponseDate,
                        r.Status
                    })
                    .ToListAsync();

                var recentResponses = recentResponsesRaw.Select(r => new MyResponseViewModel
                {
                    ResponseID = r.ResponseID,
                    VacancyName = r.VacancyName,
                    CompanyName = r.CompanyName,
                    ResponseDate = r.ResponseDate,
                    Status = r.Status,
                    StatusColor = GetStatusColor(r.Status)
                }).ToList();

                RecentResponsesGrid.ItemsSource = recentResponses;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadResumesAsync()
        {
            try
            {
                var rawResumes = await _context.Resumes
                    .Where(r => r.CandidateID == _currentUser.UserID)
                    .OrderByDescending(r => r.CreatedDate)
                    .Select(r => new
                    {
                        r.ResumeID,
                        r.Title,
                        r.Skills,
                        r.SalaryExpectation,
                        r.EmploymentType,
                        r.WorkSchedule,
                        r.IsVisible,
                        r.IsPrimary,
                        r.Status,
                        r.CreatedDate,
                        ResponsesCount = r.CandidateResponses.Count
                    })
                    .ToListAsync();

                var resumes = rawResumes.Select(r => new MyResumeViewModel
                {
                    ResumeID = r.ResumeID,
                    Title = r.Title,
                    Skills = TruncateText(r.Skills, 50),
                    SalaryExpectation = r.SalaryExpectation,
                    SalaryRange = r.SalaryExpectation.HasValue ? $"{r.SalaryExpectation.Value:N0} ₽" : "По договоренности",
                    EmploymentType = r.EmploymentType ?? "Не указан",
                    WorkSchedule = r.WorkSchedule ?? "Не указан",
                    IsVisible = r.IsVisible ?? false,
                    IsPrimary = r.IsPrimary ?? false,
                    Status = r.Status ?? "Черновик",
                    CreatedDate = r.CreatedDate ?? DateTime.Now,
                    ResponsesCount = r.ResponsesCount,
                    VisibilityText = (r.IsVisible ?? false) ? "Видимое" : "Скрыто",
                    VisibilityColor = (r.IsVisible ?? false) ? new SolidColorBrush(Colors.Green) : new SolidColorBrush(Colors.Gray),
                    PrimaryText = (r.IsPrimary ?? false) ? "Основное" : "Дополнительное",
                    PrimaryColor = (r.IsPrimary ?? false) ? new SolidColorBrush(Colors.Orange) : new SolidColorBrush(Colors.Gray)
                }).ToList();

                ResumesDataGrid.ItemsSource = resumes;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки резюме: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadVacanciesAsync()
        {
            try
            {
                var rawVacancies = await _context.Vacancies
                    .Where(v => v.IsActive == true)
                    .OrderByDescending(v => v.CreatedDate)
                    .Select(v => new
                    {
                        v.VacancyID,
                        v.Position,
                        CompanyName = v.Employer.CompanyName,
                        v.SalaryFrom,
                        v.SalaryTo,
                        v.City,
                        v.EmploymentType,
                        v.ExperienceRequired,
                        v.Description,
                        v.CreatedDate
                    })
                    .ToListAsync();

                var vacancies = rawVacancies.Select(v => new VacancySearchViewModel
                {
                    VacancyID = v.VacancyID,
                    Position = v.Position,
                    CompanyName = v.CompanyName,
                    SalaryFrom = v.SalaryFrom,
                    SalaryTo = v.SalaryTo,
                    SalaryRange = FormatSalaryRange(v.SalaryFrom, v.SalaryTo),
                    City = v.City ?? "Не указан",
                    EmploymentType = v.EmploymentType ?? "Не указан",
                    ExperienceRequired = v.ExperienceRequired,
                    ShortDescription = TruncateText(v.Description, 100),
                    CreatedDate = v.CreatedDate ?? DateTime.Now
                }).ToList();

                VacanciesDataGrid.ItemsSource = vacancies;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки вакансий: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadResponsesAsync()
        {
            try
            {
                var responsesRaw = await _context.CandidateResponses
                    .Where(r => r.CandidateID == _currentUser.UserID)
                    .OrderByDescending(r => r.ResponseDate)
                    .Select(r => new
                    {
                        r.ResponseID,
                        VacancyName = r.Vacancy.Position,
                        CompanyName = r.Vacancy.Employer.CompanyName,
                        ResumeTitle = r.Resume.Title,
                        r.ResponseDate,
                        r.Status,
                        r.EmployerComment
                    })
                    .ToListAsync();

                var responses = responsesRaw.Select(r => new MyResponseViewModel
                {
                    ResponseID = r.ResponseID,
                    VacancyName = r.VacancyName,
                    CompanyName = r.CompanyName,
                    ResumeTitle = r.ResumeTitle,
                    ResponseDate = r.ResponseDate,
                    Status = r.Status,
                    EmployerComment = r.EmployerComment,
                    StatusColor = GetStatusColor(r.Status)
                }).ToList();

                ResponsesDataGrid.ItemsSource = responses;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки откликов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadEmployerResponsesAsync()
        {
            try
            {
                var employerResponsesRaw = await _context.EmployerResponses
                    .Where(r => r.CandidateID == _currentUser.UserID)
                    .OrderByDescending(r => r.ResponseDate)
                    .Select(r => new
                    {
                        r.EmployerResponseID,
                        r.ResponseDate,
                        r.Status,
                        r.Message,
                        r.InterviewDate,
                        CompanyName = r.Employer.CompanyName,
                        VacancyName = r.Vacancy.Position,
                        ResumeTitle = r.Resume.Title
                    })
                    .ToListAsync();

                var employerResponses = employerResponsesRaw.Select(r => new EmployerResponseViewModel
                {
                    EmployerResponseID = r.EmployerResponseID,
                    ResponseDate = r.ResponseDate,
                    Status = r.Status,
                    Message = r.Message,
                    InterviewDate = r.InterviewDate,
                    CompanyName = r.CompanyName,
                    VacancyName = r.VacancyName,
                    ResumeTitle = r.ResumeTitle,
                    StatusColor = GetStatusColor(r.Status)
                }).ToList();

                EmployerResponsesDataGrid.ItemsSource = employerResponses;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки откликов работодателей: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadProfile()
        {
            try
            {
                if (_currentCandidate == null) return;

                ProfileFullName.Text = _currentCandidate.FullName;
                ProfileProfession.Text = _currentCandidate.Profession ?? "Не указана";
                ProfileExperience.Text = _currentCandidate.ExperienceYears.HasValue
                    ? $"{_currentCandidate.ExperienceYears} лет"
                    : "Не указан";
                ProfileEducation.Text = _currentCandidate.Education ?? "Не указано";
                ProfileEmail.Text = _currentUser.Email;
                ProfilePhone.Text = _currentUser.Phone;

                var resumesCount = _context.Resumes.Count(r => r.CandidateID == _currentUser.UserID);
                var activeResumes = _context.Resumes.Count(r => r.CandidateID == _currentUser.UserID && r.IsVisible == true);
                var totalResponses = _context.CandidateResponses.Count(r => r.CandidateID == _currentUser.UserID);

                ProfileResumesCount.Text = resumesCount.ToString();
                ProfileActiveResumes.Text = activeResumes.ToString();
                ProfileTotalResponses.Text = totalResponses.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки профиля: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion

        #region Вспомогательные методы

        private string TruncateText(string text, int maxLength)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Length > maxLength ? text.Substring(0, maxLength) + "..." : text;
        }

        private string FormatSalaryRange(decimal? from, decimal? to)
        {
            if (from.HasValue && to.HasValue)
                return $"{from.Value:N0} - {to.Value:N0} ₽";
            if (from.HasValue)
                return $"от {from.Value:N0} ₽";
            if (to.HasValue)
                return $"до {to.Value:N0} ₽";
            return "По договоренности";
        }

        private SolidColorBrush GetStatusColor(string status)
        {
            switch (status)
            {
                case "Новый": return new SolidColorBrush(Colors.Orange);
                case "На рассмотрении": return new SolidColorBrush(Colors.Blue);
                case "Приглашен на собеседование": return new SolidColorBrush(Colors.Green);
                case "Отклонен": return new SolidColorBrush(Colors.Red);
                case "Принят на работу": return new SolidColorBrush(Colors.DarkGreen);
                case "Отклик работодателя": return new SolidColorBrush(Colors.Purple);
                default: return new SolidColorBrush(Colors.Gray);
            }
        }

        #endregion

        #region Обработчики вакансий (поиск и отклик)

        private async void ViewVacancy_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int vacancyId = (int)button.Tag;

            _selectedVacancy = await _context.Vacancies
                .Include(v => v.Employer)
                .FirstOrDefaultAsync(v => v.VacancyID == vacancyId);

            if (_selectedVacancy == null) return;

            ViewVacancyTitle.Text = _selectedVacancy.Position;
            ViewCompanyName.Text = _selectedVacancy.Employer.CompanyName;
            ViewVacancySalary.Text = FormatSalaryRange(_selectedVacancy.SalaryFrom, _selectedVacancy.SalaryTo);
            ViewVacancyCity.Text = _selectedVacancy.City ?? "Город не указан";
            ViewVacancyEmploymentType.Text = _selectedVacancy.EmploymentType ?? "Тип занятости не указан";
            ViewVacancyExperience.Text = _selectedVacancy.ExperienceRequired.HasValue
                ? $"Требуемый опыт: {_selectedVacancy.ExperienceRequired} лет"
                : "Опыт не требуется";
            ViewVacancyDescription.Text = _selectedVacancy.Description ?? "Описание отсутствует";
            ViewVacancyRequirements.Text = _selectedVacancy.Requirements ?? "Требования не указаны";

            var myResumes = await _context.Resumes
                .Where(r => r.CandidateID == _currentUser.UserID && r.IsVisible == true)
                .Select(r => new { r.ResumeID, r.Title })
                .ToListAsync();

            ResumeForResponseCombo.ItemsSource = myResumes;
            ResumeForResponseCombo.DisplayMemberPath = "Title";
            ResumeForResponseCombo.SelectedValuePath = "ResumeID";

            if (myResumes.Any())
                ResumeForResponseCombo.SelectedIndex = 0;

            CoverLetterTextBox.Text = "";

            ViewVacancyPanel.Visibility = Visibility.Visible;
        }

        private async void SendResponse_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedVacancy == null) return;

            if (ResumeForResponseCombo.SelectedValue == null)
            {
                MessageBox.Show("Выберите резюме для отклика", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int resumeId = (int)ResumeForResponseCombo.SelectedValue;

            try
            {
                var existingResponse = await _context.CandidateResponses
                    .FirstOrDefaultAsync(r => r.CandidateID == _currentUser.UserID && r.VacancyID == _selectedVacancy.VacancyID);

                if (existingResponse != null)
                {
                    MessageBox.Show("Вы уже откликались на эту вакансию", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                var response = new CandidateRespons
                {
                    CandidateID = _currentUser.UserID,
                    VacancyID = _selectedVacancy.VacancyID,
                    ResumeID = resumeId,
                    CoverLetter = CoverLetterTextBox.Text,
                    Status = "Новый",
                    ResponseDate = DateTime.Now
                };

                _context.CandidateResponses.Add(response);
                await _context.SaveChangesAsync();

                MessageBox.Show("Отклик успешно отправлен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                CoverLetterTextBox.Clear();
                ViewVacancyPanel.Visibility = Visibility.Collapsed;
                _selectedVacancy = null;

                await LoadResponsesAsync();
                await LoadDashboardDataAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка отправки отклика: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseViewVacancy_Click(object sender, RoutedEventArgs e)
        {
            ViewVacancyPanel.Visibility = Visibility.Collapsed;
            _selectedVacancy = null;
        }

        #endregion

        #region Обработчики моих откликов на вакансии

        private void ViewResponse_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int responseId = (int)button.Tag;

            var response = _context.CandidateResponses
                .Include(r => r.Vacancy)
                .Include(r => r.Vacancy.Employer)
                .Include(r => r.Resume)
                .FirstOrDefault(r => r.ResponseID == responseId);

            if (response == null) return;

            _selectedResponse = response;

            ViewResponseVacancyName.Text = response.Vacancy.Position;
            ViewResponseCompanyName.Text = response.Vacancy.Employer.CompanyName;
            ViewResponseResumeTitle.Text = response.Resume.Title;
            ViewResponseDate.Text = response.ResponseDate?.ToString("dd.MM.yyyy HH:mm") ?? "-";
            ViewResponseStatus.Text = response.Status;
            ViewResponseStatus.Foreground = GetStatusColor(response.Status);
            ViewResponseComment.Text = response.EmployerComment ?? "Комментарий отсутствует";

            ViewResponsePanel.Visibility = Visibility.Visible;
        }

        private void CloseViewResponse_Click(object sender, RoutedEventArgs e)
        {
            ViewResponsePanel.Visibility = Visibility.Collapsed;
            _selectedResponse = null;
        }

        #endregion

        #region Обработчики откликов работодателей на мои резюме

        private void ViewEmployerResponse_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int employerResponseId = (int)button.Tag;

            var response = _context.EmployerResponses
                .Include(r => r.Employer)
                .Include(r => r.Vacancy)
                .Include(r => r.Resume)
                .FirstOrDefault(r => r.EmployerResponseID == employerResponseId);

            if (response == null) return;

            _selectedEmployerResponse = response;

            ViewEmployerResponseCompanyName.Text = response.Employer.CompanyName;
            ViewEmployerResponseVacancyName.Text = response.Vacancy?.Position ?? "Вакансия не указана";
            ViewEmployerResponseResumeTitle.Text = response.Resume?.Title ?? "Резюме не указано";
            ViewEmployerResponseDate.Text = response.ResponseDate?.ToString("dd.MM.yyyy HH:mm") ?? "-";
            ViewEmployerResponseStatus.Text = response.Status;
            ViewEmployerResponseStatus.Foreground = GetStatusColor(response.Status);

            if (response.InterviewDate.HasValue)
            {
                ViewEmployerResponseInterviewDate.Text = response.InterviewDate.Value.ToString("dd.MM.yyyy HH:mm");
                ViewEmployerResponseInterviewPanel.Visibility = Visibility.Visible;
            }
            else
            {
                ViewEmployerResponseInterviewPanel.Visibility = Visibility.Collapsed;
            }

            ViewEmployerResponseMessage.Text = string.IsNullOrEmpty(response.Message)
                ? "Сообщение от работодателя отсутствует"
                : response.Message;

            ViewEmployerResponsePanel.Visibility = Visibility.Visible;
        }

        private void CloseViewEmployerResponse_Click(object sender, RoutedEventArgs e)
        {
            ViewEmployerResponsePanel.Visibility = Visibility.Collapsed;
            _selectedEmployerResponse = null;
        }

        #endregion

        #region CRUD операции с резюме

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            _editingResumeId = null;
            EditPanelTitle.Text = "Новое резюме";
            ClearEditForm();
            ShowEditPanel();
        }

        private void EditResume_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;

            int resumeId = (int)button.Tag;
            _editingResumeId = resumeId;
            EditPanelTitle.Text = "Редактирование резюме";
            LoadResumeForEdit(resumeId);
            ShowEditPanel();
        }

        private async void LoadResumeForEdit(int resumeId)
        {
            try
            {
                var resume = await _context.Resumes.FindAsync(resumeId);
                if (resume == null) return;

                TitleTextBox.Text = resume.Title;
                SkillsTextBox.Text = resume.Skills ?? "";
                SalaryTextBox.Text = resume.SalaryExpectation?.ToString() ?? "";

                foreach (ComboBoxItem item in EmploymentTypeCombo.Items)
                {
                    if (item.Content.ToString() == resume.EmploymentType)
                    {
                        EmploymentTypeCombo.SelectedItem = item;
                        break;
                    }
                }

                foreach (ComboBoxItem item in ScheduleCombo.Items)
                {
                    if (item.Content.ToString() == resume.WorkSchedule)
                    {
                        ScheduleCombo.SelectedItem = item;
                        break;
                    }
                }

                IsVisibleCheckBox.IsChecked = resume.IsVisible ?? true;
                IsPrimaryCheckBox.IsChecked = resume.IsPrimary ?? false;
                ResumeTextBox.Text = resume.ResumeText ?? "";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки резюме: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void SaveResume_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TitleTextBox.Text))
            {
                MessageBox.Show("Укажите название резюме", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                Resume resume;

                if (_editingResumeId.HasValue)
                {
                    resume = await _context.Resumes.FindAsync(_editingResumeId.Value);
                    if (resume == null)
                    {
                        MessageBox.Show("Резюме не найдено", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else
                {
                    resume = new Resume
                    {
                        CandidateID = _currentUser.UserID,
                        CreatedDate = DateTime.Now,
                        Status = "Активно"
                    };
                    _context.Resumes.Add(resume);
                }

                resume.Title = TitleTextBox.Text.Trim();
                resume.ResumeText = string.IsNullOrWhiteSpace(ResumeTextBox.Text) ? "" : ResumeTextBox.Text.Trim();
                resume.Skills = string.IsNullOrWhiteSpace(SkillsTextBox.Text) ? null : SkillsTextBox.Text.Trim();
                resume.EmploymentType = (EmploymentTypeCombo.SelectedItem as ComboBoxItem)?.Content.ToString();
                resume.WorkSchedule = (ScheduleCombo.SelectedItem as ComboBoxItem)?.Content.ToString();
                resume.IsVisible = IsVisibleCheckBox.IsChecked ?? true;
                resume.IsPrimary = IsPrimaryCheckBox.IsChecked ?? false;
                resume.UpdatedDate = DateTime.Now;

                if (decimal.TryParse(SalaryTextBox.Text, out decimal salary))
                    resume.SalaryExpectation = salary;
                else
                    resume.SalaryExpectation = null;

                if (resume.IsPrimary == true)
                {
                    var otherResumes = await _context.Resumes
                        .Where(r => r.CandidateID == _currentUser.UserID && r.ResumeID != resume.ResumeID)
                        .ToListAsync();

                    foreach (var r in otherResumes)
                    {
                        r.IsPrimary = false;
                    }
                }

                await _context.SaveChangesAsync();

                MessageBox.Show(_editingResumeId.HasValue ? "Резюме обновлено" : "Резюме создано",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                HideEditPanel();
                await LoadResumesAsync();
                await LoadDashboardDataAsync();
            }
            catch (DbEntityValidationException ex)
            {
                var errorMessages = ex.EntityValidationErrors
                    .SelectMany(x => x.ValidationErrors)
                    .Select(x => $"{x.PropertyName}: {x.ErrorMessage}");

                string fullError = string.Join("\n", errorMessages);
                MessageBox.Show($"Ошибка валидации данных:\n{fullError}", "Ошибка сохранения",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteResume_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;

            _deletingResumeId = (int)button.Tag;
            var resume = _context.Resumes.Find(_deletingResumeId.Value);
            DeleteConfirmText.Text = $"Вы уверены, что хотите удалить резюме \"{resume?.Title}\"?";
            DeleteConfirmPanel.Visibility = Visibility.Visible;
        }

        private async void ConfirmDelete_Click(object sender, RoutedEventArgs e)
        {
            if (!_deletingResumeId.HasValue) return;

            try
            {
                var resume = await _context.Resumes.FindAsync(_deletingResumeId.Value);
                if (resume != null)
                {
                    _context.Resumes.Remove(resume);
                    await _context.SaveChangesAsync();
                    MessageBox.Show("Резюме удалено", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    await LoadResumesAsync();
                    await LoadDashboardDataAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                _deletingResumeId = null;
                DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            }
        }

        private void CancelDelete_Click(object sender, RoutedEventArgs e)
        {
            _deletingResumeId = null;
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region Обработчики профиля

        private void EditProfile_Click(object sender, RoutedEventArgs e)
        {
            ProfileViewPanel.Visibility = Visibility.Collapsed;
            ProfileEditPanel.Visibility = Visibility.Visible;

            EditFullName.Text = _currentCandidate.FullName;
            EditProfession.Text = _currentCandidate.Profession ?? "";
            EditExperience.Text = _currentCandidate.ExperienceYears?.ToString() ?? "";
            EditEducation.Text = _currentCandidate.Education ?? "";
        }

        private void CancelProfileEdit_Click(object sender, RoutedEventArgs e)
        {
            ProfileViewPanel.Visibility = Visibility.Visible;
            ProfileEditPanel.Visibility = Visibility.Collapsed;
        }

        private async void SaveProfile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _currentCandidate.FullName = EditFullName.Text.Trim();
                _currentCandidate.Profession = string.IsNullOrWhiteSpace(EditProfession.Text) ? null : EditProfession.Text.Trim();
                _currentCandidate.Education = string.IsNullOrWhiteSpace(EditEducation.Text) ? null : EditEducation.Text.Trim();
                _currentCandidate.UpdatedDate = DateTime.Now;

                if (int.TryParse(EditExperience.Text, out int experience))
                    _currentCandidate.ExperienceYears = experience;
                else
                    _currentCandidate.ExperienceYears = null;

                await _context.SaveChangesAsync();

                CandidateNameText.Text = _currentCandidate.FullName;
                LoadProfile();

                ProfileViewPanel.Visibility = Visibility.Visible;
                ProfileEditPanel.Visibility = Visibility.Collapsed;

                MessageBox.Show("Профиль обновлен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения профиля: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion

        #region Вспомогательные методы UI

        private void ClearEditForm()
        {
            TitleTextBox.Text = "";
            SkillsTextBox.Text = "";
            SalaryTextBox.Text = "";
            ResumeTextBox.Text = "";
            IsVisibleCheckBox.IsChecked = true;
            IsPrimaryCheckBox.IsChecked = false;
            EmploymentTypeCombo.SelectedIndex = 0;
            ScheduleCombo.SelectedIndex = 0;
        }

        private void ShowEditPanel()
        {
            EditPanel.Visibility = Visibility.Visible;
            var slideAnimation = new ThicknessAnimation
            {
                From = new Thickness(600, 20, 20, 20),
                To = new Thickness(20, 20, 20, 20),
                Duration = TimeSpan.FromMilliseconds(300),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };
            EditPanel.BeginAnimation(MarginProperty, slideAnimation);
        }

        private void HideEditPanel()
        {
            EditPanel.Visibility = Visibility.Collapsed;
            _editingResumeId = null;
        }

        private void CancelEdit_Click(object sender, RoutedEventArgs e)
        {
            HideEditPanel();
        }

        private async void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            switch (_currentView)
            {
                case "Dashboard":
                    await LoadDashboardDataAsync();
                    break;
                case "Resumes":
                    await LoadResumesAsync();
                    break;
                case "Vacancies":
                    await LoadVacanciesAsync();
                    break;
                case "Responses":
                    await LoadResponsesAsync();
                    await LoadEmployerResponsesAsync();
                    break;
                case "Profile":
                    LoadProfile();
                    break;
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Поиск: {SearchTextBox.Text}", "Поиск", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Properties["CurrentUser"] = null;
            Manager.MainFrame.Navigate(new LoginPage());
        }

        #endregion

        #region Метод для открытия вакансии после авторизации

        /// <summary>
        /// Показывает детали вакансии для соискателя после входа
        /// </summary>
        public async void ShowVacancyDetails(int vacancyId)
        {
            try
            {
                // Переключаемся на вкладку вакансий
                ResetMenuStyles();
                VacanciesMenu.Style = (Style)FindResource("MenuButtonActive");
                _currentView = "Vacancies";

                DashboardPanel.Visibility = Visibility.Collapsed;
                ResumesPanel.Visibility = Visibility.Collapsed;
                ResponsesPanel.Visibility = Visibility.Collapsed;
                ProfilePanel.Visibility = Visibility.Collapsed;
                VacanciesPanel.Visibility = Visibility.Visible;

                PageTitle.Text = "Поиск вакансий";
                PageSubtitle.Text = "Найдите подходящую работу";

                await LoadVacanciesAsync();

                // Небольшая задержка для загрузки данных
                await Task.Delay(300);

                // Находим вакансию в списке
                var vacanciesList = VacanciesDataGrid.ItemsSource as List<VacancySearchViewModel>;
                var vacancy = vacanciesList?.FirstOrDefault(v => v.VacancyID == vacancyId);

                if (vacancy != null)
                {
                    // Открываем детали вакансии
                    var vacancyEntity = await _context.Vacancies
                        .Include(v => v.Employer)
                        .FirstOrDefaultAsync(v => v.VacancyID == vacancyId);

                    if (vacancyEntity != null)
                    {
                        _selectedVacancy = vacancyEntity;

                        ViewVacancyTitle.Text = vacancyEntity.Position;
                        ViewCompanyName.Text = vacancyEntity.Employer.CompanyName;
                        ViewVacancySalary.Text = FormatSalaryRange(vacancyEntity.SalaryFrom, vacancyEntity.SalaryTo);
                        ViewVacancyCity.Text = vacancyEntity.City ?? "Город не указан";
                        ViewVacancyEmploymentType.Text = vacancyEntity.EmploymentType ?? "Тип занятости не указан";
                        ViewVacancyExperience.Text = vacancyEntity.ExperienceRequired.HasValue
                            ? $"Требуемый опыт: {vacancyEntity.ExperienceRequired} лет"
                            : "Опыт не требуется";
                        ViewVacancyDescription.Text = vacancyEntity.Description ?? "Описание отсутствует";
                        ViewVacancyRequirements.Text = vacancyEntity.Requirements ?? "Требования не указаны";

                        var myResumes = await _context.Resumes
                            .Where(r => r.CandidateID == _currentUser.UserID && r.IsVisible == true)
                            .Select(r => new { r.ResumeID, r.Title })
                            .ToListAsync();

                        ResumeForResponseCombo.ItemsSource = myResumes;
                        ResumeForResponseCombo.DisplayMemberPath = "Title";
                        ResumeForResponseCombo.SelectedValuePath = "ResumeID";

                        if (myResumes.Any())
                            ResumeForResponseCombo.SelectedIndex = 0;

                        CoverLetterTextBox.Text = "";

                        ViewVacancyPanel.Visibility = Visibility.Visible;
                    }
                }
                else
                {
                    MessageBox.Show("Вакансия не найдена", "Информация",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии вакансии: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion
    }

    // ViewModels
    public class MyResumeViewModel
    {
        public int ResumeID { get; set; }
        public string Title { get; set; }
        public string Skills { get; set; }
        public decimal? SalaryExpectation { get; set; }
        public string SalaryRange { get; set; }
        public string EmploymentType { get; set; }
        public string WorkSchedule { get; set; }
        public bool IsVisible { get; set; }
        public bool IsPrimary { get; set; }
        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public int ResponsesCount { get; set; }
        public string VisibilityText { get; set; }
        public SolidColorBrush VisibilityColor { get; set; }
        public string PrimaryText { get; set; }
        public SolidColorBrush PrimaryColor { get; set; }
    }

    public class MyResponseViewModel
    {
        public int ResponseID { get; set; }
        public string VacancyName { get; set; }
        public string CompanyName { get; set; }
        public string ResumeTitle { get; set; }
        public DateTime? ResponseDate { get; set; }
        public string Status { get; set; }
        public string EmployerComment { get; set; }
        public SolidColorBrush StatusColor { get; set; }
    }

    public class EmployerResponseViewModel
    {
        public int EmployerResponseID { get; set; }
        public DateTime? ResponseDate { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public DateTime? InterviewDate { get; set; }
        public string CompanyName { get; set; }
        public string VacancyName { get; set; }
        public string ResumeTitle { get; set; }
        public SolidColorBrush StatusColor { get; set; }

        public string InterviewDateText => InterviewDate?.ToString("dd.MM.yyyy HH:mm") ?? "Не назначено";
    }

    public class VacancySearchViewModel
    {
        public int VacancyID { get; set; }
        public string Position { get; set; }
        public string CompanyName { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
        public string SalaryRange { get; set; }
        public string City { get; set; }
        public string EmploymentType { get; set; }
        public int? ExperienceRequired { get; set; }
        public string ShortDescription { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Employer
{
    /// <summary>
    /// Логика взаимодействия для CandidateResponsesPage.xaml
    /// </summary>
    public partial class CandidateResponsesPage : Page
    {
        public CandidateResponsesPage()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            var filters = new List<string>
            {
                "Все отклики",
                "Новые",
                "Просмотренные",
                "Принятые",
                "Отклоненные",
                "По вакансиям"
            };

            FilterComboBox.ItemsSource = filters;
            FilterComboBox.SelectedIndex = 0;
        }

        private void ViewResumeButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет просмотр резюме кандидата",
                          "Резюме кандидата",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Принять этого кандидата?\n\n" +
                                       "Кандидат получит уведомление о приглашении на собеседование.",
                                       "Принятие кандидата",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Кандидат принят! Отправлено приглашение на собеседование.",
                              "Кандидат принят",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Отклонить этого кандидата?\n\n" +
                                       "Кандидат получит уведомление об отказе.",
                                       "Отклонение кандидата",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Кандидат отклонен. Отправлено уведомление об отказе.",
                              "Кандидат отклонен",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void MessageButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет окно для переписки с кандидатом",
                          "Переписка",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }
    }
}

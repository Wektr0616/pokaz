﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Buro.Entity;
using System.Data.Entity;

namespace Buro.Pages
{
    public partial class RegisterPage : Page
    {
        private EmploymentBureauEntities _context;
        private string _selectedType = null;

        // Ожидающие элементы для передачи после регистрации
        private int? _pendingVacancyId = null;
        private int? _pendingResumeId = null;

        public RegisterPage()
        {
            InitializeComponent();
            _context = EmploymentBureauEntities.GetContext();
            Loaded += RegisterPage_Loaded;
        }

        // Методы для установки ожидающих элементов из MainPage
        public void SetPendingVacancyId(int vacancyId)
        {
            _pendingVacancyId = vacancyId;
        }

        public void SetPendingResumeId(int resumeId)
        {
            _pendingResumeId = resumeId;
        }

        private void RegisterPage_Loaded(object sender, RoutedEventArgs e)
        {
            // Простая анимация без сложных easing
            var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(400));
            RegisterForm.BeginAnimation(OpacityProperty, fadeIn);
        }

        // Выбор типа пользователя
        private void CandidateButton_Click(object sender, RoutedEventArgs e)
        {
            _selectedType = "Candidate";

            // Сброс стилей
            ResetTypeButtonsStyles();

            CandidateButton.Style = (Style)FindResource("ActiveFilterButton");
            EmployerButton.Style = (Style)FindResource("FilterButton");

            TypeIndicator.Visibility = Visibility.Visible;
            TypeText.Text = "✓ Выбран тип: Соискатель";
            TypeText.Foreground = new SolidColorBrush(Color.FromRgb(39, 174, 96));

            CandidateFields.Visibility = Visibility.Visible;
            EmployerFields.Visibility = Visibility.Collapsed;

            HideError();
        }

        private void EmployerButton_Click(object sender, RoutedEventArgs e)
        {
            _selectedType = "Employer";

            // Сброс стилей
            ResetTypeButtonsStyles();

            EmployerButton.Style = (Style)FindResource("ActiveFilterButton");
            CandidateButton.Style = (Style)FindResource("FilterButton");

            TypeIndicator.Visibility = Visibility.Visible;
            TypeText.Text = "✓ Выбран тип: Работодатель";
            TypeText.Foreground = new SolidColorBrush(Color.FromRgb(230, 126, 34));

            EmployerFields.Visibility = Visibility.Visible;
            CandidateFields.Visibility = Visibility.Collapsed;

            HideError();
        }

        private void ResetTypeButtonsStyles()
        {
            CandidateButton.Style = (Style)FindResource("FilterButton");
            EmployerButton.Style = (Style)FindResource("FilterButton");
        }

        // Обработчики фокуса
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb != null)
            {
                HidePlaceholder(tb);
                HideError();
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb != null && string.IsNullOrWhiteSpace(tb.Text))
            {
                ShowPlaceholder(tb);
            }
        }

        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordBox pb = sender as PasswordBox;
            if (pb != null)
            {
                HidePasswordPlaceholder(pb);
                HideError();
            }
        }

        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            PasswordBox pb = sender as PasswordBox;
            if (pb != null && string.IsNullOrWhiteSpace(pb.Password))
            {
                ShowPasswordPlaceholder(pb);
            }
        }

        private void HidePlaceholder(TextBox textBox)
        {
            if (textBox == EmailTextBox) EmailPlaceholder.Visibility = Visibility.Collapsed;
            else if (textBox == PhoneTextBox) PhonePlaceholder.Visibility = Visibility.Collapsed;
            else if (textBox == FullNameTextBox) FullNamePlaceholder.Visibility = Visibility.Collapsed;
            else if (textBox == ProfessionTextBox) ProfessionPlaceholder.Visibility = Visibility.Collapsed;
            else if (textBox == EducationTextBox) EducationPlaceholder.Visibility = Visibility.Collapsed;
            else if (textBox == CompanyNameTextBox) CompanyNamePlaceholder.Visibility = Visibility.Collapsed;
            else if (textBox == ContactPersonTextBox) ContactPersonPlaceholder.Visibility = Visibility.Collapsed;
            else if (textBox == IndustryTextBox) IndustryPlaceholder.Visibility = Visibility.Collapsed;
        }

        private void ShowPlaceholder(TextBox textBox)
        {
            if (textBox == EmailTextBox) EmailPlaceholder.Visibility = Visibility.Visible;
            else if (textBox == PhoneTextBox) PhonePlaceholder.Visibility = Visibility.Visible;
            else if (textBox == FullNameTextBox) FullNamePlaceholder.Visibility = Visibility.Visible;
            else if (textBox == ProfessionTextBox) ProfessionPlaceholder.Visibility = Visibility.Visible;
            else if (textBox == EducationTextBox) EducationPlaceholder.Visibility = Visibility.Visible;
            else if (textBox == CompanyNameTextBox) CompanyNamePlaceholder.Visibility = Visibility.Visible;
            else if (textBox == ContactPersonTextBox) ContactPersonPlaceholder.Visibility = Visibility.Visible;
            else if (textBox == IndustryTextBox) IndustryPlaceholder.Visibility = Visibility.Visible;
        }

        private void HidePasswordPlaceholder(PasswordBox passwordBox)
        {
            if (passwordBox == PasswordBox) PasswordPlaceholder.Visibility = Visibility.Collapsed;
            else if (passwordBox == ConfirmPasswordBox) ConfirmPasswordPlaceholder.Visibility = Visibility.Collapsed;
        }

        private void ShowPasswordPlaceholder(PasswordBox passwordBox)
        {
            if (passwordBox == PasswordBox) PasswordPlaceholder.Visibility = Visibility.Visible;
            else if (passwordBox == ConfirmPasswordBox) ConfirmPasswordPlaceholder.Visibility = Visibility.Visible;
        }

        // Валидация
        private void ValidateEmail(object sender, TextChangedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(email))
            {
                EmailError.Text = "Email обязателен";
                EmailError.Visibility = Visibility.Visible;
            }
            else if (!IsValidEmail(email))
            {
                EmailError.Text = "Некорректный формат email";
                EmailError.Visibility = Visibility.Visible;
            }
            else
            {
                EmailError.Visibility = Visibility.Collapsed;
            }
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void ValidatePassword(object sender, RoutedEventArgs e)
        {
            string password = PasswordBox.Password;
            if (string.IsNullOrWhiteSpace(password))
            {
                PasswordError.Text = "Пароль обязателен";
                PasswordError.Visibility = Visibility.Visible;
            }
            else if (password.Length < 6)
            {
                PasswordError.Text = "Минимум 6 символов";
                PasswordError.Visibility = Visibility.Visible;
            }
            else
            {
                PasswordError.Visibility = Visibility.Collapsed;
            }
            ValidateConfirmPassword(null, null);
        }

        private void ValidateConfirmPassword(object sender, RoutedEventArgs e)
        {
            string confirm = ConfirmPasswordBox.Password;
            string password = PasswordBox.Password;

            if (!string.IsNullOrWhiteSpace(confirm) && confirm != password)
            {
                ConfirmPasswordError.Text = "Пароли не совпадают";
                ConfirmPasswordError.Visibility = Visibility.Visible;
            }
            else
            {
                ConfirmPasswordError.Visibility = Visibility.Collapsed;
            }
        }

        // Только цифры
        private void NumberOnly_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void ShowError(string message)
        {
            ErrorMessage.Text = message;
            ErrorBorder.Visibility = Visibility.Visible;
            SuccessBorder.Visibility = Visibility.Collapsed;
        }

        private void HideError()
        {
            ErrorBorder.Visibility = Visibility.Collapsed;
        }

        private void ShowSuccess(string message)
        {
            SuccessMessage.Text = message;
            SuccessBorder.Visibility = Visibility.Visible;
            ErrorBorder.Visibility = Visibility.Collapsed;
        }

        // Регистрация с авто-входом
        private async void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка выбора типа
            if (_selectedType == null)
            {
                ShowError("Пожалуйста, выберите тип аккаунта (Соискатель или Работодатель)");
                return;
            }

            // Валидация общих полей
            if (!ValidateAllFields()) return;

            // Проверка согласия
            if (AgreementCheckBox.IsChecked != true)
            {
                ShowError("Необходимо принять условия использования");
                return;
            }

            // Показываем загрузку
            RegisterButton.IsEnabled = false;
            RegisterButton.Content = "Регистрация...";
            LoadingIndicator.Visibility = Visibility.Visible;
            HideError();

            try
            {
                // Проверка уникальности email
                string email = EmailTextBox.Text.Trim();
                var existingUser = _context.Users.FirstOrDefault(u => u.Email == email);
                if (existingUser != null)
                {
                    ShowError("Пользователь с таким email уже существует");
                    EmailTextBox.Focus();
                    return;
                }

                string passwordHash = PasswordBox.Password;
                string phone = PhoneTextBox.Text.Trim();

                User newUser = null;

                if (_selectedType == "Candidate")
                {
                    // Регистрация соискателя
                    var candidate = new Candidate
                    {
                        CandidateID = 0,
                        FullName = FullNameTextBox.Text.Trim(),
                        Profession = string.IsNullOrWhiteSpace(ProfessionTextBox.Text) ? null : ProfessionTextBox.Text.Trim(),
                        ExperienceYears = string.IsNullOrWhiteSpace(ExperienceTextBox.Text) ? (int?)null : int.Parse(ExperienceTextBox.Text),
                        Education = string.IsNullOrWhiteSpace(EducationTextBox.Text) ? null : EducationTextBox.Text.Trim(),
                        CreatedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };

                    // Создаем пользователя
                    newUser = new User
                    {
                        RoleID = 2,
                        Email = email,
                        Phone = phone,
                        PasswordHash = passwordHash,
                        RegistrationDate = DateTime.Now,
                        IsActive = true
                    };

                    _context.Users.Add(newUser);
                    await _context.SaveChangesAsync();

                    candidate.CandidateID = newUser.UserID;
                    _context.Candidates.Add(candidate);
                    await _context.SaveChangesAsync();

                    ShowSuccess("Регистрация соискателя успешно завершена!");
                }
                else
                {
                    // Регистрация работодателя
                    var employer = new Employer
                    {
                        EmployerID = 0,
                        CompanyName = CompanyNameTextBox.Text.Trim(),
                        INN = INNTextBox.Text.Trim(),
                        ContactPerson = string.IsNullOrWhiteSpace(ContactPersonTextBox.Text) ? null : ContactPersonTextBox.Text.Trim(),
                        Industry = string.IsNullOrWhiteSpace(IndustryTextBox.Text) ? null : IndustryTextBox.Text.Trim(),
                        CompanyDescription = null,
                        CreatedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    };

                    // Создаем пользователя
                    newUser = new User
                    {
                        RoleID = 3,
                        Email = email,
                        Phone = phone,
                        PasswordHash = passwordHash,
                        RegistrationDate = DateTime.Now,
                        IsActive = true
                    };

                    _context.Users.Add(newUser);
                    await _context.SaveChangesAsync();

                    employer.EmployerID = newUser.UserID;
                    _context.Employers.Add(employer);
                    await _context.SaveChangesAsync();

                    ShowSuccess("Регистрация работодателя успешно завершена!");
                }

                // Автоматический вход после регистрации
                await AutoLoginAndNavigate(newUser);
            }
            catch (SqlException sqlEx)
            {
                ShowError("Ошибка базы данных: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                ShowError("Ошибка: " + ex.Message);
            }
            finally
            {
                RegisterButton.IsEnabled = true;
                RegisterButton.Content = "Зарегистрироваться";
                LoadingIndicator.Visibility = Visibility.Collapsed;
            }
        }

        private async System.Threading.Tasks.Task AutoLoginAndNavigate(User user)
        {
            try
            {
                // Загружаем пользователя с ролью
                var loggedUser = await _context.Users
                    .Include(u => u.Role)
                    .FirstOrDefaultAsync(u => u.UserID == user.UserID);

                if (loggedUser == null)
                {
                    ShowError("Ошибка автоматического входа");
                    return;
                }

                // Сохраняем пользователя
                App.Current.Properties["CurrentUser"] = loggedUser;

                string roleName = loggedUser.Role?.RoleName?.Trim();

                // Проверяем, есть ли ожидающие элементы
                bool hasPendingVacancy = _pendingVacancyId.HasValue;
                bool hasPendingResume = _pendingResumeId.HasValue;

                // Очищаем историю навигации
                while (Manager.MainFrame.CanGoBack)
                {
                    Manager.MainFrame.RemoveBackEntry();
                }

                // Перенаправление в зависимости от роли
                if (roleName == "Candidate")
                {
                    var candidatePage = new CandidateDashboardPage();

                    if (hasPendingVacancy && _pendingVacancyId.HasValue)
                    {
                        Manager.MainFrame.Navigate(candidatePage);
                        await System.Threading.Tasks.Task.Delay(300);
                        candidatePage.ShowVacancyDetails(_pendingVacancyId.Value);
                        _pendingVacancyId = null;
                    }
                    else
                    {
                        Manager.MainFrame.Navigate(candidatePage);
                    }
                }
                else if (roleName == "Employer")
                {
                    var employerPage = new EmployerDashboardPage();

                    if (hasPendingResume && _pendingResumeId.HasValue)
                    {
                        Manager.MainFrame.Navigate(employerPage);
                        await System.Threading.Tasks.Task.Delay(300);
                        employerPage.ShowResumeDetails(_pendingResumeId.Value);
                        _pendingResumeId = null;
                    }
                    else
                    {
                        Manager.MainFrame.Navigate(employerPage);
                    }
                }
                else if (roleName == "Admin")
                {
                    Manager.MainFrame.Navigate(new AdminDashboardPage());
                }
                else
                {
                    Manager.MainFrame.Navigate(new MainPage());
                }
            }
            catch (Exception ex)
            {
                ShowError("Ошибка автоматического входа: " + ex.Message);
                Manager.MainFrame.Navigate(new LoginPage());
            }
        }

        private bool ValidateAllFields()
        {
            bool isValid = true;

            // Email
            if (string.IsNullOrWhiteSpace(EmailTextBox.Text) || EmailError.Visibility == Visibility.Visible)
                isValid = false;

            // Телефон
            if (string.IsNullOrWhiteSpace(PhoneTextBox.Text))
            {
                PhoneError.Text = "Телефон обязателен";
                PhoneError.Visibility = Visibility.Visible;
                isValid = false;
            }
            else
            {
                PhoneError.Visibility = Visibility.Collapsed;
            }

            // Пароль
            if (string.IsNullOrWhiteSpace(PasswordBox.Password) || PasswordError.Visibility == Visibility.Visible)
                isValid = false;

            // Подтверждение пароля
            if (PasswordBox.Password != ConfirmPasswordBox.Password)
            {
                ConfirmPasswordError.Text = "Пароли не совпадают";
                ConfirmPasswordError.Visibility = Visibility.Visible;
                isValid = false;
            }

            // Специфичные поля
            if (_selectedType == "Candidate")
            {
                if (string.IsNullOrWhiteSpace(FullNameTextBox.Text))
                {
                    FullNameError.Text = "ФИО обязательно";
                    FullNameError.Visibility = Visibility.Visible;
                    isValid = false;
                }
                else
                {
                    FullNameError.Visibility = Visibility.Collapsed;
                }
            }
            else if (_selectedType == "Employer")
            {
                if (string.IsNullOrWhiteSpace(CompanyNameTextBox.Text))
                {
                    CompanyNameError.Text = "Название компании обязательно";
                    CompanyNameError.Visibility = Visibility.Visible;
                    isValid = false;
                }
                else
                {
                    CompanyNameError.Visibility = Visibility.Collapsed;
                }

                if (string.IsNullOrWhiteSpace(INNTextBox.Text) || (INNTextBox.Text.Length != 10 && INNTextBox.Text.Length != 12))
                {
                    INNError.Text = "ИНН должен содержать 10 или 12 цифр";
                    INNError.Visibility = Visibility.Visible;
                    isValid = false;
                }
                else
                {
                    INNError.Visibility = Visibility.Collapsed;
                }
            }

            return isValid;
        }

        private void ClearForm()
        {
            EmailTextBox.Clear();
            PhoneTextBox.Clear();
            PasswordBox.Clear();
            ConfirmPasswordBox.Clear();
            FullNameTextBox.Clear();
            ProfessionTextBox.Clear();
            ExperienceTextBox.Clear();
            EducationTextBox.Clear();
            CompanyNameTextBox.Clear();
            INNTextBox.Clear();
            ContactPersonTextBox.Clear();
            IndustryTextBox.Clear();
            AgreementCheckBox.IsChecked = false;

            // Сброс выбора типа
            _selectedType = null;
            ResetTypeButtonsStyles();
            TypeIndicator.Visibility = Visibility.Collapsed;
            CandidateFields.Visibility = Visibility.Collapsed;
            EmployerFields.Visibility = Visibility.Collapsed;

            // Восстановление placeholder'ов
            EmailPlaceholder.Visibility = Visibility.Visible;
            PhonePlaceholder.Visibility = Visibility.Visible;
            PasswordPlaceholder.Visibility = Visibility.Visible;
            ConfirmPasswordPlaceholder.Visibility = Visibility.Visible;
            FullNamePlaceholder.Visibility = Visibility.Visible;
            CompanyNamePlaceholder.Visibility = Visibility.Visible;
        }

        // Навигация
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            // При переходе на страницу входа сохраняем ожидающие элементы
            if (_pendingVacancyId.HasValue)
            {
                App.Current.Properties["PendingVacancyId"] = _pendingVacancyId.Value;
                _pendingVacancyId = null;
            }
            if (_pendingResumeId.HasValue)
            {
                App.Current.Properties["PendingResumeId"] = _pendingResumeId.Value;
                _pendingResumeId = null;
            }
            Manager.MainFrame.Navigate(new LoginPage());
        }

        private void BackToMain_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем ожидающие элементы при возврате на главную
            _pendingVacancyId = null;
            _pendingResumeId = null;
            Manager.MainFrame.Navigate(new MainPage());
        }

        protected override void OnKeyDown(System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                RegisterButton_Click(null, null);
            }
            base.OnKeyDown(e);
        }
    }
}
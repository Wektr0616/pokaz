﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            NavigateToMainPage();
        }

        public void NavigateToMainPage()
        {
            MainFrame.Navigate(new general.MainPage(this));
        }

        private void MainFrame_ContentRendered(object sender, System.EventArgs e)
        {
            Title = "Бюро по трудоустройству";
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Buro
{
    class Manager
    {
        public static Frame MainFrame { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminEmployersPage.xaml
    /// </summary>
    public partial class AdminEmployersPage : Page
    {
        public AdminEmployersPage()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            // Фильтр верификации
            var verificationStatuses = new List<string>
            {
                "Все статусы",
                "Верифицированные",
                "На проверке",
                "Не верифицированные",
                "Заблокированные"
            };

            VerificationFilterComboBox.ItemsSource = verificationStatuses;
            VerificationFilterComboBox.SelectedIndex = 0;

            // Фильтр городов
            var cities = new List<string>
            {
                "Все города",
                "Москва",
                "Санкт-Петербург",
                "Казань",
                "Екатеринбург",
                "Новосибирск",
                "Нижний Новгород"
            };

            CityFilterComboBox.ItemsSource = cities;
            CityFilterComboBox.SelectedIndex = 0;
        }

        private void VerifyAllButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Верифицировать всех непроверенных работодателей?\n\n" +
                                       "Это действие затронет все компании со статусом 'На проверке'.",
                                       "Массовая верификация",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Все работодатели успешно верифицированы!",
                              "Верификация завершена",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchText = SearchTextBox.Text.Trim();
            string verificationStatus = VerificationFilterComboBox.SelectedItem as string;
            string city = CityFilterComboBox.SelectedItem as string;

            MessageBox.Show($"Поиск работодателей:\n\n" +
                          $"Текст: {searchText}\n" +
                          $"Верификация: {verificationStatus}\n" +
                          $"Город: {city}",
                          "Результаты поиска",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Экспорт данных работодателей:\n\n" +
                          "1. Выберите формат (Excel, CSV, PDF)\n" +
                          "2. Выберите поля для экспорта\n" +
                          "3. Экспортировать данные",
                          "Экспорт данных",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewEmployerButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Просмотр подробной информации о работодателе:\n\n" +
                          "• Данные компании\n" +
                          "• История активности\n" +
                          "• Список вакансий\n" +
                          "• Отзывы соискателей",
                          "Информация о работодателе",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void EditEmployerButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Редактирование данных работодателя:\n\n" +
                          "• Изменение информации о компании\n" +
                          "• Редактирование контактных данных\n" +
                          "• Изменение статуса верификации\n" +
                          "• Управление вакансиями",
                          "Редактирование работодателя",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void VerifyEmployerButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Верифицировать этого работодателя?\n\n" +
                                       "После верификации компания получит статус 'Проверенный'.",
                                       "Верификация компании",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Работодатель успешно верифицирован!",
                              "Верификация завершена",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void DeleteEmployerButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Удалить этого работодателя?\n\n" +
                                       "Все данные компании и вакансии будут удалены безвозвратно.",
                                       "Удаление работодателя",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Работодатель удален успешно.",
                              "Удаление завершено",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }
    }
}
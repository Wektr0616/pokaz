﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Buro.Entity;

namespace Buro.Pages
{
    public partial class AdminDashboardPage : Page
    {
        private EmploymentBureauEntities _context;
        private string _currentSection = "Users";
        private object _selectedItem = null;
        private bool _isEditing = false;
        private int _deleteItemId = 0;

        // Фильтры для комиссий
        private DateTime? _filterDateFrom = null;
        private DateTime? _filterDateTo = null;
        private DateTime? _statsDateFrom = null;
        private DateTime? _statsDateTo = null;
        private string _filterCompanyName = "";

        // Словарь для хранения текстовых полей формы
        private Dictionary<string, TextBox> _textBoxes = new Dictionary<string, TextBox>();
        private Dictionary<string, PasswordBox> _passwordBoxes = new Dictionary<string, PasswordBox>();
        private Dictionary<string, ComboBox> _comboBoxes = new Dictionary<string, ComboBox>();
        private Dictionary<string, CheckBox> _checkBoxes = new Dictionary<string, CheckBox>();

        public AdminDashboardPage()
        {
            InitializeComponent();
            _context = EmploymentBureauEntities.GetContext();
            Loaded += Page_Loaded;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            object currentUser = App.Current.Properties["CurrentUser"];
            if (currentUser != null)
            {
                User user = currentUser as User;
                if (user != null)
                {
                    AdminNameText.Text = user.Email;
                }
            }

            LoadData();
            LoadStatisticsCards();
        }

        // ═══════════════════════════════════════════════════════════════
        // ЗАГРУЗКА КАРТОЧЕК СТАТИСТИКИ (ОСНОВНАЯ ПАНЕЛЬ)
        // ═══════════════════════════════════════════════════════════════
        private void LoadStatisticsCards()
        {
            try
            {
                StatUsers.Text = _context.Users.Count().ToString();
                StatCandidates.Text = _context.Candidates.Count().ToString();
                StatEmployers.Text = _context.Employers.Count().ToString();
                StatVacancies.Text = _context.Vacancies.Count().ToString();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Stats error: {ex.Message}");
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // УПРАВЛЕНИЕ ВИДИМОСТЬЮ СТОЛБЦОВ
        // ═══════════════════════════════════════════════════════════════

        private void ConfigureGridColumns()
        {
            ColID.Visibility = Visibility.Visible;
            ColTitle.Visibility = Visibility.Visible;
            ColSubtitle.Visibility = Visibility.Visible;
            ColCommission.Visibility = Visibility.Visible;
            ColStatus.Visibility = Visibility.Visible;
            ColDate.Visibility = Visibility.Visible;
            ColActions.Visibility = Visibility.Visible;

            switch (_currentSection)
            {
                case "Users":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Header = "СТАТУС";
                    ColDate.Header = "ДАТА РЕГИСТРАЦИИ";
                    break;
                case "Candidates":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Visibility = Visibility.Collapsed;
                    ColDate.Header = "ДАТА СОЗДАНИЯ";
                    break;
                case "Employers":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Visibility = Visibility.Collapsed;
                    ColDate.Header = "ДАТА РЕГИСТРАЦИИ";
                    break;
                case "Vacancies":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Header = "СТАТУС";
                    ColDate.Header = "ДАТА ПУБЛИКАЦИИ";
                    break;
                case "Resumes":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Header = "ВИДИМОСТЬ";
                    ColDate.Header = "ДАТА СОЗДАНИЯ";
                    break;
                case "Responses":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Header = "СТАТУС";
                    ColDate.Header = "ДАТА ОТКЛИКА";
                    break;
                case "Commissions":
                    ColCommission.Visibility = Visibility.Visible;
                    ColStatus.Header = "СТАТУС ОПЛАТЫ";
                    ColDate.Header = "ДАТА СОЗДАНИЯ";
                    break;
            }
        }

        private void AdminDataGrid_Loaded(object sender, RoutedEventArgs e)
        {
            ConfigureGridColumns();
        }

        // Переключение меню
        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            StatisticsPanel.Visibility = Visibility.Collapsed;
            AddButton.Visibility = Visibility.Visible;
            SearchTextBox.Visibility = Visibility.Visible;
            Button btn = sender as Button;
            if (btn == null) return;

            UsersMenu.Style = (Style)FindResource("MenuButton");
            CandidatesMenu.Style = (Style)FindResource("MenuButton");
            EmployersMenu.Style = (Style)FindResource("MenuButton");
            VacanciesMenu.Style = (Style)FindResource("MenuButton");
            ResumesMenu.Style = (Style)FindResource("MenuButton");
            ResponsesMenu.Style = (Style)FindResource("MenuButton");
            CommissionsMenu.Style = (Style)FindResource("MenuButton");

            btn.Style = (Style)FindResource("MenuButtonActive");

            _currentSection = btn.Tag.ToString();

            FilterButton.Visibility = (_currentSection == "Commissions") ? Visibility.Visible : Visibility.Collapsed;

            HidePanels();
            LoadData();
            LoadStatisticsCards();
        }

        private void HidePanels()
        {
            EditPanel.Visibility = Visibility.Collapsed;
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            DataPanel.Visibility = Visibility.Visible;
            ClearFormDictionaries();
        }

        private void ClearFormDictionaries()
        {
            _textBoxes.Clear();
            _passwordBoxes.Clear();
            _comboBoxes.Clear();
            _checkBoxes.Clear();
        }

        // Загрузка данных
        private void LoadData()
        {
            try
            {
                _selectedItem = null;
                CommissionProfitPanel.Visibility = Visibility.Collapsed;

                switch (_currentSection)
                {
                    case "Users":
                        LoadUsers();
                        break;
                    case "Candidates":
                        LoadCandidates();
                        break;
                    case "Employers":
                        LoadEmployers();
                        break;
                    case "Vacancies":
                        LoadVacancies();
                        break;
                    case "Resumes":
                        LoadResumes();
                        break;
                    case "Responses":
                        LoadResponses();
                        break;
                    case "Commissions":
                        LoadCommissions();
                        break;
                }

                ConfigureGridColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        // ViewModel для карточек
        public class DataCardViewModel
        {
            public int ID { get; set; }
            public string Title { get; set; }
            public string Subtitle { get; set; }
            public string Info1 { get; set; }
            public string Info2 { get; set; }
            public string Info3 { get; set; }
            public string Description { get; set; }
            public string DateInfo { get; set; }
            public string ExtraInfo { get; set; }
            public bool HasStatus { get; set; }
            public string StatusText { get; set; }
            public SolidColorBrush StatusColor { get; set; }
            public string CommissionInfo { get; set; }
            public string ProfitInfo { get; set; }
        }

        private void LoadUsers()
        {
            PageTitle.Text = "Управление пользователями";
            DataGridTitle.Text = "Список пользователей";

            var users = _context.Users.Select(u => new
            {
                u.UserID,
                u.Email,
                u.Phone,
                RoleName = u.Role.RoleName,
                u.RegistrationDate,
                u.IsActive
            }).ToList();

            var cards = users.Select(u => new DataCardViewModel
            {
                ID = u.UserID,
                Title = u.Email,
                Subtitle = $"Роль: {u.RoleName}",
                Info1 = u.Phone ?? "не указан",
                Info2 = "",
                Info3 = "",
                Description = "",
                DateInfo = $"Зарегистрирован: {u.RegistrationDate:dd.MM.yyyy}",
                ExtraInfo = u.IsActive == true ? "Активен" : "Неактивен",
                HasStatus = true,
                StatusText = u.IsActive == true ? "Активен" : "Неактивен",
                StatusColor = u.IsActive == true ? new SolidColorBrush(Colors.Green) : new SolidColorBrush(Colors.Gray),
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
        }

        private void LoadCandidates()
        {
            PageTitle.Text = "Управление соискателями";
            DataGridTitle.Text = "Список соискателей";

            var candidates = _context.Candidates.Select(c => new
            {
                c.CandidateID,
                c.FullName,
                c.Profession,
                c.ExperienceYears,
                c.Education,
                c.CreatedDate,
                Email = c.User.Email,
                Phone = c.User.Phone
            }).ToList();

            var cards = candidates.Select(c => new DataCardViewModel
            {
                ID = c.CandidateID,
                Title = c.FullName,
                Subtitle = c.Profession ?? "Профессия не указана",
                Info1 = $"Опыт: {c.ExperienceYears ?? 0} лет",
                Info2 = c.Education ?? "",
                Info3 = "",
                Description = $"Email: {c.Email} | Тел: {c.Phone}",
                DateInfo = $"Создан: {c.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = "",
                HasStatus = false,
                StatusText = "",
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
        }

        private void LoadEmployers()
        {
            PageTitle.Text = "Управление работодателями";
            DataGridTitle.Text = "Список работодателей";

            var employers = _context.Employers.Select(e => new
            {
                e.EmployerID,
                e.CompanyName,
                e.INN,
                e.ContactPerson,
                e.Industry,
                e.CreatedDate,
                Email = e.User.Email
            }).ToList();

            var cards = employers.Select(e => new DataCardViewModel
            {
                ID = e.EmployerID,
                Title = e.CompanyName,
                Subtitle = $"ИНН: {e.INN}",
                Info1 = e.Industry ?? "",
                Info2 = "",
                Info3 = "",
                Description = $"Контакт: {e.ContactPerson} | Email: {e.Email}",
                DateInfo = $"Создан: {e.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = "",
                HasStatus = false,
                StatusText = "",
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
        }

        private void LoadVacancies()
        {
            PageTitle.Text = "Управление вакансиями";
            DataGridTitle.Text = "Список вакансий";

            var vacancies = _context.Vacancies.Select(v => new
            {
                v.VacancyID,
                v.Position,
                EmployerName = v.Employer.CompanyName,
                v.SalaryFrom,
                v.SalaryTo,
                v.City,
                v.IsActive,
                v.CreatedDate,
                v.Description
            }).ToList();

            var cards = vacancies.Select(v => new DataCardViewModel
            {
                ID = v.VacancyID,
                Title = v.Position,
                Subtitle = v.EmployerName,
                Info1 = FormatSalaryRange(v.SalaryFrom, v.SalaryTo),
                Info2 = v.City ?? "Город не указан",
                Info3 = "",
                Description = v.Description ?? "",
                DateInfo = $"Создана: {v.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = "",
                HasStatus = true,
                StatusText = v.IsActive == true ? "Активна" : "Не активна",
                StatusColor = v.IsActive == true ? new SolidColorBrush(Colors.Green) : new SolidColorBrush(Colors.Gray),
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
        }

        private void LoadResumes()
        {
            PageTitle.Text = "Управление резюме";
            DataGridTitle.Text = "Список резюме";

            var resumes = _context.Resumes.Select(r => new
            {
                r.ResumeID,
                r.Title,
                CandidateName = r.Candidate.FullName,
                r.SalaryExpectation,
                r.EmploymentType,
                r.IsVisible,
                r.Status,
                r.CreatedDate,
                r.Skills
            }).ToList();

            var cards = resumes.Select(r => new DataCardViewModel
            {
                ID = r.ResumeID,
                Title = r.Title,
                Subtitle = r.CandidateName,
                Info1 = r.SalaryExpectation.HasValue ? $"ЗП: {r.SalaryExpectation:N0} ₽" : "ЗП не указана",
                Info2 = r.EmploymentType ?? "",
                Info3 = "",
                Description = r.Skills ?? "",
                DateInfo = $"Создано: {r.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = $"Статус: {r.Status}",
                HasStatus = true,
                StatusText = r.IsVisible == true ? "Видимое" : "Скрыто",
                StatusColor = r.IsVisible == true ? new SolidColorBrush(Colors.Blue) : new SolidColorBrush(Colors.Gray),
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
        }

        private void LoadResponses()
        {
            PageTitle.Text = "Управление откликами";
            DataGridTitle.Text = "Список откликов";

            var responses = _context.CandidateResponses.Select(r => new
            {
                r.ResponseID,
                CandidateName = r.Candidate.FullName,
                VacancyName = r.Vacancy.Position,
                EmployerName = r.Vacancy.Employer.CompanyName,
                r.Status,
                r.ResponseDate,
                r.EmployerComment
            }).ToList();

            var cards = responses.Select(r => new DataCardViewModel
            {
                ID = r.ResponseID,
                Title = r.CandidateName,
                Subtitle = $"→ {r.VacancyName}",
                Info1 = r.EmployerName,
                Info2 = "",
                Info3 = "",
                Description = r.EmployerComment ?? "",
                DateInfo = $"Отклик: {r.ResponseDate:dd.MM.yyyy HH:mm}",
                ExtraInfo = "",
                HasStatus = true,
                StatusText = r.Status,
                StatusColor = GetResponseStatusColor(r.Status),
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
        }

        private SolidColorBrush GetResponseStatusColor(string status)
        {
            switch (status?.ToLower())
            {
                case "новый":
                    return new SolidColorBrush(Colors.Blue);
                case "на рассмотрении":
                case "рассматривается":
                    return new SolidColorBrush(Colors.Orange);
                case "приглашен на собеседование":
                    return new SolidColorBrush(Colors.Purple);
                case "принят на работу":
                    return new SolidColorBrush(Colors.Green);
                case "отклонен":
                    return new SolidColorBrush(Colors.Red);
                default:
                    return new SolidColorBrush(Colors.Gray);
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // РАЗДЕЛ КОМИССИЙ С ФИЛЬТРАЦИЕЙ
        // ═══════════════════════════════════════════════════════════════

        private void LoadCommissions()
        {
            PageTitle.Text = "Управление комиссиями";
            DataGridTitle.Text = "История комиссий за трудоустройства";

            var query = _context.CommissionHistories.AsQueryable();

            if (_filterDateFrom.HasValue)
                query = query.Where(c => c.CreatedDate >= _filterDateFrom.Value);
            if (_filterDateTo.HasValue)
                query = query.Where(c => c.CreatedDate <= _filterDateTo.Value.AddDays(1).AddSeconds(-1));
            if (!string.IsNullOrWhiteSpace(_filterCompanyName))
                query = query.Where(c => c.Employer.CompanyName.Contains(_filterCompanyName));

            var commissions = query
                .Select(ch => new
                {
                    ch.CommissionID,
                    CandidateName = ch.Candidate.FullName,
                    EmployerName = ch.Employer.CompanyName,
                    VacancyPosition = ch.Vacancy.Position,
                    ch.AnnualSalary,
                    ch.CommissionPercent,
                    ch.CommissionAmount,
                    ch.PaymentStatus,
                    ch.PaymentDate,
                    ch.InvoiceNumber,
                    ch.CreatedDate,
                    ch.Notes
                })
                .OrderByDescending(c => c.CreatedDate)
                .ToList();

            // Финансовые карточки
            var totalProfit = commissions.Sum(x => x.CommissionAmount);
            var paidProfit = commissions.Where(x => x.PaymentStatus == "Оплачено").Sum(x => x.CommissionAmount);
            var pendingProfit = commissions.Where(x => x.PaymentStatus == "Ожидает оплаты").Sum(x => x.CommissionAmount);
            var cancelledProfit = commissions.Where(x => x.PaymentStatus == "Отменено").Sum(x => x.CommissionAmount);

            StatTotalProfit.Text = $"{totalProfit:N0} ₽";
            StatPaidProfit.Text = $"{paidProfit:N0} ₽";
            StatPendingProfit.Text = $"{pendingProfit:N0} ₽";
            StatCancelledProfit.Text = $"{cancelledProfit:N0} ₽";
            CommissionProfitPanel.Visibility = Visibility.Visible;

            var cards = commissions.Select(c => new DataCardViewModel
            {
                ID = c.CommissionID,
                Title = $"{c.CandidateName} → {c.EmployerName}",
                Subtitle = c.VacancyPosition,
                Info1 = $"💰 Комиссия: {c.CommissionAmount:N0} ₽ ({c.CommissionPercent}%)",
                Info2 = $"📅 Годовой оклад: {c.AnnualSalary:N0} ₽",
                Info3 = $"🏢 {c.EmployerName}",
                Description = c.Notes ?? "",
                DateInfo = c.PaymentDate.HasValue ? $"Оплачено: {c.PaymentDate:dd.MM.yyyy}" : $"Создано: {c.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = c.PaymentStatus,
                HasStatus = true,
                StatusText = c.PaymentStatus,
                StatusColor = GetPaymentStatusColor(c.PaymentStatus),
                CommissionInfo = $"{c.CommissionAmount:N0} ₽"
            }).ToList();

            AdminDataGrid.ItemsSource = cards;

            var sb = new StringBuilder($"Всего записей: {cards.Count}");
            if (_filterDateFrom.HasValue || _filterDateTo.HasValue || !string.IsNullOrWhiteSpace(_filterCompanyName))
            {
                sb.Append("  [Фильтры: ");
                var filters = new List<string>();
                if (_filterDateFrom.HasValue) filters.Add($"с {_filterDateFrom.Value:dd.MM.yyyy}");
                if (_filterDateTo.HasValue) filters.Add($"по {_filterDateTo.Value:dd.MM.yyyy}");
                if (!string.IsNullOrWhiteSpace(_filterCompanyName)) filters.Add($"компания: {_filterCompanyName}");
                sb.Append(string.Join(", ", filters));
                sb.Append("]");
            }
            PageSubtitle.Text = sb.ToString();
        }

        private SolidColorBrush GetPaymentStatusColor(string status)
        {
            switch (status?.ToLower())
            {
                case "оплачено":
                    return new SolidColorBrush(Colors.Green);
                case "ожидает оплаты":
                    return new SolidColorBrush(Colors.Orange);
                case "отменено":
                    return new SolidColorBrush(Colors.Gray);
                default:
                    return new SolidColorBrush(Colors.Blue);
            }
        }

        // Фильтрация комиссий
        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            ShowCommissionFilters();
        }

        private void ShowCommissionFilters()
        {
            EditPanel.Visibility = Visibility.Visible;
            DataPanel.Visibility = Visibility.Collapsed;
            EditPanelTitle.Text = "🔍 Фильтрация комиссий";
            SaveButton.Content = "Применить фильтры";
            SaveButton.Click -= SaveButton_Click;
            SaveButton.Click += ApplyCommissionFilters_Click;

            EditFormContainer.Children.Clear();
            ClearFormDictionaries();

            // Дата "с"
            var dateFromPanel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };
            dateFromPanel.Children.Add(new TextBlock
            {
                Text = "Дата с:",
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            });
            var dateFromPicker = new DatePicker
            {
                Name = "DateFromPicker",
                SelectedDate = _filterDateFrom,
                Language = System.Windows.Markup.XmlLanguage.GetLanguage("ru-RU"),
                Padding = new Thickness(10),
                FontSize = 14
            };
            dateFromPanel.Children.Add(dateFromPicker);
            EditFormContainer.Children.Add(dateFromPanel);

            // Дата "по"
            var dateToPanel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };
            dateToPanel.Children.Add(new TextBlock
            {
                Text = "Дата по:",
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            });
            var dateToPicker = new DatePicker
            {
                Name = "DateToPicker",
                SelectedDate = _filterDateTo,
                Language = System.Windows.Markup.XmlLanguage.GetLanguage("ru-RU"),
                Padding = new Thickness(10),
                FontSize = 14
            };
            dateToPanel.Children.Add(dateToPicker);
            EditFormContainer.Children.Add(dateToPanel);

            // Название компании
            AddFormField("Название компании:", "CompanyName", _filterCompanyName);

            // Быстрые фильтры
            AddQuickDateFilters(dateFromPicker, dateToPicker);

            // Кнопка сброса
            AddResetFiltersButton();

            // Информация о текущих фильтрах
            ShowCurrentFiltersInfo();
        }

        private void AddQuickDateFilters(DatePicker fromPicker, DatePicker toPicker)
        {
            var quickFilterPanel = new StackPanel { Margin = new Thickness(0, 10, 0, 10) };
            quickFilterPanel.Children.Add(new TextBlock
            {
                Text = "Быстрый выбор периода:",
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 8)
            });

            var quickButtonsWrap = new WrapPanel { Orientation = Orientation.Horizontal };
            var quickFilters = new[] { "Сегодня", "Вчера", "Неделя", "Месяц", "Год", "Всё время" };

            foreach (var filter in quickFilters)
            {
                var quickBtn = new Button
                {
                    Content = filter,
                    Margin = new Thickness(0, 0, 8, 8),
                    Padding = new Thickness(12, 6, 12, 6),
                    Background = new SolidColorBrush(Color.FromRgb(240, 240, 240)),
                    Cursor = Cursors.Hand,
                    FontSize = 12
                };
                quickBtn.Click += (s, ev) => ApplyQuickDateFilter(filter, fromPicker, toPicker);
                quickButtonsWrap.Children.Add(quickBtn);
            }

            quickFilterPanel.Children.Add(quickButtonsWrap);
            EditFormContainer.Children.Add(quickFilterPanel);
        }

        private void ApplyQuickDateFilter(string filterType, DatePicker fromPicker, DatePicker toPicker)
        {
            DateTime today = DateTime.Today;

            switch (filterType)
            {
                case "Сегодня":
                    _filterDateFrom = today;
                    _filterDateTo = today;
                    break;
                case "Вчера":
                    _filterDateFrom = today.AddDays(-1);
                    _filterDateTo = today.AddDays(-1);
                    break;
                case "Неделя":
                    _filterDateFrom = today.AddDays(-7);
                    _filterDateTo = today;
                    break;
                case "Месяц":
                    _filterDateFrom = today.AddMonths(-1);
                    _filterDateTo = today;
                    break;
                case "Год":
                    _filterDateFrom = today.AddYears(-1);
                    _filterDateTo = today;
                    break;
                case "Всё время":
                    _filterDateFrom = null;
                    _filterDateTo = null;
                    break;
            }

            if (fromPicker != null) fromPicker.SelectedDate = _filterDateFrom;
            if (toPicker != null) toPicker.SelectedDate = _filterDateTo;
        }

        private void AddResetFiltersButton()
        {
            var resetPanel = new StackPanel { Margin = new Thickness(0, 15, 0, 0) };
            var resetButton = new Button
            {
                Content = "🔄 Сбросить все фильтры",
                Background = new SolidColorBrush(Colors.Gray),
                Foreground = new SolidColorBrush(Colors.White),
                Padding = new Thickness(15, 10, 15, 10),
                Cursor = Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Left,
                FontSize = 13
            };
            resetButton.Click += ResetFilters_Click;
            resetPanel.Children.Add(resetButton);
            EditFormContainer.Children.Add(resetPanel);
        }

        private void ShowCurrentFiltersInfo()
        {
            if (_filterDateFrom.HasValue || _filterDateTo.HasValue || !string.IsNullOrWhiteSpace(_filterCompanyName))
            {
                var currentFilterPanel = new Border
                {
                    Background = new SolidColorBrush(Color.FromRgb(232, 245, 233)),
                    CornerRadius = new CornerRadius(8),
                    Padding = new Thickness(15),
                    Margin = new Thickness(0, 15, 0, 0),
                    BorderBrush = new SolidColorBrush(Color.FromRgb(129, 199, 132)),
                    BorderThickness = new Thickness(1)
                };

                var currentFilterStack = new StackPanel();
                currentFilterStack.Children.Add(new TextBlock
                {
                    Text = "📋 Текущие фильтры:",
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(Color.FromRgb(27, 94, 32)),
                    Margin = new Thickness(0, 0, 0, 8)
                });

                var filtersList = new StringBuilder();
                if (_filterDateFrom.HasValue) filtersList.AppendLine($"• С: {_filterDateFrom.Value:dd.MM.yyyy}");
                if (_filterDateTo.HasValue) filtersList.AppendLine($"• По: {_filterDateTo.Value:dd.MM.yyyy}");
                if (!string.IsNullOrWhiteSpace(_filterCompanyName)) filtersList.AppendLine($"• Компания: {_filterCompanyName}");

                currentFilterStack.Children.Add(new TextBlock
                {
                    Text = filtersList.ToString().TrimEnd(),
                    Foreground = new SolidColorBrush(Color.FromRgb(46, 125, 50)),
                    LineHeight = 20
                });

                currentFilterPanel.Child = currentFilterStack;
                EditFormContainer.Children.Add(currentFilterPanel);
            }
        }

        private void ApplyCommissionFilters_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var fromPicker = FindVisualChild<DatePicker>(EditFormContainer, "DateFromPicker");
                var toPicker = FindVisualChild<DatePicker>(EditFormContainer, "DateToPicker");

                _filterDateFrom = fromPicker?.SelectedDate;
                _filterDateTo = toPicker?.SelectedDate;

                if (_filterDateFrom.HasValue && _filterDateTo.HasValue && _filterDateFrom > _filterDateTo)
                {
                    MessageBox.Show("Дата 'с' не может быть позже даты 'по'.", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                _filterCompanyName = GetTextValue("CompanyName");

                SaveButton.Click -= ApplyCommissionFilters_Click;
                SaveButton.Click += SaveButton_Click;

                HidePanels();
                LoadCommissions();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка применения фильтров: " + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ResetFilters_Click(object sender, RoutedEventArgs e)
        {
            _filterDateFrom = null;
            _filterDateTo = null;
            _filterCompanyName = "";

            SaveButton.Click -= ApplyCommissionFilters_Click;
            SaveButton.Click += SaveButton_Click;

            HidePanels();
            LoadCommissions();
        }

        private T FindVisualChild<T>(DependencyObject parent, string name) where T : FrameworkElement
        {
            if (parent == null) return null;

            int childCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T typedChild && typedChild.Name == name)
                    return typedChild;

                var result = FindVisualChild<T>(child, name);
                if (result != null)
                    return result;
            }
            return null;
        }

        // Обработчики кнопок
        private void EditItem_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null) return;
            EditItemById((int)btn.Tag);
        }

        private void ViewItem_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null) return;
            MessageBox.Show($"Просмотр записи ID: {btn.Tag}", "Просмотр",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void DeleteItem_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null) return;

            _deleteItemId = (int)btn.Tag;

            string name = "Unknown";
            var item = AdminDataGrid.ItemsSource as List<DataCardViewModel>;
            if (item != null)
            {
                var card = item.FirstOrDefault(x => x.ID == _deleteItemId);
                if (card != null) name = card.Title;
            }

            DeleteConfirmText.Text = $"Вы уверены, что хотите удалить '{name}'?\n\nЭто действие нельзя отменить!";
            DeleteConfirmPanel.Visibility = Visibility.Visible;
            DataPanel.Visibility = Visibility.Collapsed;
        }

        private void EditItemById(int id)
        {
            _isEditing = true;
            _selectedItem = new { ID = id };

            EditPanel.Visibility = Visibility.Visible;
            DataPanel.Visibility = Visibility.Collapsed;
            EditPanelTitle.Text = "Редактирование записи";
            SaveButton.Content = "💾 Сохранить изменения";
            SaveButton.Click -= ApplyCommissionFilters_Click;
            SaveButton.Click += SaveButton_Click;

            BuildEditForm(id);
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentSection == "Commissions")
            {
                ShowCommissionFilters();
                return;
            }

            _isEditing = false;
            _selectedItem = null;

            EditPanel.Visibility = Visibility.Visible;
            DataPanel.Visibility = Visibility.Collapsed;
            EditPanelTitle.Text = "Добавление новой записи";
            SaveButton.Content = "➕ Добавить запись";
            SaveButton.Click -= ApplyCommissionFilters_Click;
            SaveButton.Click += SaveButton_Click;

            BuildEditForm(0);
        }

        private void BuildEditForm(int id)
        {
            EditFormContainer.Children.Clear();
            ClearFormDictionaries();

            switch (_currentSection)
            {
                case "Users": BuildUserForm(id); break;
                case "Candidates": BuildCandidateForm(id); break;
                case "Employers": BuildEmployerForm(id); break;
                case "Vacancies": BuildVacancyForm(id); break;
                case "Resumes": BuildResumeForm(id); break;
                case "Responses": BuildResponseForm(id); break;
                case "Commissions": BuildCommissionForm(id); break;
            }
        }

        private void BuildUserForm(int id)
        {
            string email = "", phone = "", roleName = "Candidate";
            bool isActive = true;

            if (_isEditing && id > 0)
            {
                var user = _context.Users.Find(id);
                if (user != null)
                {
                    email = user.Email;
                    phone = user.Phone;
                    roleName = user.Role.RoleName;
                    isActive = user.IsActive ?? true;
                }
            }

            AddFormField("Email:", "Email", email);
            AddFormField("Телефон:", "Phone", phone);
            AddPasswordField("Пароль (оставьте пустым, чтобы не менять):", "Password");

            var roles = _context.Roles.Select(r => r.RoleName).ToList();
            AddComboBoxField("Роль:", "Role", roles, roleName);
            AddCheckBoxField("Активен:", "IsActive", isActive);
        }

        private void BuildCandidateForm(int id)
        {
            string fullName = "", profession = "", experience = "", education = "", email = "", phone = "";

            if (_isEditing && id > 0)
            {
                var candidate = _context.Candidates.Find(id);
                if (candidate != null)
                {
                    fullName = candidate.FullName;
                    profession = candidate.Profession;
                    experience = candidate.ExperienceYears?.ToString() ?? "";
                    education = candidate.Education;
                    email = candidate.User.Email;
                    phone = candidate.User.Phone;
                }
            }

            if (!_isEditing)
            {
                AddFormField("Email:", "Email", "");
                AddFormField("Телефон:", "Phone", "");
                AddPasswordField("Пароль:", "Password");
            }
            else
            {
                AddFormField("Email:", "Email", email, true);
                AddFormField("Телефон:", "Phone", phone, true);
            }

            AddFormField("ФИО:", "FullName", fullName);
            AddFormField("Профессия:", "Profession", profession);
            AddFormField("Опыт работы (лет):", "Experience", experience);
            AddFormField("Образование:", "Education", education);
        }

        private void BuildEmployerForm(int id)
        {
            string companyName = "", inn = "", contactPerson = "", industry = "", email = "", phone = "";

            if (_isEditing && id > 0)
            {
                var employer = _context.Employers.Find(id);
                if (employer != null)
                {
                    companyName = employer.CompanyName;
                    inn = employer.INN;
                    contactPerson = employer.ContactPerson;
                    industry = employer.Industry;
                    email = employer.User.Email;
                    phone = employer.User.Phone;
                }
            }

            if (!_isEditing)
            {
                AddFormField("Email:", "Email", "");
                AddFormField("Телефон:", "Phone", "");
                AddPasswordField("Пароль:", "Password");
            }
            else
            {
                AddFormField("Email:", "Email", email, true);
                AddFormField("Телефон:", "Phone", phone, true);
            }

            AddFormField("Название компании:", "CompanyName", companyName);
            AddFormField("ИНН:", "INN", inn);
            AddFormField("Контактное лицо:", "ContactPerson", contactPerson);
            AddFormField("Отрасль:", "Industry", industry);
        }

        private void BuildVacancyForm(int id)
        {
            string position = "", salaryFrom = "", salaryTo = "", city = "", description = "", requirements = "";
            bool isActive = true;
            int selectedEmployerId = 0;

            if (_isEditing && id > 0)
            {
                var vacancy = _context.Vacancies.Find(id);
                if (vacancy != null)
                {
                    position = vacancy.Position;
                    salaryFrom = vacancy.SalaryFrom?.ToString() ?? "";
                    salaryTo = vacancy.SalaryTo?.ToString() ?? "";
                    city = vacancy.City;
                    isActive = vacancy.IsActive ?? true;
                    selectedEmployerId = vacancy.EmployerID;
                    description = vacancy.Description ?? "";
                    requirements = vacancy.Requirements ?? "";
                }
            }

            var employers = _context.Employers.Select(e => new { Id = e.EmployerID, Text = e.CompanyName }).ToList<dynamic>();
            AddEmployerComboBox("Работодатель:", "Employer", employers, selectedEmployerId);
            AddFormField("Должность:", "Position", position);
            AddFormField("Зарплата от:", "SalaryFrom", salaryFrom);
            AddFormField("Зарплата до:", "SalaryTo", salaryTo);
            AddFormField("Город:", "City", city);
            AddFormField("Описание:", "Description", description, false, true);
            AddFormField("Требования:", "Requirements", requirements, false, true);
            AddCheckBoxField("Активна:", "IsActive", isActive);
        }

        private void BuildResumeForm(int id)
        {
            string title = "", salary = "", status = "Опубликовано";
            bool isVisible = true;

            if (_isEditing && id > 0)
            {
                var resume = _context.Resumes.Find(id);
                if (resume != null)
                {
                    title = resume.Title;
                    salary = resume.SalaryExpectation?.ToString() ?? "";
                    status = resume.Status;
                    isVisible = resume.IsVisible ?? true;
                }
            }

            AddFormField("Название резюме:", "Title", title);
            AddFormField("Ожидаемая зарплата:", "Salary", salary);

            var statuses = new List<string> { "Опубликовано", "На проверке", "Черновик", "Архив" };
            AddComboBoxField("Статус:", "Status", statuses, status);
            AddCheckBoxField("Видимое для работодателей:", "IsVisible", isVisible);
        }

        private void BuildResponseForm(int id)
        {
            string status = "", comment = "";

            if (_isEditing && id > 0)
            {
                var response = _context.CandidateResponses.Find(id);
                if (response != null)
                {
                    status = response.Status;
                    comment = response.EmployerComment;
                }
            }

            var statuses = new List<string> { "Новый", "На рассмотрении", "Приглашен на собеседование", "Отклонен", "Принят на работу" };
            AddComboBoxField("Статус отклика:", "Status", statuses, status);
            AddFormField("Комментарий работодателя:", "Comment", comment, false, true);
        }

        private void BuildCommissionForm(int id)
        {
            string annualSalary = "", commissionPercent = "", commissionAmount = "", paymentStatus = "Ожидает оплаты", paymentDate = "", invoiceNumber = "", notes = "";

            if (_isEditing && id > 0)
            {
                var commission = _context.CommissionHistories.Find(id);
                if (commission != null)
                {
                    annualSalary = commission.AnnualSalary.ToString();
                    commissionPercent = commission.CommissionPercent.ToString();
                    commissionAmount = commission.CommissionAmount.ToString();
                    paymentStatus = commission.PaymentStatus;
                    paymentDate = commission.PaymentDate?.ToString("yyyy-MM-dd") ?? "";
                    invoiceNumber = commission.InvoiceNumber ?? "";
                    notes = commission.Notes ?? "";
                }
            }

            AddFormField("Годовой оклад (₽):", "AnnualSalary", annualSalary);
            AddFormField("Процент комиссии (%):", "CommissionPercent", commissionPercent);
            AddFormField("Сумма комиссии (₽):", "CommissionAmount", commissionAmount, true);

            var statuses = new List<string> { "Ожидает оплаты", "Оплачено", "Отменено" };
            AddComboBoxField("Статус оплаты:", "PaymentStatus", statuses, paymentStatus);
            AddFormField("Дата оплаты (ГГГГ-ММ-ДД):", "PaymentDate", paymentDate);
            AddFormField("Номер счёта/акта:", "InvoiceNumber", invoiceNumber);
            AddFormField("Примечания:", "Notes", notes, false, true);
        }

        // Вспомогательные методы создания полей
        private void AddFormField(string label, string fieldName, string value, bool isReadOnly = false, bool isMultiline = false)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };
            panel.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 5) });

            Control inputControl;
            if (isMultiline)
            {
                inputControl = new TextBox
                {
                    Name = fieldName,
                    Text = value,
                    TextWrapping = TextWrapping.Wrap,
                    AcceptsReturn = true,
                    Height = 80,
                    Padding = new Thickness(10),
                    IsReadOnly = isReadOnly,
                    Background = isReadOnly ? new SolidColorBrush(Colors.LightGray) : new SolidColorBrush(Colors.White)
                };
            }
            else
            {
                inputControl = new TextBox
                {
                    Name = fieldName,
                    Text = value,
                    Padding = new Thickness(10),
                    IsReadOnly = isReadOnly,
                    Background = isReadOnly ? new SolidColorBrush(Colors.LightGray) : new SolidColorBrush(Colors.White)
                };
            }

            panel.Children.Add(inputControl);
            EditFormContainer.Children.Add(panel);
            _textBoxes[fieldName] = inputControl as TextBox;
        }

        private void AddPasswordField(string label, string fieldName)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };
            panel.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 5) });

            var passwordBox = new PasswordBox { Name = fieldName, Padding = new Thickness(10) };
            panel.Children.Add(passwordBox);
            EditFormContainer.Children.Add(panel);
            _passwordBoxes[fieldName] = passwordBox;
        }

        private void AddComboBoxField(string label, string fieldName, List<string> items, string selectedValue)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };
            panel.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 5) });

            var comboBox = new ComboBox { Name = fieldName, Padding = new Thickness(10) };
            foreach (var item in items) comboBox.Items.Add(item);

            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                if (comboBox.Items[i].ToString() == selectedValue)
                {
                    comboBox.SelectedIndex = i;
                    break;
                }
            }
            if (comboBox.SelectedIndex < 0 && comboBox.Items.Count > 0) comboBox.SelectedIndex = 0;

            panel.Children.Add(comboBox);
            EditFormContainer.Children.Add(panel);
            _comboBoxes[fieldName] = comboBox;
        }

        private void AddEmployerComboBox(string label, string fieldName, List<dynamic> items, int selectedId)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };
            panel.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 5) });

            var comboBox = new ComboBox
            {
                Name = fieldName,
                Padding = new Thickness(10),
                DisplayMemberPath = "Text",
                SelectedValuePath = "Id"
            };
            foreach (var item in items) comboBox.Items.Add(item);

            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                dynamic item = comboBox.Items[i];
                if (item.Id == selectedId)
                {
                    comboBox.SelectedIndex = i;
                    break;
                }
            }
            if (comboBox.SelectedIndex < 0 && comboBox.Items.Count > 0) comboBox.SelectedIndex = 0;

            panel.Children.Add(comboBox);
            EditFormContainer.Children.Add(panel);
            _comboBoxes[fieldName] = comboBox;
        }

        private void AddCheckBoxField(string label, string fieldName, bool isChecked)
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 10, 0, 10) };
            var checkBox = new CheckBox { Name = fieldName, IsChecked = isChecked, Margin = new Thickness(0, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center };
            panel.Children.Add(checkBox);
            panel.Children.Add(new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center });
            EditFormContainer.Children.Add(panel);
            _checkBoxes[fieldName] = checkBox;
        }

        private string GetTextValue(string fieldName) => _textBoxes.ContainsKey(fieldName) ? _textBoxes[fieldName].Text ?? "" : "";
        private string GetPasswordValue(string fieldName) => _passwordBoxes.ContainsKey(fieldName) ? _passwordBoxes[fieldName].Password ?? "" : "";
        private string GetComboValue(string fieldName) => _comboBoxes.ContainsKey(fieldName) ? _comboBoxes[fieldName].SelectedItem?.ToString() ?? "" : "";
        private int GetEmployerComboValue(string fieldName) => _comboBoxes.ContainsKey(fieldName) && _comboBoxes[fieldName].SelectedItem != null ? ((dynamic)_comboBoxes[fieldName].SelectedItem).Id : 0;
        private bool GetCheckValue(string fieldName) => _checkBoxes.ContainsKey(fieldName) && _checkBoxes[fieldName].IsChecked == true;
        private int? ParseInt(string value) => int.TryParse(value, out int result) ? result : (int?)null;
        private decimal? ParseDecimal(string value) => decimal.TryParse(value, out decimal result) ? result : (decimal?)null;

        // Сохранение
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateForm()) return;

                if (_isEditing)
                {
                    UpdateExistingRecord();
                    MessageBox.Show("Изменения успешно сохранены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    CreateNewRecord();
                    MessageBox.Show("Новая запись успешно добавлена!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                HidePanels();
                LoadData();
                LoadStatisticsCards();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateForm()
        {
            if ((_currentSection == "Users" || (!_isEditing && (_currentSection == "Candidates" || _currentSection == "Employers"))) && string.IsNullOrWhiteSpace(GetTextValue("Email")))
            {
                MessageBox.Show("Email обязателен для заполнения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!_isEditing && string.IsNullOrWhiteSpace(GetPasswordValue("Password")))
            {
                MessageBox.Show("Пароль обязателен для новых записей!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (_currentSection == "Commissions")
            {
                if (string.IsNullOrWhiteSpace(GetTextValue("AnnualSalary")))
                {
                    MessageBox.Show("Годовой оклад обязателен для заполнения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }
                if (string.IsNullOrWhiteSpace(GetTextValue("CommissionPercent")))
                {
                    MessageBox.Show("Процент комиссии обязателен для заполнения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }
            }

            return true;
        }

        private void CreateNewRecord()
        {
            switch (_currentSection)
            {
                case "Users": CreateUser(); break;
                case "Candidates": CreateCandidate(); break;
                case "Employers": CreateEmployer(); break;
                case "Vacancies": CreateVacancy(); break;
                case "Commissions": CreateCommission(); break;
            }
        }

        private void UpdateExistingRecord()
        {
            dynamic item = _selectedItem;
            int id = item.ID;

            switch (_currentSection)
            {
                case "Users": UpdateUser(id); break;
                case "Candidates": UpdateCandidate(id); break;
                case "Employers": UpdateEmployer(id); break;
                case "Vacancies": UpdateVacancy(id); break;
                case "Resumes": UpdateResume(id); break;
                case "Responses": UpdateResponse(id); break;
                case "Commissions": UpdateCommission(id); break;
            }
        }

        private void CreateUser()
        {
            string email = GetTextValue("Email");
            if (_context.Users.Any(u => u.Email == email))
                throw new Exception("Пользователь с таким email уже существует!");

            string roleName = GetComboValue("Role");
            var role = _context.Roles.FirstOrDefault(r => r.RoleName == roleName);
            if (role == null) throw new Exception("Роль не найдена!");

            var user = new User
            {
                Email = email,
                Phone = GetTextValue("Phone"),
                PasswordHash = GetPasswordValue("Password"),
                RoleID = role.RoleID,
                IsActive = GetCheckValue("IsActive"),
                RegistrationDate = DateTime.Now
            };
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        private void CreateCandidate()
        {
            string email = GetTextValue("Email");
            if (_context.Users.Any(u => u.Email == email))
                throw new Exception("Пользователь с таким email уже существует!");

            var user = new User
            {
                Email = email,
                Phone = GetTextValue("Phone"),
                PasswordHash = GetPasswordValue("Password"),
                RoleID = 2,
                IsActive = true,
                RegistrationDate = DateTime.Now
            };
            _context.Users.Add(user);
            _context.SaveChanges();

            var candidate = new Candidate
            {
                CandidateID = user.UserID,
                FullName = GetTextValue("FullName"),
                Profession = GetTextValue("Profession"),
                ExperienceYears = ParseInt(GetTextValue("Experience")),
                Education = GetTextValue("Education"),
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now
            };
            _context.Candidates.Add(candidate);
            _context.SaveChanges();
        }

        private void CreateEmployer()
        {
            string email = GetTextValue("Email");
            if (_context.Users.Any(u => u.Email == email))
                throw new Exception("Пользователь с таким email уже существует!");

            var user = new User
            {
                Email = email,
                Phone = GetTextValue("Phone"),
                PasswordHash = GetPasswordValue("Password"),
                RoleID = 3,
                IsActive = true,
                RegistrationDate = DateTime.Now
            };
            _context.Users.Add(user);
            _context.SaveChanges();

            var employer = new Employer
            {
                EmployerID = user.UserID,
                CompanyName = GetTextValue("CompanyName"),
                INN = GetTextValue("INN"),
                ContactPerson = GetTextValue("ContactPerson"),
                Industry = GetTextValue("Industry"),
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now
            };
            _context.Employers.Add(employer);
            _context.SaveChanges();
        }

        private void CreateVacancy()
        {
            var vacancy = new Vacancy
            {
                EmployerID = GetEmployerComboValue("Employer"),
                Position = GetTextValue("Position"),
                SalaryFrom = ParseDecimal(GetTextValue("SalaryFrom")),
                SalaryTo = ParseDecimal(GetTextValue("SalaryTo")),
                City = GetTextValue("City"),
                Description = GetTextValue("Description"),
                Requirements = GetTextValue("Requirements"),
                IsActive = GetCheckValue("IsActive"),
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now
            };
            _context.Vacancies.Add(vacancy);
            _context.SaveChanges();
        }

        private void CreateCommission()
        {
            var successfulResponses = _context.CandidateResponses.Where(r => r.Status == "Принят на работу").ToList();
            if (!successfulResponses.Any())
                throw new Exception("Нет успешных трудоустройств для создания комиссии!");

            var response = successfulResponses.First();

            decimal annualSalary = ParseDecimal(GetTextValue("AnnualSalary")) ?? 0;
            decimal percent = ParseDecimal(GetTextValue("CommissionPercent")) ?? 15;
            decimal commissionAmount = annualSalary * (percent / 100);

            var commission = new CommissionHistory
            {
                ResponseID = response.ResponseID,
                CandidateID = response.CandidateID,
                EmployerID = response.Vacancy.EmployerID,
                VacancyID = response.VacancyID,
                AnnualSalary = annualSalary,
                CommissionPercent = percent,
                CommissionAmount = commissionAmount,
                PaymentStatus = GetComboValue("PaymentStatus"),
                PaymentDate = string.IsNullOrEmpty(GetTextValue("PaymentDate")) ? (DateTime?)null : DateTime.Parse(GetTextValue("PaymentDate")),
                InvoiceNumber = GetTextValue("InvoiceNumber"),
                Notes = GetTextValue("Notes"),
                CreatedDate = DateTime.Now
            };
            _context.CommissionHistories.Add(commission);
            _context.SaveChanges();
        }

        private void UpdateUser(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null) throw new Exception("Пользователь не найден!");

            string newEmail = GetTextValue("Email");
            if (newEmail != user.Email && _context.Users.Any(u => u.Email == newEmail))
                throw new Exception("Email уже используется другим пользователем!");

            user.Email = newEmail;
            user.Phone = GetTextValue("Phone");

            string newPassword = GetPasswordValue("Password");
            if (!string.IsNullOrWhiteSpace(newPassword)) user.PasswordHash = newPassword;

            string roleName = GetComboValue("Role");
            var role = _context.Roles.FirstOrDefault(r => r.RoleName == roleName);
            if (role != null) user.RoleID = role.RoleID;

            user.IsActive = GetCheckValue("IsActive");
            _context.SaveChanges();
        }

        private void UpdateCandidate(int id)
        {
            var candidate = _context.Candidates.Find(id);
            if (candidate == null) throw new Exception("Соискатель не найден!");

            candidate.FullName = GetTextValue("FullName");
            candidate.Profession = GetTextValue("Profession");
            candidate.ExperienceYears = ParseInt(GetTextValue("Experience"));
            candidate.Education = GetTextValue("Education");
            candidate.UpdatedDate = DateTime.Now;
            _context.SaveChanges();
        }

        private void UpdateEmployer(int id)
        {
            var employer = _context.Employers.Find(id);
            if (employer == null) throw new Exception("Работодатель не найден!");

            employer.CompanyName = GetTextValue("CompanyName");
            employer.INN = GetTextValue("INN");
            employer.ContactPerson = GetTextValue("ContactPerson");
            employer.Industry = GetTextValue("Industry");
            employer.UpdatedDate = DateTime.Now;
            _context.SaveChanges();
        }

        private void UpdateVacancy(int id)
        {
            var vacancy = _context.Vacancies.Find(id);
            if (vacancy == null) throw new Exception("Вакансия не найдена!");

            vacancy.EmployerID = GetEmployerComboValue("Employer");
            vacancy.Position = GetTextValue("Position");
            vacancy.SalaryFrom = ParseDecimal(GetTextValue("SalaryFrom"));
            vacancy.SalaryTo = ParseDecimal(GetTextValue("SalaryTo"));
            vacancy.City = GetTextValue("City");
            vacancy.Description = GetTextValue("Description");
            vacancy.Requirements = GetTextValue("Requirements");
            vacancy.IsActive = GetCheckValue("IsActive");
            vacancy.UpdatedDate = DateTime.Now;
            _context.SaveChanges();
        }

        private void UpdateResume(int id)
        {
            var resume = _context.Resumes.Find(id);
            if (resume == null) throw new Exception("Резюме не найдено!");

            resume.Title = GetTextValue("Title");
            resume.SalaryExpectation = ParseDecimal(GetTextValue("Salary"));
            resume.Status = GetComboValue("Status");
            resume.IsVisible = GetCheckValue("IsVisible");
            resume.UpdatedDate = DateTime.Now;
            _context.SaveChanges();
        }

        private void UpdateResponse(int id)
        {
            var response = _context.CandidateResponses.Find(id);
            if (response == null) throw new Exception("Отклик не найден!");

            response.Status = GetComboValue("Status");
            string comment = GetTextValue("Comment");
            response.EmployerComment = string.IsNullOrWhiteSpace(comment) ? null : comment;
            _context.SaveChanges();
        }

        private void UpdateCommission(int id)
        {
            var commission = _context.CommissionHistories.Find(id);
            if (commission == null) throw new Exception("Запись комиссии не найдена!");

            decimal annualSalary = ParseDecimal(GetTextValue("AnnualSalary")) ?? commission.AnnualSalary;
            decimal percent = ParseDecimal(GetTextValue("CommissionPercent")) ?? commission.CommissionPercent;

            commission.AnnualSalary = annualSalary;
            commission.CommissionPercent = percent;
            commission.CommissionAmount = annualSalary * (percent / 100);
            commission.PaymentStatus = GetComboValue("PaymentStatus");

            string paymentDateStr = GetTextValue("PaymentDate");
            commission.PaymentDate = string.IsNullOrEmpty(paymentDateStr) ? (DateTime?)null : DateTime.Parse(paymentDateStr);

            commission.InvoiceNumber = GetTextValue("InvoiceNumber");
            commission.Notes = GetTextValue("Notes");
            commission.UpdatedDate = DateTime.Now;
            _context.SaveChanges();
        }

        // Удаление
        private void ConfirmDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                switch (_currentSection)
                {
                    case "Users": DeleteUser(); break;
                    case "Candidates": DeleteCandidate(); break;
                    case "Employers": DeleteEmployer(); break;
                    case "Vacancies": DeleteVacancy(); break;
                    case "Resumes": DeleteResume(); break;
                    case "Responses": DeleteResponse(); break;
                    case "Commissions": DeleteCommission(); break;
                }
                _context.SaveChanges();
                HidePanels();
                LoadData();
                LoadStatisticsCards();
                MessageBox.Show("Запись успешно удалена!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при удалении: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteUser()
        {
            var user = _context.Users.Find(_deleteItemId);
            if (user == null) return;

            var admin = _context.Admins.FirstOrDefault(a => a.AdminID == user.UserID);
            if (admin != null) _context.Admins.Remove(admin);

            var candidate = _context.Candidates.FirstOrDefault(c => c.CandidateID == user.UserID);
            if (candidate != null)
            {
                var resumes = _context.Resumes.Where(r => r.CandidateID == candidate.CandidateID).ToList();
                foreach (var r in resumes)
                {
                    _context.CandidateResponses.RemoveRange(_context.CandidateResponses.Where(cr => cr.ResumeID == r.ResumeID));
                    _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.ResumeID == r.ResumeID));
                }
                _context.Resumes.RemoveRange(resumes);
                _context.CandidateResponses.RemoveRange(_context.CandidateResponses.Where(cr => cr.CandidateID == candidate.CandidateID));
                _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.CandidateID == candidate.CandidateID));
                _context.CommissionHistories.RemoveRange(_context.CommissionHistories.Where(ch => ch.CandidateID == candidate.CandidateID));
                _context.Candidates.Remove(candidate);
            }

            var employer = _context.Employers.FirstOrDefault(emp => emp.EmployerID == user.UserID);
            if (employer != null)
            {
                var vacancies = _context.Vacancies.Where(v => v.EmployerID == employer.EmployerID).ToList();
                foreach (var v in vacancies)
                {
                    _context.CandidateResponses.RemoveRange(_context.CandidateResponses.Where(cr => cr.VacancyID == v.VacancyID));
                    _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.VacancyID == v.VacancyID));
                    _context.CommissionHistories.RemoveRange(_context.CommissionHistories.Where(ch => ch.VacancyID == v.VacancyID));
                }
                _context.Vacancies.RemoveRange(vacancies);
                _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.EmployerID == employer.EmployerID));
                _context.CommissionHistories.RemoveRange(_context.CommissionHistories.Where(ch => ch.EmployerID == employer.EmployerID));
                _context.Employers.Remove(employer);
            }
            _context.Users.Remove(user);
        }

        private void DeleteCandidate()
        {
            var candidate = _context.Candidates.Find(_deleteItemId);
            if (candidate == null) return;

            var resumes = _context.Resumes.Where(r => r.CandidateID == candidate.CandidateID).ToList();
            foreach (var r in resumes)
            {
                _context.CandidateResponses.RemoveRange(_context.CandidateResponses.Where(cr => cr.ResumeID == r.ResumeID));
                _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.ResumeID == r.ResumeID));
            }
            _context.Resumes.RemoveRange(resumes);
            _context.CandidateResponses.RemoveRange(_context.CandidateResponses.Where(cr => cr.CandidateID == candidate.CandidateID));
            _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.CandidateID == candidate.CandidateID));
            _context.CommissionHistories.RemoveRange(_context.CommissionHistories.Where(ch => ch.CandidateID == candidate.CandidateID));
            _context.Candidates.Remove(candidate);
        }

        private void DeleteEmployer()
        {
            var employer = _context.Employers.Find(_deleteItemId);
            if (employer == null) return;

            var vacancies = _context.Vacancies.Where(v => v.EmployerID == employer.EmployerID).ToList();
            foreach (var v in vacancies)
            {
                _context.CandidateResponses.RemoveRange(_context.CandidateResponses.Where(cr => cr.VacancyID == v.VacancyID));
                _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.VacancyID == v.VacancyID));
                _context.CommissionHistories.RemoveRange(_context.CommissionHistories.Where(ch => ch.VacancyID == v.VacancyID));
            }
            _context.Vacancies.RemoveRange(vacancies);
            _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.EmployerID == employer.EmployerID));
            _context.CommissionHistories.RemoveRange(_context.CommissionHistories.Where(ch => ch.EmployerID == employer.EmployerID));
            _context.Employers.Remove(employer);
        }

        private void DeleteVacancy()
        {
            var vacancy = _context.Vacancies.Find(_deleteItemId);
            if (vacancy == null) return;

            _context.CandidateResponses.RemoveRange(_context.CandidateResponses.Where(cr => cr.VacancyID == vacancy.VacancyID));
            _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.VacancyID == vacancy.VacancyID));
            _context.CommissionHistories.RemoveRange(_context.CommissionHistories.Where(ch => ch.VacancyID == vacancy.VacancyID));
            _context.Vacancies.Remove(vacancy);
        }

        private void DeleteResume()
        {
            var resume = _context.Resumes.Find(_deleteItemId);
            if (resume == null) return;

            _context.CandidateResponses.RemoveRange(_context.CandidateResponses.Where(cr => cr.ResumeID == resume.ResumeID));
            _context.EmployerResponses.RemoveRange(_context.EmployerResponses.Where(er => er.ResumeID == resume.ResumeID));
            _context.Resumes.Remove(resume);
        }

        private void DeleteResponse() => _context.CandidateResponses.Remove(_context.CandidateResponses.Find(_deleteItemId));
        private void DeleteCommission() => _context.CommissionHistories.Remove(_context.CommissionHistories.Find(_deleteItemId));

        private void CancelDelete_Click(object sender, RoutedEventArgs e)
        {
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            DataPanel.Visibility = Visibility.Visible;
            _deleteItemId = 0;
        }

        private void CancelEdit_Click(object sender, RoutedEventArgs e)
        {
            SaveButton.Click -= ApplyCommissionFilters_Click;
            SaveButton.Click += SaveButton_Click;
            HidePanels();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
            LoadStatisticsCards();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string search = SearchTextBox.Text.ToLower();
            if (string.IsNullOrWhiteSpace(search))
            {
                LoadData();
                return;
            }

            var allItems = AdminDataGrid.ItemsSource as List<DataCardViewModel>;
            if (allItems == null) return;

            var filteredList = allItems.Where(item =>
                item.Title.ToLower().Contains(search) ||
                item.Subtitle.ToLower().Contains(search) ||
                item.Info1.ToLower().Contains(search) ||
                item.Info2.ToLower().Contains(search) ||
                item.Description.ToLower().Contains(search)
            ).ToList();

            AdminDataGrid.ItemsSource = filteredList;
            PageSubtitle.Text = $"Найдено: {filteredList.Count}";
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                App.Current.Properties["CurrentUser"] = null;
                Manager.MainFrame.Navigate(new LoginPage());
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // ПОЛНОСТЬЮ ПЕРЕРАБОТАННАЯ СТАТИСТИКА
        // ═══════════════════════════════════════════════════════════════

        private void StatisticsButton_Click(object sender, RoutedEventArgs e)
        {
            _currentSection = "Statistics";

            UsersMenu.Style = (Style)FindResource("MenuButton");
            CandidatesMenu.Style = (Style)FindResource("MenuButton");
            EmployersMenu.Style = (Style)FindResource("MenuButton");
            VacanciesMenu.Style = (Style)FindResource("MenuButton");
            ResumesMenu.Style = (Style)FindResource("MenuButton");
            ResponsesMenu.Style = (Style)FindResource("MenuButton");
            CommissionsMenu.Style = (Style)FindResource("MenuButton");

            AddButton.Visibility = Visibility.Collapsed;
            FilterButton.Visibility = Visibility.Collapsed;
            SearchTextBox.Visibility = Visibility.Collapsed;

            PageTitle.Text = "📊 Аналитическая панель";
            PageSubtitle.Text = "Полная статистика системы за выбранный период";

            DataPanel.Visibility = Visibility.Collapsed;
            StatisticsPanel.Visibility = Visibility.Visible;
            EditPanel.Visibility = Visibility.Collapsed;
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            CommissionProfitPanel.Visibility = Visibility.Collapsed;

            LoadAllStatistics();
        }

        private async void LoadAllStatistics()
        {
            try
            {
                ShowStatisticsLoading(true);

                await Task.Run(() =>
                {
                    Dispatcher.Invoke(() => LoadGeneralStatistics());
                    Dispatcher.Invoke(() => LoadFinancialStatistics());
                    Dispatcher.Invoke(() => LoadUserRoleDistribution());
                    Dispatcher.Invoke(() => LoadResponseStatusStatistics());
                    Dispatcher.Invoke(() => LoadTopEmployersByCommission());
                    Dispatcher.Invoke(() => LoadTopVacanciesByResponses());
                    Dispatcher.Invoke(() => LoadTopCandidatesByHires());
                    Dispatcher.Invoke(() => LoadMonthlyDynamics());
                });

                ShowStatisticsLoading(false);
            }
            catch (Exception ex)
            {
                ShowStatisticsLoading(false);
                MessageBox.Show($"Ошибка загрузки статистики: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowStatisticsLoading(bool isLoading)
        {
            if (isLoading)
            {
                PageSubtitle.Text = "⏳ Загрузка данных...";
            }
            else
            {
                PageSubtitle.Text = _statsDateFrom.HasValue || _statsDateTo.HasValue
                    ? $"Статистика за период: {(_statsDateFrom?.ToString("dd.MM.yyyy") ?? "все время")} - {(_statsDateTo?.ToString("dd.MM.yyyy") ?? "настоящее время")}"
                    : "Полная статистика системы";
            }
        }

        private void LoadGeneralStatistics()
        {
            var usersQuery = _context.Users.AsQueryable();
            var candidatesQuery = _context.Candidates.AsQueryable();
            var employersQuery = _context.Employers.AsQueryable();
            var vacanciesQuery = _context.Vacancies.AsQueryable();
            var resumesQuery = _context.Resumes.AsQueryable();
            var responsesQuery = _context.CandidateResponses.AsQueryable();

            if (_statsDateFrom.HasValue)
            {
                usersQuery = usersQuery.Where(u => u.RegistrationDate >= _statsDateFrom.Value);
                candidatesQuery = candidatesQuery.Where(c => c.CreatedDate >= _statsDateFrom.Value);
                employersQuery = employersQuery.Where(e => e.CreatedDate >= _statsDateFrom.Value);
                vacanciesQuery = vacanciesQuery.Where(v => v.CreatedDate >= _statsDateFrom.Value);
                resumesQuery = resumesQuery.Where(r => r.CreatedDate >= _statsDateFrom.Value);
                responsesQuery = responsesQuery.Where(r => r.ResponseDate >= _statsDateFrom.Value);
            }
            if (_statsDateTo.HasValue)
            {
                var dateToEnd = _statsDateTo.Value.AddDays(1).AddSeconds(-1);
                usersQuery = usersQuery.Where(u => u.RegistrationDate <= dateToEnd);
                candidatesQuery = candidatesQuery.Where(c => c.CreatedDate <= dateToEnd);
                employersQuery = employersQuery.Where(e => e.CreatedDate <= dateToEnd);
                vacanciesQuery = vacanciesQuery.Where(v => v.CreatedDate <= dateToEnd);
                resumesQuery = resumesQuery.Where(r => r.CreatedDate <= dateToEnd);
                responsesQuery = responsesQuery.Where(r => r.ResponseDate <= dateToEnd);
            }

            int totalUsers = usersQuery.Count();
            int totalCandidates = candidatesQuery.Count();
            int totalEmployers = employersQuery.Count();
            int totalVacancies = vacanciesQuery.Count();
            int activeVacancies = vacanciesQuery.Count(v => v.IsActive == true);
            int totalResumes = resumesQuery.Count();
            int visibleResumes = resumesQuery.Count(r => r.IsVisible == true);
            int totalResponses = responsesQuery.Count();
            int successfulResponses = responsesQuery.Count(r => r.Status == "Принят на работу");

            Dispatcher.Invoke(() =>
            {
                StatsTotalUsers.Text = totalUsers.ToString("N0");
                StatsTotalCandidates.Text = totalCandidates.ToString("N0");
                StatsTotalEmployers.Text = totalEmployers.ToString("N0");
                StatsTotalVacancies.Text = totalVacancies.ToString("N0");
                StatsActiveVacancies.Text = $"{activeVacancies:N0} активных";
                StatsTotalResumes.Text = totalResumes.ToString("N0");
                StatsActiveResumes.Text = $"{visibleResumes:N0} видимых";
                StatsTotalResponses.Text = totalResponses.ToString("N0");
                StatsSuccessfulResponses.Text = $"{successfulResponses:N0} успешных";

                var lastMonth = DateTime.Now.AddDays(-30);
                int newUsersLastMonth = _context.Users.Count(u => u.RegistrationDate >= lastMonth);
                int newCandidatesLastMonth = _context.Candidates.Count(c => c.CreatedDate >= lastMonth);
                int newEmployersLastMonth = _context.Employers.Count(e => e.CreatedDate >= lastMonth);

                StatsNewUsers.Text = $"+{newUsersLastMonth:N0} за 30 дней";
                StatsNewCandidates.Text = $"+{newCandidatesLastMonth:N0} за 30 дней";
                StatsNewEmployers.Text = $"+{newEmployersLastMonth:N0} за 30 дней";
            });
        }

        private void LoadFinancialStatistics()
        {
            var commissionsQuery = _context.CommissionHistories.AsQueryable();

            if (_statsDateFrom.HasValue)
                commissionsQuery = commissionsQuery.Where(c => c.CreatedDate >= _statsDateFrom.Value);
            if (_statsDateTo.HasValue)
                commissionsQuery = commissionsQuery.Where(c => c.CreatedDate <= _statsDateTo.Value.AddDays(1).AddSeconds(-1));

            var commissions = commissionsQuery.ToList();

            decimal totalAmount = commissions.Sum(c => c.CommissionAmount);
            decimal paidAmount = commissions.Where(c => c.PaymentStatus == "Оплачено").Sum(c => c.CommissionAmount);
            decimal pendingAmount = commissions.Where(c => c.PaymentStatus == "Ожидает оплаты").Sum(c => c.CommissionAmount);
            decimal cancelledAmount = commissions.Where(c => c.PaymentStatus == "Отменено").Sum(c => c.CommissionAmount);

            int totalCount = commissions.Count;
            int paidCount = commissions.Count(c => c.PaymentStatus == "Оплачено");
            int pendingCount = commissions.Count(c => c.PaymentStatus == "Ожидает оплаты");
            int cancelledCount = commissions.Count(c => c.PaymentStatus == "Отменено");

            decimal avgAmount = totalCount > 0 ? commissions.Average(c => c.CommissionAmount) : 0;
            decimal minAmount = totalCount > 0 ? commissions.Min(c => c.CommissionAmount) : 0;
            decimal maxAmount = totalCount > 0 ? commissions.Max(c => c.CommissionAmount) : 0;
            decimal paymentRate = totalCount > 0 ? (decimal)paidCount / totalCount * 100 : 0;

            Dispatcher.Invoke(() =>
            {
                StatsTotalCommission.Text = $"{totalAmount:N0} ₽";
                StatsPaidCommission.Text = $"{paidAmount:N0} ₽";
                StatsPendingCommission.Text = $"{pendingAmount:N0} ₽";
                StatsCancelledCommission.Text = $"{cancelledAmount:N0} ₽";

                StatsCommissionCount.Text = $"{totalCount:N0} комиссий";
                StatsPaidCount.Text = $"{paidCount:N0} платежей";
                StatsPendingCount.Text = $"{pendingCount:N0} платежей";
                StatsCancelledCount.Text = $"{cancelledCount:N0} платежей";

                StatsAvgCommission.Text = $"{avgAmount:N0} ₽";
                StatsMinCommission.Text = $"{minAmount:N0} ₽";
                StatsMaxCommission.Text = $"{maxAmount:N0} ₽";
                StatsPaymentRate.Text = $"{paymentRate:F1}%";
            });
        }

        private void LoadUserRoleDistribution()
        {
            var usersQuery = _context.Users.AsQueryable();

            if (_statsDateFrom.HasValue)
                usersQuery = usersQuery.Where(u => u.RegistrationDate >= _statsDateFrom.Value);
            if (_statsDateTo.HasValue)
                usersQuery = usersQuery.Where(u => u.RegistrationDate <= _statsDateTo.Value.AddDays(1).AddSeconds(-1));

            int adminCount = usersQuery.Count(u => u.RoleID == 1);
            int candidateCount = usersQuery.Count(u => u.RoleID == 2);
            int employerCount = usersQuery.Count(u => u.RoleID == 3);
            int activeCount = usersQuery.Count(u => u.IsActive == true);
            int inactiveCount = usersQuery.Count(u => u.IsActive == false || u.IsActive == null);

            Dispatcher.Invoke(() =>
            {
                StatsAdminCount.Text = adminCount.ToString("N0");
                StatsCandidateCount.Text = candidateCount.ToString("N0");
                StatsEmployerCount.Text = employerCount.ToString("N0");
                StatsActiveUsersCount.Text = activeCount.ToString("N0");
                StatsInactiveUsersCount.Text = inactiveCount.ToString("N0");
            });
        }

        private void LoadResponseStatusStatistics()
        {
            var responsesQuery = _context.CandidateResponses.AsQueryable();

            if (_statsDateFrom.HasValue)
                responsesQuery = responsesQuery.Where(r => r.ResponseDate >= _statsDateFrom.Value);
            if (_statsDateTo.HasValue)
                responsesQuery = responsesQuery.Where(r => r.ResponseDate <= _statsDateTo.Value.AddDays(1).AddSeconds(-1));

            int newCount = responsesQuery.Count(r => r.Status == "Новый");
            int reviewCount = responsesQuery.Count(r => r.Status == "На рассмотрении" || r.Status == "Рассматривается");
            int interviewCount = responsesQuery.Count(r => r.Status == "Приглашен на собеседование");
            int hiredCount = responsesQuery.Count(r => r.Status == "Принят на работу");
            int rejectedCount = responsesQuery.Count(r => r.Status == "Отклонен" || r.Status == "Отклонено");

            Dispatcher.Invoke(() =>
            {
                StatsStatusNew.Text = newCount.ToString("N0");
                StatsStatusReview.Text = reviewCount.ToString("N0");
                StatsStatusInterview.Text = interviewCount.ToString("N0");
                StatsStatusHired.Text = hiredCount.ToString("N0");
                StatsStatusRejected.Text = rejectedCount.ToString("N0");
            });
        }

        private void LoadTopEmployersByCommission()
        {
            var commissionsQuery = _context.CommissionHistories.AsQueryable();

            if (_statsDateFrom.HasValue)
                commissionsQuery = commissionsQuery.Where(c => c.CreatedDate >= _statsDateFrom.Value);
            if (_statsDateTo.HasValue)
                commissionsQuery = commissionsQuery.Where(c => c.CreatedDate <= _statsDateTo.Value.AddDays(1).AddSeconds(-1));

            var data = commissionsQuery
                .GroupBy(c => new { c.EmployerID, c.Employer.CompanyName, c.Employer.INN })
                .Select(g => new TopEmployerViewModel
                {
                    CompanyName = g.Key.CompanyName,
                    INN = g.Key.INN,
                    CommissionCount = g.Count(),
                    TotalAmount = g.Sum(c => c.CommissionAmount),
                    PaidAmount = g.Where(c => c.PaymentStatus == "Оплачено").Sum(c => c.CommissionAmount)
                })
                .OrderByDescending(x => x.TotalAmount)
                .Take(10)
                .ToList();

            for (int i = 0; i < data.Count; i++)
                data[i].Rank = i + 1;

            Dispatcher.Invoke(() => StatsTopEmployersGrid.ItemsSource = data);
        }

        private void LoadTopVacanciesByResponses()
        {
            var responsesQuery = _context.CandidateResponses.AsQueryable();

            if (_statsDateFrom.HasValue)
                responsesQuery = responsesQuery.Where(r => r.ResponseDate >= _statsDateFrom.Value);
            if (_statsDateTo.HasValue)
                responsesQuery = responsesQuery.Where(r => r.ResponseDate <= _statsDateTo.Value.AddDays(1).AddSeconds(-1));

            // Получаем данные из БД без форматирования
            var rawData = responsesQuery
                .GroupBy(r => new { r.VacancyID, r.Vacancy.Position, r.Vacancy.Employer.CompanyName, r.Vacancy.SalaryFrom, r.Vacancy.SalaryTo })
                .Select(g => new
                {
                    Position = g.Key.Position,
                    CompanyName = g.Key.CompanyName,
                    ResponseCount = g.Count(),
                    HiredCount = g.Count(r => r.Status == "Принят на работу"),
                    SalaryFrom = g.Key.SalaryFrom,
                    SalaryTo = g.Key.SalaryTo
                })
                .OrderByDescending(x => x.HiredCount)
                .ThenByDescending(x => x.ResponseCount)
                .Take(10)
                .ToList();

            // Форматируем данные после получения из БД
            var data = rawData.Select((item, index) => new TopVacancyViewModel
            {
                Rank = index + 1,
                Position = item.Position,
                CompanyName = item.CompanyName,
                ResponseCount = item.ResponseCount,
                HiredCount = item.HiredCount,
                SalaryRange = FormatSalaryRange(item.SalaryFrom, item.SalaryTo)
            }).ToList();

            Dispatcher.Invoke(() => StatsTopVacanciesGrid.ItemsSource = data);
        }

        private void LoadTopCandidatesByHires()
        {
            var commissionsQuery = _context.CommissionHistories.AsQueryable();

            if (_statsDateFrom.HasValue)
                commissionsQuery = commissionsQuery.Where(c => c.CreatedDate >= _statsDateFrom.Value);
            if (_statsDateTo.HasValue)
                commissionsQuery = commissionsQuery.Where(c => c.CreatedDate <= _statsDateTo.Value.AddDays(1).AddSeconds(-1));

            var data = commissionsQuery
                .GroupBy(c => new { c.CandidateID, c.Candidate.FullName, c.Candidate.Profession })
                .Select(g => new TopCandidateViewModel
                {
                    FullName = g.Key.FullName,
                    Profession = g.Key.Profession,
                    HireCount = g.Select(x => x.ResponseID).Distinct().Count(),
                    CommissionCount = g.Count(),
                    TotalCommission = g.Sum(x => x.CommissionAmount)
                })
                .OrderByDescending(x => x.HireCount)
                .ThenByDescending(x => x.TotalCommission)
                .Take(10)
                .ToList();

            for (int i = 0; i < data.Count; i++)
                data[i].Rank = i + 1;

            Dispatcher.Invoke(() => StatsTopCandidatesGrid.ItemsSource = data);
        }

        private void LoadMonthlyDynamics()
        {
            DateTime startDate = _statsDateFrom ?? new DateTime(DateTime.Now.Year, 1, 1);
            DateTime endDate = _statsDateTo ?? DateTime.Now;

            var monthlyData = new List<MonthlyStatViewModel>();
            var current = new DateTime(startDate.Year, startDate.Month, 1);
            var lastMonth = new DateTime(endDate.Year, endDate.Month, 1);

            while (current <= lastMonth)
            {
                var monthStart = current;
                var monthEnd = current.AddMonths(1).AddSeconds(-1);

                int newUsers = _context.Users.Count(u => u.RegistrationDate >= monthStart && u.RegistrationDate <= monthEnd);
                int newResponses = _context.CandidateResponses.Count(r => r.ResponseDate >= monthStart && r.ResponseDate <= monthEnd);
                int newHires = _context.CandidateResponses.Count(r => r.ResponseDate >= monthStart && r.ResponseDate <= monthEnd && r.Status == "Принят на работу");
                int newCommissions = _context.CommissionHistories.Count(c => c.CreatedDate >= monthStart && c.CreatedDate <= monthEnd);
                decimal commissionAmount = _context.CommissionHistories.Where(c => c.CreatedDate >= monthStart && c.CreatedDate <= monthEnd).Sum(c => (decimal?)c.CommissionAmount) ?? 0;

                monthlyData.Add(new MonthlyStatViewModel
                {
                    Period = current.ToString("MMMM yyyy"),
                    NewUsers = newUsers,
                    NewResponses = newResponses,
                    NewHires = newHires,
                    NewCommissions = newCommissions,
                    CommissionAmount = commissionAmount
                });

                current = current.AddMonths(1);
            }

            if (!_statsDateFrom.HasValue && !_statsDateTo.HasValue)
                monthlyData = monthlyData.OrderByDescending(m => m.Period).Take(12).OrderBy(m => m.Period).ToList();

            Dispatcher.Invoke(() => StatsMonthlyGrid.ItemsSource = monthlyData);
        }

        // Вспомогательный метод для форматирования зарплаты (без LINQ to Entities)
        private string FormatSalaryRange(decimal? salaryFrom, decimal? salaryTo)
        {
            if (salaryFrom.HasValue && salaryTo.HasValue)
                return $"{salaryFrom:N0} - {salaryTo:N0} ₽";
            if (salaryFrom.HasValue)
                return $"от {salaryFrom:N0} ₽";
            if (salaryTo.HasValue)
                return $"до {salaryTo:N0} ₽";
            return "По договоренности";
        }

        // Применение фильтров статистики
        private void ApplyStatsFilter_Click(object sender, RoutedEventArgs e)
        {
            _statsDateFrom = StatsDateFrom.SelectedDate;
            _statsDateTo = StatsDateTo.SelectedDate;

            if (_statsDateFrom.HasValue && _statsDateTo.HasValue && _statsDateFrom > _statsDateTo)
            {
                MessageBox.Show("Дата 'с' не может быть позже даты 'по'.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            StatsFilterIndicator.Visibility = (_statsDateFrom.HasValue || _statsDateTo.HasValue) ? Visibility.Visible : Visibility.Collapsed;
            LoadAllStatistics();
        }

        private void ResetStatsFilter_Click(object sender, RoutedEventArgs e)
        {
            StatsDateFrom.SelectedDate = null;
            StatsDateTo.SelectedDate = null;
            _statsDateFrom = null;
            _statsDateTo = null;
            StatsFilterIndicator.Visibility = Visibility.Collapsed;
            LoadAllStatistics();
        }

        // ViewModel классы для статистики
        public class TopEmployerViewModel
        {
            public int Rank { get; set; }
            public string CompanyName { get; set; }
            public string INN { get; set; }
            public int CommissionCount { get; set; }
            public decimal TotalAmount { get; set; }
            public decimal PaidAmount { get; set; }
        }

        public class TopVacancyViewModel
        {
            public int Rank { get; set; }
            public string Position { get; set; }
            public string CompanyName { get; set; }
            public int ResponseCount { get; set; }
            public int HiredCount { get; set; }
            public string SalaryRange { get; set; }
        }

        public class TopCandidateViewModel
        {
            public int Rank { get; set; }
            public string FullName { get; set; }
            public string Profession { get; set; }
            public int HireCount { get; set; }
            public int CommissionCount { get; set; }
            public decimal TotalCommission { get; set; }
        }

        public class MonthlyStatViewModel
        {
            public string Period { get; set; }
            public int NewUsers { get; set; }
            public int NewResponses { get; set; }
            public int NewHires { get; set; }
            public int NewCommissions { get; set; }
            public decimal CommissionAmount { get; set; }
        }
    }
}
﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Buro.Entity;
using System.Data.Entity;

namespace Buro.Pages
{
    public partial class LoginPage : Page
    {
        private EmploymentBureauEntities _context;

        public LoginPage()
        {
            InitializeComponent();
            _context = EmploymentBureauEntities.GetContext();
            Loaded += LoginPage_Loaded;
        }

        private void LoginPage_Loaded(object sender, RoutedEventArgs e)
        {
            // Анимация появления формы
            var fadeIn = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(500),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };
            LoginForm.BeginAnimation(OpacityProperty, fadeIn);

            var slideIn = new ThicknessAnimation
            {
                From = new Thickness(0, 30, 0, 0),
                To = new Thickness(0),
                Duration = TimeSpan.FromMilliseconds(500),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };
            LoginForm.BeginAnimation(MarginProperty, slideIn);
        }

        private void EmailTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            EmailPlaceholder.Visibility = Visibility.Collapsed;
            EmailError.Visibility = Visibility.Collapsed;
            HideError();
        }

        private void EmailTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                EmailPlaceholder.Visibility = Visibility.Visible;
            }
            ValidateEmail();
        }

        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordPlaceholder.Visibility = Visibility.Collapsed;
            PasswordError.Visibility = Visibility.Collapsed;
            HideError();
        }

        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                PasswordPlaceholder.Visibility = Visibility.Visible;
            }
            ValidatePassword();
        }

        private bool ValidateEmail()
        {
            string email = EmailTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(email))
            {
                EmailError.Text = "Email обязателен для заполнения";
                EmailError.Visibility = Visibility.Visible;
                return false;
            }

            if (!email.Contains("@") || !email.Contains("."))
            {
                EmailError.Text = "Введите корректный email";
                EmailError.Visibility = Visibility.Visible;
                return false;
            }

            return true;
        }

        private bool ValidatePassword()
        {
            if (string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                PasswordError.Text = "Пароль обязателен для заполнения";
                PasswordError.Visibility = Visibility.Visible;
                return false;
            }

            if (PasswordBox.Password.Length < 3)
            {
                PasswordError.Text = "Пароль слишком короткий";
                PasswordError.Visibility = Visibility.Visible;
                return false;
            }

            return true;
        }

        private void ShowError(string message)
        {
            ErrorMessage.Text = message;
            ErrorBorder.Visibility = Visibility.Visible;

            var shake = new DoubleAnimation
            {
                From = 0,
                To = 10,
                Duration = TimeSpan.FromMilliseconds(50),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(3)
            };
            ErrorBorder.BeginAnimation(TranslateTransform.XProperty, shake);
        }

        private void HideError()
        {
            ErrorBorder.Visibility = Visibility.Collapsed;
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            bool isEmailValid = ValidateEmail();
            bool isPasswordValid = ValidatePassword();

            if (!isEmailValid || !isPasswordValid)
                return;

            LoginButton.IsEnabled = false;
            LoginButton.Content = "Вход...";
            LoadingIndicator.Visibility = Visibility.Visible;
            HideError();

            try
            {
                string email = EmailTextBox.Text.Trim();
                string passwordHash = PasswordBox.Password;

                // Используем Include для загрузки связанных данных
                var user = await _context.Users
                    .Include(u => u.Role)
                    .FirstOrDefaultAsync(u => u.Email == email && u.PasswordHash == passwordHash && u.IsActive == true);

                if (user == null)
                {
                    ShowError("Неверный email или пароль. Пожалуйста, проверьте введённые данные.");
                    PasswordBox.Clear();
                    PasswordBox.Focus();
                    return;
                }

                // Сохраняем пользователя в свойства приложения
                App.Current.Properties["CurrentUser"] = user;

                // Проверяем роль
                if (user.Role == null)
                {
                    ShowError("Ошибка: у пользователя не назначена роль.");
                    return;
                }

                string roleName = user.Role.RoleName?.Trim();

                // Проверяем, есть ли ожидающие элементы для открытия
                bool hasPendingVacancy = App.Current.Properties.Contains("PendingVacancyId") && App.Current.Properties["PendingVacancyId"] != null;
                bool hasPendingResume = App.Current.Properties.Contains("PendingResumeId") && App.Current.Properties["PendingResumeId"] != null;

                // Сохраняем ID до перехода
                int? pendingVacancyId = hasPendingVacancy ? (int)App.Current.Properties["PendingVacancyId"] : (int?)null;
                int? pendingResumeId = hasPendingResume ? (int)App.Current.Properties["PendingResumeId"] : (int?)null;

                // Очищаем ожидающие элементы перед обработкой (чтобы не зациклить)
                if (hasPendingVacancy) App.Current.Properties["PendingVacancyId"] = null;
                if (hasPendingResume) App.Current.Properties["PendingResumeId"] = null;

                // Очищаем историю навигации для безопасности
                while (Manager.MainFrame.CanGoBack)
                {
                    Manager.MainFrame.RemoveBackEntry();
                }

                // Обработка в зависимости от роли и ожидаемых элементов
                if (roleName == "Candidate")
                {
                    // Для соискателя
                    var candidatePage = new CandidateDashboardPage();

                    if (pendingVacancyId.HasValue)
                    {
                        // Сначала переходим на страницу, потом открываем вакансию
                        Manager.MainFrame.Navigate(candidatePage);
                        await System.Threading.Tasks.Task.Delay(300);
                        candidatePage.ShowVacancyDetails(pendingVacancyId.Value);
                    }
                    else
                    {
                        Manager.MainFrame.Navigate(candidatePage);
                    }
                }
                else if (roleName == "Employer")
                {
                    // Проверяем существование работодателя в БД
                    var employer = await _context.Employers.FindAsync(user.UserID);
                    if (employer == null)
                    {
                        ShowError("Ошибка: данные работодателя не найдены. Обратитесь к администратору.");
                        return;
                    }

                    var employerPage = new EmployerDashboardPage();

                    if (pendingResumeId.HasValue)
                    {
                        Manager.MainFrame.Navigate(employerPage);
                        await System.Threading.Tasks.Task.Delay(300);
                        employerPage.ShowResumeDetails(pendingResumeId.Value);
                    }
                    else
                    {
                        Manager.MainFrame.Navigate(employerPage);
                    }
                }
                else if (roleName == "Admin")
                {
                    // Для админа - просто переходим на панель админа
                    Manager.MainFrame.Navigate(new AdminDashboardPage());
                }
                else
                {
                    ShowError($"Неизвестная роль пользователя: {roleName}");
                    return;
                }
            }
            catch (Exception ex)
            {
                ShowError("Ошибка подключения к серверу. Пожалуйста, попробуйте позже.");
                System.Diagnostics.Debug.WriteLine($"Login error: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"Stack trace: {ex.StackTrace}");
            }
            finally
            {
                LoginButton.IsEnabled = true;
                LoginButton.Content = "Войти";
                LoadingIndicator.Visibility = Visibility.Collapsed;
            }
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new RegisterPage());
        }

        private void BackToMain_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем ожидающие элементы при возврате на главную
            App.Current.Properties["PendingVacancyId"] = null;
            App.Current.Properties["PendingResumeId"] = null;
            Manager.MainFrame.Navigate(new MainPage());
        }

        protected override void OnKeyDown(System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                LoginButton_Click(null, null);
            }
            base.OnKeyDown(e);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.JobSeeker
{
    /// <summary>
    /// Логика взаимодействия для EmployerResponsesPage.xaml
    /// </summary>
    public partial class EmployerResponsesPage : Page
    {
        public EmployerResponsesPage()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            var filters = new List<string>
            {
                "Все отклики",
                "Новые",
                "Приглашения",
                "Сообщения",
                "Отказы",
                "Архив"
            };

            FilterComboBox.ItemsSource = filters;
            FilterComboBox.SelectedIndex = 0;
        }

        private void AcceptInvitationButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Принять приглашение на собеседование?\n\n" +
                                       "Работодатель получит уведомление о вашем согласии.",
                                       "Принятие приглашения",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Приглашение принято! Работодатель получил уведомление.\n\n" +
                              "Не забудьте подготовиться к собеседованию.",
                              "Приглашение принято",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void RescheduleButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет окно для переноса даты собеседования",
                          "Перенос собеседования",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void DeclineInvitationButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Отклонить приглашение на собеседование?\n\n" +
                                       "Работодатель получит уведомление об отказе.",
                                       "Отклонение приглашения",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Приглашение отклонено. Работодатель получил уведомление.",
                              "Приглашение отклонено",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void ReplyButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет окно для ответа работодателю",
                          "Ответ работодателю",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Подробная информация о предложении:\n\n" +
                          "Компания: SoftDev Company\n" +
                          "Должность: Менеджер проектов\n" +
                          "Зарплата: 120 000 - 150 000 руб.\n" +
                          "Тип занятости: Полная\n" +
                          "Локация: Удаленно\n" +
                          "Описание: Управление IT-проектами, команда 5-10 человек",
                          "Подробности предложения",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void DeleteResponseButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Удалить этот отклик из списка?\n\n" +
                                       "Отклик будет перемещен в архив.",
                                       "Удаление отклика",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Отклик удален и перемещен в архив.",
                              "Отклик удален",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        // Метод для обновления статистики
        public void UpdateStatistics(int total, int newResponses, int invitations, int rejections)
        {
            // В реальном приложении здесь будет обновление UI
        }
    }
}


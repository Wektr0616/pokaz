﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Buro.Entity;
using System.Data.Entity;
using System.Threading.Tasks;

namespace Buro.Pages
{
    public partial class MainPage : Page
    {
        private EmploymentBureauEntities _context;
        private List<PublicVacancyViewModel> _allVacancies = new List<PublicVacancyViewModel>();
        private List<PublicResumeViewModel> _allResumes = new List<PublicResumeViewModel>();

        public MainPage()
        {
            InitializeComponent();
            _context = EmploymentBureauEntities.GetContext();
            Loaded += MainPage_Loaded;
        }

        private async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            await LoadPublicDataAsync();
        }

        #region Загрузка данных

        private async Task LoadPublicDataAsync()
        {
            try
            {
                await LoadPublicVacanciesAsync();
                await LoadPublicResumesAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadPublicVacanciesAsync()
        {
            var vacanciesRaw = await _context.Vacancies
                .Where(v => v.IsActive == true)
                .OrderByDescending(v => v.CreatedDate)
                .Take(50)
                .Select(v => new
                {
                    v.VacancyID,
                    v.Position,
                    CompanyName = v.Employer.CompanyName,
                    v.SalaryFrom,
                    v.SalaryTo,
                    v.City,
                    v.EmploymentType,
                    v.ExperienceRequired,
                    v.Description,
                    v.Requirements
                })
                .ToListAsync();

            _allVacancies = vacanciesRaw.Select(v => new PublicVacancyViewModel
            {
                VacancyID = v.VacancyID,
                Position = v.Position,
                CompanyName = v.CompanyName,
                SalaryRange = FormatSalary(v.SalaryFrom, v.SalaryTo),
                City = v.City ?? "Не указан",
                EmploymentType = v.EmploymentType ?? "Не указан",
                ExperienceText = v.ExperienceRequired.HasValue ? $"{v.ExperienceRequired} лет" : "Не требуется",
                Description = v.Description ?? "Описание отсутствует",
                Requirements = v.Requirements ?? "Требования не указаны",
                SalaryFrom = v.SalaryFrom,
                SalaryTo = v.SalaryTo
            }).ToList();

            ApplyVacancyFilters();
        }

        private async Task LoadPublicResumesAsync()
        {
            var resumesRaw = await _context.Resumes
                .Where(r => r.IsVisible == true && r.Status == "Активно")
                .OrderByDescending(r => r.CreatedDate)
                .Take(50)
                .Select(r => new
                {
                    r.ResumeID,
                    CandidateName = r.Candidate.FullName,
                    r.Candidate.Profession,
                    r.Candidate.ExperienceYears,
                    r.SalaryExpectation,
                    r.EmploymentType,
                    r.WorkSchedule,
                    r.Skills,
                    r.ResumeText
                })
                .ToListAsync();

            _allResumes = resumesRaw.Select(r => new PublicResumeViewModel
            {
                ResumeID = r.ResumeID,
                CandidateName = r.CandidateName,
                Profession = r.Profession ?? "Не указана",
                ExperienceText = r.ExperienceYears.HasValue ? $"{r.ExperienceYears} лет" : "Не указан",
                ExperienceYears = r.ExperienceYears,
                SalaryExpectationText = r.SalaryExpectation.HasValue ? $"{r.SalaryExpectation.Value:N0} ₽" : "По договоренности",
                SalaryExpectation = r.SalaryExpectation,
                EmploymentType = r.EmploymentType ?? "Не указан",
                WorkSchedule = r.WorkSchedule ?? "Не указан",
                Skills = r.Skills ?? "Навыки не указаны",
                ResumeText = r.ResumeText ?? "Описание отсутствует"
            }).ToList();

            ApplyResumeFilters();
        }

        private string FormatSalary(decimal? from, decimal? to)
        {
            if (from.HasValue && to.HasValue)
                return $"{from.Value:N0} - {to.Value:N0} ₽";
            if (from.HasValue)
                return $"от {from.Value:N0} ₽";
            if (to.HasValue)
                return $"до {to.Value:N0} ₽";
            return "По договоренности";
        }

        #endregion

        #region Фильтрация вакансий

        private void ApplyVacancyFilters()
        {
            var filtered = _allVacancies.AsEnumerable();

            // Поиск по тексту
            var searchText = VacancySearchText?.Text?.ToLower() ?? "";
            if (!string.IsNullOrWhiteSpace(searchText) && searchText != "должность...")
            {
                filtered = filtered.Where(v =>
                    v.Position.ToLower().Contains(searchText) ||
                    v.CompanyName.ToLower().Contains(searchText));
            }

            // Фильтр по городу
            var selectedCity = VacancyCityFilter?.SelectedItem as ComboBoxItem;
            if (selectedCity != null && selectedCity.Content.ToString() != "Все города")
            {
                var city = selectedCity.Content.ToString();
                filtered = filtered.Where(v => v.City == city);
            }

            // Фильтр по типу занятости
            var selectedType = VacancyTypeFilter?.SelectedItem as ComboBoxItem;
            if (selectedType != null && selectedType.Content.ToString() != "Все типы")
            {
                var type = selectedType.Content.ToString();
                filtered = filtered.Where(v => v.EmploymentType == type);
            }

            // Фильтр по зарплате
            if (decimal.TryParse(VacancySalaryFrom?.Text, out decimal salaryFrom))
            {
                filtered = filtered.Where(v => !v.SalaryTo.HasValue || v.SalaryTo >= salaryFrom);
            }
            if (decimal.TryParse(VacancySalaryTo?.Text, out decimal salaryTo))
            {
                filtered = filtered.Where(v => !v.SalaryFrom.HasValue || v.SalaryFrom <= salaryTo);
            }

            PublicVacanciesDataGrid.ItemsSource = filtered.ToList();
        }

        private void VacancyQuickFilter_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button == null) return;

            // Сброс стилей
            VacancyFilterAll.Style = (Style)FindResource("FilterButton");
            VacancyFilterFullTime.Style = (Style)FindResource("FilterButton");
            VacancyFilterRemote.Style = (Style)FindResource("FilterButton");

            // Установка активного стиля
            button.Style = (Style)FindResource("ActiveFilterButton");

            var tag = button.Tag.ToString();
            var filtered = _allVacancies.AsEnumerable();

            if (tag != "All")
            {
                filtered = filtered.Where(v => v.EmploymentType.Contains(tag));
            }

            PublicVacanciesDataGrid.ItemsSource = filtered.ToList();
        }

        private void ApplyVacancyFilters_Click(object sender, RoutedEventArgs e)
        {
            ApplyVacancyFilters();
        }

        #endregion

        #region Фильтрация резюме

        private void ApplyResumeFilters()
        {
            var filtered = _allResumes.AsEnumerable();

            // Поиск по тексту
            var searchText = ResumeSearchText?.Text?.ToLower() ?? "";
            if (!string.IsNullOrWhiteSpace(searchText) && searchText != "профессия, навыки...")
            {
                filtered = filtered.Where(r =>
                    (r.Profession?.ToLower().Contains(searchText) ?? false) ||
                    (r.Skills?.ToLower().Contains(searchText) ?? false) ||
                    r.CandidateName.ToLower().Contains(searchText));
            }

            // Фильтр по опыту
            var selectedExp = ResumeExpFilter?.SelectedItem as ComboBoxItem;
            if (selectedExp != null)
            {
                var expText = selectedExp.Content.ToString();
                switch (expText)
                {
                    case "Без опыта":
                        filtered = filtered.Where(r => !r.ExperienceYears.HasValue || r.ExperienceYears == 0);
                        break;
                    case "1-3 года":
                        filtered = filtered.Where(r => r.ExperienceYears >= 1 && r.ExperienceYears <= 3);
                        break;
                    case "3-5 лет":
                        filtered = filtered.Where(r => r.ExperienceYears > 3 && r.ExperienceYears <= 5);
                        break;
                    case "5+ лет":
                        filtered = filtered.Where(r => r.ExperienceYears > 5);
                        break;
                }
            }

            // Фильтр по типу занятости
            var selectedType = ResumeTypeFilter?.SelectedItem as ComboBoxItem;
            if (selectedType != null && selectedType.Content.ToString() != "Все типы")
            {
                var type = selectedType.Content.ToString();
                filtered = filtered.Where(r => r.EmploymentType == type);
            }

            // Фильтр по зарплате
            if (decimal.TryParse(ResumeSalaryFrom?.Text, out decimal salaryFrom))
            {
                filtered = filtered.Where(r => !r.SalaryExpectation.HasValue || r.SalaryExpectation >= salaryFrom);
            }
            if (decimal.TryParse(ResumeSalaryTo?.Text, out decimal salaryTo))
            {
                filtered = filtered.Where(r => !r.SalaryExpectation.HasValue || r.SalaryExpectation <= salaryTo);
            }

            PublicResumesDataGrid.ItemsSource = filtered.ToList();
        }

        private void ResumeQuickFilter_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button == null) return;

            // Сброс стилей
            ResumeFilterAll.Style = (Style)FindResource("FilterButton");
            ResumeFilterIT.Style = (Style)FindResource("FilterButton");
            ResumeFilterManager.Style = (Style)FindResource("FilterButton");

            // Установка активного стиля
            button.Style = (Style)FindResource("ActiveFilterButton");

            var tag = button.Tag.ToString();
            var filtered = _allResumes.AsEnumerable();

            switch (tag)
            {
                case "IT":
                    filtered = filtered.Where(r =>
                        (r.Profession?.ToLower().Contains("программист") ?? false) ||
                        (r.Profession?.ToLower().Contains("разработчик") ?? false) ||
                        (r.Profession?.ToLower().Contains("developer") ?? false) ||
                        (r.Skills?.ToLower().Contains("c#") ?? false) ||
                        (r.Skills?.ToLower().Contains("java") ?? false) ||
                        (r.Skills?.ToLower().Contains("python") ?? false));
                    break;
                case "Manager":
                    filtered = filtered.Where(r =>
                        (r.Profession?.ToLower().Contains("менеджер") ?? false) ||
                        (r.Profession?.ToLower().Contains("manager") ?? false) ||
                        (r.Profession?.ToLower().Contains("руководитель") ?? false));
                    break;
            }

            PublicResumesDataGrid.ItemsSource = filtered.ToList();
        }

        private void ApplyResumeFilters_Click(object sender, RoutedEventArgs e)
        {
            ApplyResumeFilters();
        }

        #endregion

        #region Просмотр деталей

        private void ViewPublicVacancyDetail_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int vacancyId = (int)button.Tag;

            var vacancy = _allVacancies.FirstOrDefault(v => v.VacancyID == vacancyId);
            if (vacancy == null) return;

            PublicVacancyDetailTitle.Text = vacancy.Position;
            PublicVacancyDetailCompany.Text = vacancy.CompanyName;
            PublicVacancyDetailSalary.Text = vacancy.SalaryRange;
            PublicVacancyDetailCity.Text = vacancy.City;
            PublicVacancyDetailEmployment.Text = vacancy.EmploymentType;
            PublicVacancyDetailDescription.Text = vacancy.Description;

            PublicVacancyDetailPanel.Visibility = Visibility.Visible;
        }

        private void ClosePublicVacancyDetail_Click(object sender, RoutedEventArgs e)
        {
            PublicVacancyDetailPanel.Visibility = Visibility.Collapsed;
        }

        private void ViewPublicResumeDetail_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int resumeId = (int)button.Tag;

            var resume = _allResumes.FirstOrDefault(r => r.ResumeID == resumeId);
            if (resume == null) return;

            PublicResumeDetailName.Text = resume.CandidateName;
            PublicResumeDetailProfession.Text = resume.Profession;
            PublicResumeDetailExperience.Text = resume.ExperienceText;
            PublicResumeDetailSalary.Text = resume.SalaryExpectationText;
            PublicResumeDetailSkills.Text = resume.Skills;

            PublicResumeDetailPanel.Visibility = Visibility.Visible;
        }

        private void ClosePublicResumeDetail_Click(object sender, RoutedEventArgs e)
        {
            PublicResumeDetailPanel.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region Навигация

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new LoginPage());
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new RegisterPage());
        }

        private void ScrollToVacancies_Click(object sender, RoutedEventArgs e)
        {
            VacanciesSection.BringIntoView();
        }

        private void ScrollToResumes_Click(object sender, RoutedEventArgs e)
        {
            ResumesSection.BringIntoView();
        }

        private void ContactButton_Click(object sender, RoutedEventArgs e)
        {
            ContactsSection.BringIntoView();
        }

        #endregion
    }

    #region ViewModels

    public class PublicVacancyViewModel
    {
        public int VacancyID { get; set; }
        public string Position { get; set; }
        public string CompanyName { get; set; }
        public string SalaryRange { get; set; }
        public string City { get; set; }
        public string EmploymentType { get; set; }
        public string ExperienceText { get; set; }
        public string Description { get; set; }
        public string Requirements { get; set; }
        public decimal? SalaryFrom { get; set; }
        public decimal? SalaryTo { get; set; }
    }

    public class PublicResumeViewModel
    {
        public int ResumeID { get; set; }
        public string CandidateName { get; set; }
        public string Profession { get; set; }
        public string ExperienceText { get; set; }
        public int? ExperienceYears { get; set; }
        public string SalaryExpectationText { get; set; }
        public decimal? SalaryExpectation { get; set; }
        public string EmploymentType { get; set; }
        public string WorkSchedule { get; set; }
        public string Skills { get; set; }
        public string ResumeText { get; set; }
    }

    #endregion
}
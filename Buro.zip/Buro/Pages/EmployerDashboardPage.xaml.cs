﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Buro.Entity;
using System.Data.Entity;
using System.Windows.Data;

namespace Buro.Pages
{
    public partial class EmployerDashboardPage : Page
    {
        private EmploymentBureauEntities _context;
        private User _currentUser;
        private Employer _currentEmployer;
        private string _currentView = "Dashboard";
        private int? _editingVacancyId = null;
        private int? _deletingVacancyId = null;
        private int? _payingCommissionId = null;
        private Resume _selectedResume = null;
        private CandidateRespons _selectedResponse = null;

        public EmployerDashboardPage()
        {
            InitializeComponent();
            _context = EmploymentBureauEntities.GetContext();
            Loaded += EmployerDashboardPage_Loaded;
        }

        private async void EmployerDashboardPage_Loaded(object sender, RoutedEventArgs e)
        {
            _currentUser = App.Current.Properties["CurrentUser"] as User;
            if (_currentUser == null)
            {
                Manager.MainFrame.Navigate(new LoginPage());
                return;
            }

            _currentEmployer = await _context.Employers.FindAsync(_currentUser.UserID);
            if (_currentEmployer != null)
            {
                EmployerNameText.Text = _currentEmployer.CompanyName;
            }

            LoadDashboardData();
        }

        #region Навигация по меню

        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;

            ResetMenuStyles();

            button.Style = (Style)FindResource("MenuButtonActive");

            _currentView = button.Tag.ToString();
            SwitchView(_currentView);
        }

        private void ResetMenuStyles()
        {
            DashboardMenu.Style = (Style)FindResource("MenuButton");
            VacanciesMenu.Style = (Style)FindResource("MenuButton");
            ResponsesMenu.Style = (Style)FindResource("MenuButton");
            ResumesMenu.Style = (Style)FindResource("MenuButton");
            ProfileMenu.Style = (Style)FindResource("MenuButton");
            CommissionsMenu.Style = (Style)FindResource("MenuButton");
        }

        private void SwitchView(string viewName)
        {
            HideAllPanels();

            switch (viewName)
            {
                case "Dashboard":
                    DashboardPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Обзор";
                    PageSubtitle.Text = "Добро пожаловать в личный кабинет";
                    LoadDashboardData();
                    break;

                case "Vacancies":
                    VacanciesPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Мои вакансии";
                    PageSubtitle.Text = "Управление активными вакансиями";
                    LoadVacancies();
                    break;

                case "Responses":
                    ResponsesPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Отклики";
                    PageSubtitle.Text = "Управление откликами кандидатов";
                    LoadResponses();
                    break;

                case "Resumes":
                    ResumesPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Поиск резюме";
                    PageSubtitle.Text = "Поиск кандидатов по базе резюме";
                    LoadResumes();
                    break;

                case "Profile":
                    ProfilePanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Профиль компании";
                    PageSubtitle.Text = "Редактирование данных компании";
                    LoadProfile();
                    break;

                case "Commissions":
                    CommissionsPanel.Visibility = Visibility.Visible;
                    PageTitle.Text = "Мои комиссии";
                    PageSubtitle.Text = "Управление комиссиями за успешное трудоустройство";
                    LoadEmployerCommissions();
                    break;
            }
        }

        private void HideAllPanels()
        {
            DashboardPanel.Visibility = Visibility.Collapsed;
            VacanciesPanel.Visibility = Visibility.Collapsed;
            ResponsesPanel.Visibility = Visibility.Collapsed;
            ResumesPanel.Visibility = Visibility.Collapsed;
            ProfilePanel.Visibility = Visibility.Collapsed;
            CommissionsPanel.Visibility = Visibility.Collapsed;
            EditPanel.Visibility = Visibility.Collapsed;
            ViewResponsePanel.Visibility = Visibility.Collapsed;
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            ViewResumePanel.Visibility = Visibility.Collapsed;
            PayConfirmPanel.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region Загрузка данных

        private void LoadDashboardData()
        {
            try
            {
                var vacanciesCount = _context.Vacancies
                    .Where(v => v.EmployerID == _currentUser.UserID && v.IsActive == true)
                    .Count();
                StatVacancies.Text = vacanciesCount.ToString();

                var responsesCount = _context.CandidateResponses
                    .Where(r => r.Vacancy.EmployerID == _currentUser.UserID && r.Status == "Новый")
                    .Count();
                StatResponses.Text = responsesCount.ToString();

                StatViews.Text = "0";

                var hiredCount = _context.CandidateResponses
                    .Where(r => r.Vacancy.EmployerID == _currentUser.UserID && r.Status == "Принят на работу")
                    .Count();
                StatHired.Text = hiredCount.ToString();

                // Обновляем счётчик комиссий к оплате
                var pendingCommission = _context.CommissionHistories
                    .Where(c => c.EmployerID == _currentUser.UserID && c.PaymentStatus == "Ожидает оплаты")
                    .Sum(c => (decimal?)c.CommissionAmount) ?? 0;

                var recentResponsesRaw = _context.CandidateResponses
                    .Where(r => r.Vacancy.EmployerID == _currentUser.UserID)
                    .OrderByDescending(r => r.ResponseDate)
                    .Take(5)
                    .Select(r => new
                    {
                        r.ResponseID,
                        CandidateName = r.Candidate.FullName,
                        VacancyName = r.Vacancy.Position,
                        r.ResponseDate,
                        r.Status
                    })
                    .ToList();

                var recentResponses = recentResponsesRaw.Select(r => new ResponseViewModel
                {
                    ResponseID = r.ResponseID,
                    CandidateName = r.CandidateName,
                    VacancyName = r.VacancyName,
                    ResponseDate = r.ResponseDate,
                    Status = r.Status,
                    StatusColor = GetStatusColor(r.Status)
                }).ToList();

                RecentResponsesGrid.ItemsSource = recentResponses;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadVacancies()
        {
            try
            {
                var rawVacancies = _context.Vacancies
                    .Where(v => v.EmployerID == _currentUser.UserID)
                    .OrderByDescending(v => v.CreatedDate)
                    .Select(v => new
                    {
                        v.VacancyID,
                        v.Position,
                        CompanyName = v.Employer.CompanyName,
                        SalaryFrom = v.SalaryFrom,
                        SalaryTo = v.SalaryTo,
                        v.City,
                        v.EmploymentType,
                        v.Description,
                        v.IsActive,
                        v.CreatedDate,
                        ResponsesCount = v.CandidateResponses.Count
                    })
                    .ToList();

                var vacancies = rawVacancies.Select(v => new VacancyViewModel
                {
                    VacancyID = v.VacancyID,
                    Position = v.Position,
                    CompanyName = v.CompanyName,
                    SalaryRange = FormatSalary(v.SalaryFrom, v.SalaryTo),
                    City = v.City ?? "Не указан",
                    EmploymentType = v.EmploymentType ?? "Не указан",
                    ShortDescription = TruncateText(v.Description, 100),
                    IsActive = v.IsActive ?? false,
                    IsNotActive = !(v.IsActive ?? false),
                    CreatedDate = v.CreatedDate ?? DateTime.Now,
                    ResponsesCount = v.ResponsesCount,
                    Status = (v.IsActive ?? false) ? "Активна" : "Не активна",
                    StatusColor = (v.IsActive ?? false) ? new SolidColorBrush(Colors.Green) : new SolidColorBrush(Colors.Gray)
                }).ToList();

                VacanciesDataGrid.ItemsSource = vacancies;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки вакансий: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadResponses()
        {
            try
            {
                var responsesRaw = _context.CandidateResponses
                    .Where(r => r.Vacancy.EmployerID == _currentUser.UserID)
                    .OrderByDescending(r => r.ResponseDate)
                    .Select(r => new
                    {
                        r.ResponseID,
                        CandidateName = r.Candidate.FullName,
                        CandidateProfession = r.Candidate.Profession,
                        CandidateExperience = r.Candidate.ExperienceYears,
                        VacancyName = r.Vacancy.Position,
                        r.ResponseDate,
                        r.Status,
                        r.CoverLetter
                    })
                    .ToList();

                var responses = responsesRaw.Select(r => new ResponseViewModel
                {
                    ResponseID = r.ResponseID,
                    CandidateName = r.CandidateName,
                    CandidateProfession = r.CandidateProfession,
                    CandidateExperience = r.CandidateExperience,
                    VacancyName = r.VacancyName,
                    ResponseDate = r.ResponseDate,
                    Status = r.Status,
                    CoverLetter = r.CoverLetter,
                    StatusColor = GetStatusColor(r.Status)
                }).ToList();

                ResponsesDataGrid.ItemsSource = responses;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки откликов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadResumes()
        {
            try
            {
                var resumes = _context.Resumes
                    .Where(r => r.IsVisible == true && r.Status == "Активно")
                    .OrderByDescending(r => r.CreatedDate)
                    .Select(r => new ResumeViewModel
                    {
                        ResumeID = r.ResumeID,
                        CandidateName = r.Candidate.FullName,
                        CandidateProfession = r.Candidate.Profession,
                        CandidateExperience = r.Candidate.ExperienceYears,
                        Position = r.Title,
                        Skills = r.Skills,
                        SalaryExpectation = r.SalaryExpectation,
                        EmploymentType = r.EmploymentType,
                        CreatedDate = r.CreatedDate
                    })
                    .ToList();

                ResumesDataGrid.ItemsSource = resumes;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки резюме: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadProfile()
        {
            try
            {
                if (_currentEmployer == null) return;

                ProfileCompanyName.Text = _currentEmployer.CompanyName;
                ProfileINN.Text = _currentEmployer.INN;
                ProfileContactPerson.Text = _currentEmployer.ContactPerson;
                ProfileIndustry.Text = _currentEmployer.Industry;
                ProfileDescription.Text = _currentEmployer.CompanyDescription ?? "Описание не добавлено";
                ProfileCreatedDate.Text = _currentEmployer.CreatedDate?.ToString("dd.MM.yyyy") ?? "-";

                var vacanciesCount = _context.Vacancies.Count(v => v.EmployerID == _currentUser.UserID);
                var activeVacanciesCount = _context.Vacancies.Count(v => v.EmployerID == _currentUser.UserID && v.IsActive == true);
                var totalResponses = _context.CandidateResponses.Count(r => r.Vacancy.EmployerID == _currentUser.UserID);

                ProfileVacanciesCount.Text = vacanciesCount.ToString();
                ProfileActiveVacancies.Text = activeVacanciesCount.ToString();
                ProfileTotalResponses.Text = totalResponses.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки профиля: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion

        #region Комиссии

        private void LoadEmployerCommissions()
        {
            try
            {
                var commissions = _context.CommissionHistories
                    .Where(c => c.EmployerID == _currentUser.UserID)
                    .OrderByDescending(c => c.CreatedDate)
                    .Select(c => new
                    {
                        c.CommissionID,
                        CandidateName = c.Candidate.FullName,
                        VacancyPosition = c.Vacancy.Position,
                        c.AnnualSalary,
                        c.CommissionPercent,
                        c.CommissionAmount,
                        c.PaymentStatus,
                        c.CreatedDate
                    })
                    .ToList();

                var totalPending = commissions
                    .Where(c => c.PaymentStatus == "Ожидает оплаты")
                    .Sum(c => (decimal?)c.CommissionAmount) ?? 0;

                var totalPaid = commissions
                    .Where(c => c.PaymentStatus == "Оплачено")
                    .Sum(c => (decimal?)c.CommissionAmount) ?? 0;

                var total = commissions.Sum(c => (decimal?)c.CommissionAmount) ?? 0;

                StatTotalCommission.Text = $"{total:N0} ₽";
                StatPendingCommission.Text = $"{totalPending:N0} ₽";
                StatPaidCommission.Text = $"{totalPaid:N0} ₽";

                var commissionList = commissions.Select(c => new CommissionViewModel
                {
                    CommissionID = c.CommissionID,
                    CandidateName = c.CandidateName,
                    VacancyPosition = c.VacancyPosition,
                    AnnualSalary = c.AnnualSalary,
                    CommissionPercent = c.CommissionPercent,
                    CommissionAmount = c.CommissionAmount,
                    PaymentStatus = c.PaymentStatus,
                    CreatedDate = c.CreatedDate,
                    StatusColor = GetCommissionStatusColor(c.PaymentStatus)
                }).ToList();

                CommissionsDataGrid.ItemsSource = commissionList;

                var pendingCount = commissions.Count(c => c.PaymentStatus == "Ожидает оплаты");
                if (pendingCount > 0)
                {
                    PageSubtitle.Text = $"💳 {pendingCount} комиссий ожидают оплаты на сумму {totalPending:N0} ₽";
                    PageSubtitle.Foreground = new SolidColorBrush(Colors.Orange);
                }
                else
                {
                    PageSubtitle.Text = "Все комиссии оплачены";
                    PageSubtitle.Foreground = new SolidColorBrush(Colors.Green);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки комиссий: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private SolidColorBrush GetCommissionStatusColor(string status)
        {
            switch (status?.ToLower())
            {
                case "оплачено": return new SolidColorBrush(Colors.Green);
                case "ожидает оплаты": return new SolidColorBrush(Colors.Orange);
                case "отменено": return new SolidColorBrush(Colors.Gray);
                default: return new SolidColorBrush(Colors.Blue);
            }
        }

        private void PayCommission_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int commissionId = (int)button.Tag;

            var commission = _context.CommissionHistories
                .Include(c => c.Candidate)
                .Include(c => c.Vacancy)
                .FirstOrDefault(c => c.CommissionID == commissionId);

            if (commission == null) return;

            _payingCommissionId = commissionId;

            PayConfirmText.Text = $"Вы хотите оплатить комиссию за трудоустройство кандидата?\n\n" +
                $"Кандидат: {commission.Candidate.FullName}\n" +
                $"Вакансия: {commission.Vacancy.Position}\n" +
                $"Сумма комиссии: {commission.CommissionAmount:N0} ₽\n\n" +
                $"После подтверждения статус изменится на 'Оплачено'.";

            PayConfirmPanel.Visibility = Visibility.Visible;
            CommissionsPanel.Visibility = Visibility.Collapsed;
        }

        private void ConfirmPay_Click(object sender, RoutedEventArgs e)
        {
            if (!_payingCommissionId.HasValue) return;

            try
            {
                var commission = _context.CommissionHistories.Find(_payingCommissionId.Value);
                if (commission == null)
                {
                    MessageBox.Show("Комиссия не найдена", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (commission.PaymentStatus == "Оплачено")
                {
                    MessageBox.Show("Эта комиссия уже оплачена", "Информация",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                commission.PaymentStatus = "Оплачено";
                commission.PaymentDate = DateTime.Now;
                commission.InvoiceNumber = $"INV-{commission.CommissionID:D6}-{DateTime.Now:yyyyMMdd}";
                commission.UpdatedDate = DateTime.Now;
                commission.Notes = (commission.Notes ?? "") +
                    $"\n[Оплачено {DateTime.Now:dd.MM.yyyy HH:mm}]";

                _context.SaveChanges();

                MessageBox.Show(
                    $"✅ Комиссия успешно оплачена!\n\n" +
                    $"Сумма: {commission.CommissionAmount:N0} ₽\n" +
                    $"Номер счёта: {commission.InvoiceNumber}\n" +
                    $"Дата оплаты: {DateTime.Now:dd.MM.yyyy HH:mm}",
                    "Оплата подтверждена",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                _payingCommissionId = null;
                PayConfirmPanel.Visibility = Visibility.Collapsed;
                CommissionsPanel.Visibility = Visibility.Visible;

                LoadEmployerCommissions();
                LoadDashboardData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при оплате: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelPay_Click(object sender, RoutedEventArgs e)
        {
            _payingCommissionId = null;
            PayConfirmPanel.Visibility = Visibility.Collapsed;
            CommissionsPanel.Visibility = Visibility.Visible;
        }

        #endregion

        #region Вспомогательные методы

        private string FormatSalary(decimal? from, decimal? to)
        {
            if (from.HasValue && to.HasValue)
                return $"{from.Value:N0} - {to.Value:N0} ₽";
            if (from.HasValue)
                return $"от {from.Value:N0} ₽";
            if (to.HasValue)
                return $"до {to.Value:N0} ₽";
            return "По договоренности";
        }

        private string TruncateText(string text, int maxLength)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Length > maxLength ? text.Substring(0, maxLength) + "..." : text;
        }

        private SolidColorBrush GetStatusColor(string status)
        {
            switch (status)
            {
                case "Новый": return new SolidColorBrush(Colors.Orange);
                case "На рассмотрении": return new SolidColorBrush(Colors.Blue);
                case "Приглашен на собеседование": return new SolidColorBrush(Colors.Green);
                case "Отклонен": return new SolidColorBrush(Colors.Red);
                case "Принят на работу": return new SolidColorBrush(Colors.DarkGreen);
                default: return new SolidColorBrush(Colors.Gray);
            }
        }

        #endregion

        #region Обработчики событий откликов

        private void ViewResponse_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int responseId = (int)button.Tag;

            var response = _context.CandidateResponses
                .Include(r => r.Candidate)
                .Include(r => r.Vacancy)
                .FirstOrDefault(r => r.ResponseID == responseId);

            if (response == null) return;

            _selectedResponse = response;

            ViewCandidateName.Text = response.Candidate.FullName;
            ViewCandidateProfession.Text = response.Candidate.Profession;
            ViewCandidateExperience.Text = response.Candidate.ExperienceYears.HasValue
                ? $"Опыт: {response.Candidate.ExperienceYears} лет"
                : "Опыт: не указан";
            ViewVacancyName.Text = response.Vacancy.Position;
            ViewCoverLetter.Text = response.CoverLetter ?? "Сопроводительное письмо не добавлено";

            foreach (ComboBoxItem item in ResponseStatusCombo.Items)
            {
                if (item.Content.ToString() == response.Status)
                {
                    ResponseStatusCombo.SelectedItem = item;
                    break;
                }
            }

            ViewResponsePanel.Visibility = Visibility.Visible;
        }

        private void SaveResponseStatus_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedResponse == null) return;

            try
            {
                string newStatus = (ResponseStatusCombo.SelectedItem as ComboBoxItem)?.Content.ToString();
                string oldStatus = _selectedResponse.Status;

                _selectedResponse.Status = newStatus;
                _selectedResponse.EmployerComment = ResponseCommentText.Text;

                if (newStatus == "Принят на работу" && oldStatus != "Принят на работу")
                {
                    CreateCommissionForHiredCandidate(_selectedResponse);
                }

                _context.SaveChanges();

                MessageBox.Show("Статус сохранен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                ViewResponsePanel.Visibility = Visibility.Collapsed;

                LoadResponses();
                LoadDashboardData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CreateCommissionForHiredCandidate(CandidateRespons response)
        {
            try
            {
                var vacancy = _context.Vacancies
                    .FirstOrDefault(v => v.VacancyID == response.VacancyID);

                if (vacancy == null)
                    throw new Exception("Вакансия не найдена");

                decimal? averageSalary = CalculateAverageSalary(vacancy.SalaryFrom, vacancy.SalaryTo);

                if (!averageSalary.HasValue || averageSalary.Value <= 0)
                    throw new Exception("Не указана зарплата по вакансии. Невозможно рассчитать комиссию.");

                var commissionSettings = _context.CommissionSettings
                    .FirstOrDefault(s => s.IsActive == true);

                decimal commissionPercent = 15.00m;

                if (commissionSettings != null)
                {
                    commissionPercent = commissionSettings.CommissionPercent;
                }

                decimal annualSalary = averageSalary.Value * 12;
                decimal commissionAmount = annualSalary * (commissionPercent / 100);

                var existingCommission = _context.CommissionHistories
                    .FirstOrDefault(c => c.ResponseID == response.ResponseID);

                if (existingCommission != null)
                {
                    existingCommission.AnnualSalary = annualSalary;
                    existingCommission.CommissionPercent = commissionPercent;
                    existingCommission.CommissionAmount = commissionAmount;
                    existingCommission.PaymentStatus = "Ожидает оплаты";
                    existingCommission.Notes = $"Автоматический пересчёт комиссии. Среднемесячная ЗП: {averageSalary.Value:N0} ₽";
                    existingCommission.UpdatedDate = DateTime.Now;
                }
                else
                {
                    var commission = new CommissionHistory
                    {
                        ResponseID = response.ResponseID,
                        CandidateID = response.CandidateID,
                        EmployerID = response.Vacancy.EmployerID,
                        VacancyID = response.VacancyID,
                        AnnualSalary = annualSalary,
                        CommissionPercent = commissionPercent,
                        CommissionAmount = commissionAmount,
                        PaymentStatus = "Ожидает оплаты",
                        InvoiceNumber = null,
                        Notes = $"Автоматический расчёт при трудоустройстве. Среднемесячная ЗП: {averageSalary.Value:N0} ₽ × 12 мес. = {annualSalary:N0} ₽. Комиссия {commissionPercent}%",
                        CreatedDate = DateTime.Now
                    };

                    _context.CommissionHistories.Add(commission);
                }

                MessageBox.Show(
                    $"💰 Комиссия за трудоустройство рассчитана!\n\n" +
                    $"Кандидат: {response.Candidate.FullName}\n" +
                    $"Вакансия: {vacancy.Position}\n" +
                    $"Среднемесячная ЗП: {averageSalary.Value:N0} ₽\n" +
                    $"Годовой оклад: {annualSalary:N0} ₽\n" +
                    $"Процент комиссии: {commissionPercent}%\n" +
                    $"Сумма комиссии: {commissionAmount:N0} ₽\n\n" +
                    $"Статус: Ожидает оплаты",
                    "Комиссия рассчитана",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка расчёта комиссии: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private decimal? CalculateAverageSalary(decimal? salaryFrom, decimal? salaryTo)
        {
            if (salaryFrom.HasValue && salaryTo.HasValue && salaryTo.Value > 0)
            {
                return (salaryFrom.Value + salaryTo.Value) / 2;
            }

            if (salaryFrom.HasValue && salaryFrom.Value > 0)
            {
                return salaryFrom.Value;
            }

            if (salaryTo.HasValue && salaryTo.Value > 0)
            {
                return salaryTo.Value;
            }

            return null;
        }

        private void CloseViewResponse_Click(object sender, RoutedEventArgs e)
        {
            ViewResponsePanel.Visibility = Visibility.Collapsed;
            _selectedResponse = null;
        }

        #endregion

        #region Обработчики событий резюме

        private async void ViewResume_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int resumeId = (int)button.Tag;

            _selectedResume = await _context.Resumes
                .Include(r => r.Candidate)
                .FirstOrDefaultAsync(r => r.ResumeID == resumeId);

            if (_selectedResume == null) return;

            ViewResumeCandidateName.Text = _selectedResume.Candidate.FullName;
            ViewResumeProfession.Text = _selectedResume.Candidate.Profession;
            ViewResumeExperience.Text = _selectedResume.Candidate.ExperienceYears.HasValue
                ? $"Опыт работы: {_selectedResume.Candidate.ExperienceYears} лет"
                : "Опыт работы: не указан";
            ViewResumeEducation.Text = $"Образование: {_selectedResume.Candidate.Education ?? "не указано"}";
            ViewResumeTitle.Text = _selectedResume.Title;
            ViewResumeSalary.Text = _selectedResume.SalaryExpectation.HasValue
                ? $"Зарплатные ожидания: {_selectedResume.SalaryExpectation.Value:N0} ₽"
                : "Зарплатные ожидания: по договоренности";
            ViewResumeEmploymentType.Text = $"Тип занятости: {_selectedResume.EmploymentType ?? "не указан"}";
            ViewResumeSkills.Text = _selectedResume.Skills ?? "Навыки не указаны";
            ViewResumeText.Text = _selectedResume.ResumeText ?? "Описание отсутствует";

            var myVacancies = await _context.Vacancies
                .Where(v => v.EmployerID == _currentUser.UserID && v.IsActive == true)
                .Select(v => new { v.VacancyID, v.Position })
                .ToListAsync();

            VacancyForInviteCombo.ItemsSource = myVacancies;
            VacancyForInviteCombo.DisplayMemberPath = "Position";
            VacancyForInviteCombo.SelectedValuePath = "VacancyID";

            if (myVacancies.Any())
                VacancyForInviteCombo.SelectedIndex = 0;

            ViewResumePanel.Visibility = Visibility.Visible;
        }

        private async void InviteCandidate_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int resumeId = (int)button.Tag;

            _selectedResume = await _context.Resumes
                .Include(r => r.Candidate)
                .FirstOrDefaultAsync(r => r.ResumeID == resumeId);

            if (_selectedResume == null) return;

            ViewResumeCandidateName.Text = _selectedResume.Candidate.FullName;
            ViewResumeProfession.Text = _selectedResume.Candidate.Profession;
            ViewResumeExperience.Text = _selectedResume.Candidate.ExperienceYears.HasValue
                ? $"Опыт работы: {_selectedResume.Candidate.ExperienceYears} лет"
                : "Опыт работы: не указан";
            ViewResumeEducation.Text = $"Образование: {_selectedResume.Candidate.Education ?? "не указано"}";
            ViewResumeTitle.Text = _selectedResume.Title;
            ViewResumeSalary.Text = _selectedResume.SalaryExpectation.HasValue
                ? $"Зарплатные ожидания: {_selectedResume.SalaryExpectation.Value:N0} ₽"
                : "Зарплатные ожидания: по договоренности";
            ViewResumeEmploymentType.Text = $"Тип занятости: {_selectedResume.EmploymentType ?? "не указан"}";
            ViewResumeSkills.Text = _selectedResume.Skills ?? "Навыки не указаны";
            ViewResumeText.Text = _selectedResume.ResumeText ?? "Описание отсутствует";

            var myVacancies = await _context.Vacancies
                .Where(v => v.EmployerID == _currentUser.UserID && v.IsActive == true)
                .Select(v => new { v.VacancyID, v.Position })
                .ToListAsync();

            VacancyForInviteCombo.ItemsSource = myVacancies;
            VacancyForInviteCombo.DisplayMemberPath = "Position";
            VacancyForInviteCombo.SelectedValuePath = "VacancyID";

            if (myVacancies.Any())
                VacancyForInviteCombo.SelectedIndex = 0;

            InterviewDatePicker.SelectedDate = null;
            InviteMessageTextBox.Text = "";

            ViewResumePanel.Visibility = Visibility.Visible;
        }

        private async void SendInvite_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedResume == null) return;

            if (VacancyForInviteCombo.SelectedValue == null)
            {
                MessageBox.Show("Выберите вакансию", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int vacancyId = (int)VacancyForInviteCombo.SelectedValue;

            try
            {
                var employerResponse = new EmployerRespons
                {
                    EmployerID = _currentUser.UserID,
                    CandidateID = _selectedResume.CandidateID,
                    VacancyID = vacancyId,
                    ResumeID = _selectedResume.ResumeID,
                    Message = InviteMessageTextBox.Text,
                    Status = InterviewDatePicker.SelectedDate.HasValue ? "Приглашен на собеседование" : "Отклик работодателя",
                    ResponseDate = DateTime.Now,
                    InterviewDate = InterviewDatePicker.SelectedDate
                };

                _context.EmployerResponses.Add(employerResponse);
                await _context.SaveChangesAsync();

                MessageBox.Show("Приглашение успешно отправлено кандидату!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                InviteMessageTextBox.Clear();
                InterviewDatePicker.SelectedDate = null;
                ViewResumePanel.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка отправки приглашения: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseViewResume_Click(object sender, RoutedEventArgs e)
        {
            ViewResumePanel.Visibility = Visibility.Collapsed;
            _selectedResume = null;
        }

        #endregion

        #region CRUD операции с вакансиями

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            _editingVacancyId = null;
            EditPanelTitle.Text = "Новая вакансия";
            ClearEditForm();
            ShowEditPanel();
        }

        private void EditVacancy_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;

            int vacancyId = (int)button.Tag;
            _editingVacancyId = vacancyId;
            EditPanelTitle.Text = "Редактирование вакансии";
            LoadVacancyForEdit(vacancyId);
            ShowEditPanel();
        }

        private async void LoadVacancyForEdit(int vacancyId)
        {
            try
            {
                var vacancy = await _context.Vacancies.FindAsync(vacancyId);
                if (vacancy == null) return;

                PositionTextBox.Text = vacancy.Position;
                CityTextBox.Text = vacancy.City ?? "";
                SalaryFromTextBox.Text = vacancy.SalaryFrom?.ToString() ?? "";
                SalaryToTextBox.Text = vacancy.SalaryTo?.ToString() ?? "";
                ExperienceTextBox.Text = vacancy.ExperienceRequired?.ToString() ?? "";
                DescriptionTextBox.Text = vacancy.Description ?? "";
                RequirementsTextBox.Text = vacancy.Requirements ?? "";
                IsActiveCheckBox.IsChecked = vacancy.IsActive ?? true;

                foreach (ComboBoxItem item in EmploymentTypeCombo.Items)
                {
                    if (item.Content.ToString() == vacancy.EmploymentType)
                    {
                        EmploymentTypeCombo.SelectedItem = item;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки вакансии: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void SaveVacancy_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PositionTextBox.Text))
            {
                MessageBox.Show("Укажите должность", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                Vacancy vacancy;

                if (_editingVacancyId.HasValue)
                {
                    vacancy = await _context.Vacancies.FindAsync(_editingVacancyId.Value);
                    if (vacancy == null)
                    {
                        MessageBox.Show("Вакансия не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else
                {
                    vacancy = new Vacancy
                    {
                        EmployerID = _currentUser.UserID,
                        CreatedDate = DateTime.Now
                    };
                    _context.Vacancies.Add(vacancy);
                }

                vacancy.Position = PositionTextBox.Text.Trim();
                vacancy.City = string.IsNullOrWhiteSpace(CityTextBox.Text) ? null : CityTextBox.Text.Trim();
                vacancy.Description = string.IsNullOrWhiteSpace(DescriptionTextBox.Text) ? null : DescriptionTextBox.Text.Trim();
                vacancy.Requirements = string.IsNullOrWhiteSpace(RequirementsTextBox.Text) ? null : RequirementsTextBox.Text.Trim();
                vacancy.EmploymentType = (EmploymentTypeCombo.SelectedItem as ComboBoxItem)?.Content.ToString();
                vacancy.IsActive = IsActiveCheckBox.IsChecked;
                vacancy.UpdatedDate = DateTime.Now;

                if (decimal.TryParse(SalaryFromTextBox.Text, out decimal salaryFrom))
                    vacancy.SalaryFrom = salaryFrom;
                else
                    vacancy.SalaryFrom = null;

                if (decimal.TryParse(SalaryToTextBox.Text, out decimal salaryTo))
                    vacancy.SalaryTo = salaryTo;
                else
                    vacancy.SalaryTo = null;

                if (int.TryParse(ExperienceTextBox.Text, out int experience))
                    vacancy.ExperienceRequired = experience;
                else
                    vacancy.ExperienceRequired = null;

                await _context.SaveChangesAsync();

                MessageBox.Show(_editingVacancyId.HasValue ? "Вакансия обновлена" : "Вакансия создана",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                HideEditPanel();
                LoadVacancies();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteVacancy_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;

            _deletingVacancyId = (int)button.Tag;
            var vacancy = _context.Vacancies.Find(_deletingVacancyId.Value);
            DeleteConfirmText.Text = $"Вы уверены, что хотите удалить вакансию \"{vacancy?.Position}\"?";
            DeleteConfirmPanel.Visibility = Visibility.Visible;
        }

        private async void ConfirmDelete_Click(object sender, RoutedEventArgs e)
        {
            if (!_deletingVacancyId.HasValue) return;

            try
            {
                var vacancy = await _context.Vacancies.FindAsync(_deletingVacancyId.Value);
                if (vacancy != null)
                {
                    _context.Vacancies.Remove(vacancy);
                    await _context.SaveChangesAsync();
                    MessageBox.Show("Вакансия удалена", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadVacancies();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                _deletingVacancyId = null;
                DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            }
        }

        private void CancelDelete_Click(object sender, RoutedEventArgs e)
        {
            _deletingVacancyId = null;
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
        }

        #endregion

        #region Обработчики профиля

        private void EditProfile_Click(object sender, RoutedEventArgs e)
        {
            ProfileViewPanel.Visibility = Visibility.Collapsed;
            ProfileEditPanel.Visibility = Visibility.Visible;

            EditCompanyName.Text = _currentEmployer.CompanyName;
            EditINN.Text = _currentEmployer.INN;
            EditContactPerson.Text = _currentEmployer.ContactPerson ?? "";
            EditIndustry.Text = _currentEmployer.Industry ?? "";
            EditCompanyDescription.Text = _currentEmployer.CompanyDescription ?? "";
        }

        private void CancelProfileEdit_Click(object sender, RoutedEventArgs e)
        {
            ProfileViewPanel.Visibility = Visibility.Visible;
            ProfileEditPanel.Visibility = Visibility.Collapsed;
        }

        private async void SaveProfile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _currentEmployer.CompanyName = EditCompanyName.Text.Trim();
                _currentEmployer.INN = EditINN.Text.Trim();
                _currentEmployer.ContactPerson = string.IsNullOrWhiteSpace(EditContactPerson.Text) ? null : EditContactPerson.Text.Trim();
                _currentEmployer.Industry = string.IsNullOrWhiteSpace(EditIndustry.Text) ? null : EditIndustry.Text.Trim();
                _currentEmployer.CompanyDescription = string.IsNullOrWhiteSpace(EditCompanyDescription.Text) ? null : EditCompanyDescription.Text.Trim();
                _currentEmployer.UpdatedDate = DateTime.Now;

                await _context.SaveChangesAsync();

                EmployerNameText.Text = _currentEmployer.CompanyName;
                LoadProfile();

                ProfileViewPanel.Visibility = Visibility.Visible;
                ProfileEditPanel.Visibility = Visibility.Collapsed;

                MessageBox.Show("Профиль компании обновлен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения профиля: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        #endregion

        #region Вспомогательные методы UI

        private void ClearEditForm()
        {
            PositionTextBox.Text = "";
            CityTextBox.Text = "";
            SalaryFromTextBox.Text = "";
            SalaryToTextBox.Text = "";
            ExperienceTextBox.Text = "";
            DescriptionTextBox.Text = "";
            RequirementsTextBox.Text = "";
            IsActiveCheckBox.IsChecked = true;
            EmploymentTypeCombo.SelectedIndex = 0;
        }

        private void ShowEditPanel()
        {
            EditPanel.Visibility = Visibility.Visible;
            var slideAnimation = new ThicknessAnimation
            {
                From = new Thickness(600, 20, 20, 20),
                To = new Thickness(20, 20, 20, 20),
                Duration = TimeSpan.FromMilliseconds(300),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };
            EditPanel.BeginAnimation(MarginProperty, slideAnimation);
        }

        private void HideEditPanel()
        {
            EditPanel.Visibility = Visibility.Collapsed;
            _editingVacancyId = null;
        }

        private void CancelEdit_Click(object sender, RoutedEventArgs e)
        {
            HideEditPanel();
        }

        private void ViewVacancy_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button)) return;
            int vacancyId = (int)button.Tag;
            MessageBox.Show($"Просмотр вакансии ID: {vacancyId}", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            switch (_currentView)
            {
                case "Dashboard": LoadDashboardData(); break;
                case "Vacancies": LoadVacancies(); break;
                case "Responses": LoadResponses(); break;
                case "Resumes": LoadResumes(); break;
                case "Profile": LoadProfile(); break;
                case "Commissions": LoadEmployerCommissions(); break;
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Поиск: {SearchTextBox.Text}", "Поиск", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Properties["CurrentUser"] = null;
            Manager.MainFrame.Navigate(new LoginPage());
        }

        #endregion
    }

    // ViewModels
    public class VacancyViewModel
    {
        public int VacancyID { get; set; }
        public string Position { get; set; }
        public string CompanyName { get; set; }
        public string SalaryRange { get; set; }
        public string City { get; set; }
        public string EmploymentType { get; set; }
        public string ShortDescription { get; set; }
        public bool IsActive { get; set; }
        public bool IsNotActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public int ResponsesCount { get; set; }
        public string Status { get; set; }
        public SolidColorBrush StatusColor { get; set; }
    }

    public class ResponseViewModel
    {
        public int ResponseID { get; set; }
        public string CandidateName { get; set; }
        public string CandidateProfession { get; set; }
        public int? CandidateExperience { get; set; }
        public string VacancyName { get; set; }
        public DateTime? ResponseDate { get; set; }
        public string Status { get; set; }
        public string CoverLetter { get; set; }
        public SolidColorBrush StatusColor { get; set; }
    }

    public class ResumeViewModel
    {
        public int ResumeID { get; set; }
        public string CandidateName { get; set; }
        public string CandidateProfession { get; set; }
        public int? CandidateExperience { get; set; }
        public string Position { get; set; }
        public string Skills { get; set; }
        public decimal? SalaryExpectation { get; set; }
        public string EmploymentType { get; set; }
        public DateTime? CreatedDate { get; set; }
    }

    public class CommissionViewModel
    {
        public int CommissionID { get; set; }
        public string CandidateName { get; set; }
        public string VacancyPosition { get; set; }
        public decimal AnnualSalary { get; set; }
        public string AnnualSalaryFormatted => $"{AnnualSalary:N0} ₽";
        public decimal CommissionPercent { get; set; }
        public decimal CommissionAmount { get; set; }
        public string CommissionAmountFormatted => $"{CommissionAmount:N0} ₽";
        public string PaymentStatus { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedDateFormatted => CreatedDate?.ToString("dd.MM.yyyy") ?? "-";
        public bool CanPay => PaymentStatus == "Ожидает оплаты";
        public SolidColorBrush StatusColor { get; set; }
    }
}
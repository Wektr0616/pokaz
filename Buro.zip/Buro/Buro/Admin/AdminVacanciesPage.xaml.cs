﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminVacanciesPage.xaml
    /// </summary>
    public partial class AdminVacanciesPage : Page
    {
        public AdminVacanciesPage()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            // Фильтр статусов
            var statuses = new List<string>
            {
                "Все статусы",
                "Активные",
                "Снятые",
                "На модерации",
                "Черновики"
            };

            StatusFilterComboBox.ItemsSource = statuses;
            StatusFilterComboBox.SelectedIndex = 0;

            // Фильтр категорий
            var categories = new List<string>
            {
                "Все категории",
                "IT и программирование",
                "Маркетинг и продажи",
                "Бухгалтерия и финансы",
                "Производство",
                "Образование",
                "Медицина",
                "Строительство"
            };

            CategoryFilterComboBox.ItemsSource = categories;
            CategoryFilterComboBox.SelectedIndex = 0;

            // Фильтр городов
            var cities = new List<string>
            {
                "Все города",
                "Москва",
                "Санкт-Петербург",
                "Казань",
                "Екатеринбург",
                "Удаленно"
            };

            CityFilterComboBox.ItemsSource = cities;
            CityFilterComboBox.SelectedIndex = 0;
        }

        private void CreateVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Создание новой вакансии от имени администратора:\n\n" +
                          "1. Выбор работодателя\n" +
                          "2. Заполнение данных вакансии\n" +
                          "3. Модерация и публикация",
                          "Создание вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchText = SearchTextBox.Text.Trim();
            string status = StatusFilterComboBox.SelectedItem as string;
            string category = CategoryFilterComboBox.SelectedItem as string;
            string city = CityFilterComboBox.SelectedItem as string;

            MessageBox.Show($"Поиск вакансий:\n\n" +
                          $"Текст: {searchText}\n" +
                          $"Статус: {status}\n" +
                          $"Категория: {category}\n" +
                          $"Город: {city}",
                          "Результаты поиска",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Просмотр полной информации о вакансии:\n\n" +
                          "• Подробное описание\n" +
                          "• Требования и обязанности\n" +
                          "• Статистика откликов\n" +
                          "• История изменений",
                          "Просмотр вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void EditVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Редактирование вакансии:\n\n" +
                          "• Изменение описания\n" +
                          "• Корректировка требований\n" +
                          "• Изменение зарплаты\n" +
                          "• Обновление статуса",
                          "Редактирование вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void DeactivateVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Снять эту вакансию с публикации?\n\n" +
                                       "Вакансия перестанет быть видна соискателям.",
                                       "Снятие вакансии",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Вакансия снята с публикации.",
                              "Вакансия снята",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void ActivateVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Активировать эту вакансию?\n\n" +
                                       "Вакансия снова станет видна соискателям.",
                                       "Активация вакансии",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Вакансия активирована и опубликована.",
                              "Вакансия активирована",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void DeleteVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Удалить эту вакансию безвозвратно?\n\n" +
                                       "Все данные вакансии будут удалены.",
                                       "Удаление вакансии",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Вакансия удалена успешно.",
                              "Удаление завершено",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.JobSeeker
{
    /// <summary>
    /// Логика взаимодействия для MyApplicationsPage.xaml
    /// </summary>
    public partial class MyApplicationsPage : Page
    {
        public MyApplicationsPage()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            var filters = new List<string>
            {
                "Все отклики",
                "Отправленные",
                "Просмотренные",
                "Приглашения",
                "Отказы",
                "Архивные"
            };

            FilterComboBox.ItemsSource = filters;
            FilterComboBox.SelectedIndex = 0;
        }

        private void ViewVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет переход на страницу вакансии",
                          "Просмотр вакансии",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void EditApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет редактирование отклика",
                          "Редактирование отклика",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void WithdrawButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Отозвать этот отклик?\n\n" +
                                       "Работодатель больше не увидит ваше резюме по этой вакансии.",
                                       "Отзыв отклика",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Отклик отозван успешно.",
                              "Отклик отозван",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        private void ViewCoverLetterButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Сопроводительное письмо:\n\n" +
                          "Заинтересовала ваша вакансия, так как имею 3-летний опыт работы с React и современным стеком frontend-технологий.\n\n" +
                          "В предыдущих проектах:\n" +
                          "• Разрабатывал SPA-приложения на React/TypeScript\n" +
                          "• Работал с Redux, React Router, Material-UI\n" +
                          "• Интегрировал REST API\n" +
                          "• Участвовал в code review\n\n" +
                          "Готов рассмотреть ваше предложение и пройти собеседование.",
                          "Сопроводительное письмо",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ConfirmInterviewButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Подтвердить участие в собеседовании?\n\n" +
                                       "Работодатель получит подтверждение.",
                                       "Подтверждение собеседования",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Собеседование подтверждено! Работодатель получил уведомление.\n\n" +
                              "Не забудьте подготовиться к встрече.",
                              "Собеседование подтверждено",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }

        // Метод для обновления статистики
        public void UpdateStatistics(int total, int sent, int viewed, int invitations)
        {
            // В реальном приложении здесь будет обновление UI
        }

        // Метод для загрузки откликов пользователя
        public void LoadApplications(string userId)
        {
            // В реальном приложении здесь будет загрузка из базы данных
        }
    }
}
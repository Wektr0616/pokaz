﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buro
{
    public class DatabaseHelper
    {
        private readonly string _connectionString;

        public DatabaseHelper()
        {
            // Измените строку подключения под вашу конфигурацию
            _connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=BuroDB;Trusted_Connection=True;";
        }

        // Хеширование пароля (простая реализация, для продакшена используйте более надежный метод)
        public string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }

        // Проверка пароля
        public bool VerifyPassword(string inputPassword, string storedHash)
        {
            string inputHash = HashPassword(inputPassword);
            return inputHash == storedHash;
        }

        #region JobSeeker Methods

        public async Task<int> RegisterJobSeeker(JobSeekerModel seeker, string password)
        {
            string hashedPassword = HashPassword(password);

            const string query = @"
                INSERT INTO JobSeekers (FullName, Email, Phone, PasswordHash, Profession, Experience, Education, RegistrationDate, IsActive)
                VALUES (@FullName, @Email, @Phone, @PasswordHash, @Profession, @Experience, @Education, GETDATE(), 1);
                SELECT SCOPE_IDENTITY();";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FullName", seeker.FullName);
                    command.Parameters.AddWithValue("@Email", seeker.Email);
                    command.Parameters.AddWithValue("@Phone", seeker.Phone);
                    command.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                    command.Parameters.AddWithValue("@Profession", seeker.Profession);
                    command.Parameters.AddWithValue("@Experience", string.IsNullOrEmpty(seeker.Experience) ? DBNull.Value : (object)seeker.Experience);
                    command.Parameters.AddWithValue("@Education", string.IsNullOrEmpty(seeker.Education) ? DBNull.Value : (object)seeker.Education);

                    var result = await command.ExecuteScalarAsync();
                    return Convert.ToInt32(result);
                }
            }
        }

        public async Task<JobSeekerModel> AuthenticateJobSeeker(string email, string password)
        {
            const string query = @"
                SELECT Id, FullName, Email, Phone, PasswordHash, Profession, Experience, Education, RegistrationDate
                FROM JobSeekers 
                WHERE Email = @Email AND IsActive = 1";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);

                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            string storedHash = reader["PasswordHash"].ToString();
                            if (VerifyPassword(password, storedHash))
                            {
                                return new JobSeekerModel
                                {
                                    Id = Convert.ToInt32(reader["Id"]),
                                    FullName = reader["FullName"].ToString(),
                                    Email = reader["Email"].ToString(),
                                    Phone = reader["Phone"].ToString(),
                                    Profession = reader["Profession"].ToString(),
                                    Experience = reader["Experience"]?.ToString(),
                                    Education = reader["Education"]?.ToString(),
                                    RegistrationDate = Convert.ToDateTime(reader["RegistrationDate"])
                                };
                            }
                        }
                    }
                }
            }
            return null;
        }

        public async Task<bool> IsEmailExists(string email)
        {
            const string query = "SELECT COUNT(1) FROM JobSeekers WHERE Email = @Email";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    int count = Convert.ToInt32(await command.ExecuteScalarAsync());
                    return count > 0;
                }
            }
        }

        #endregion

        #region Employer Methods

        public async Task<int> RegisterEmployer(EmployerModel employer, string password)
        {
            string hashedPassword = HashPassword(password);

            const string query = @"
                INSERT INTO Employers (CompanyName, INN, Email, Phone, ContactPerson, PasswordHash, BusinessField, RegistrationDate, IsActive, IsVerified)
                VALUES (@CompanyName, @INN, @Email, @Phone, @ContactPerson, @PasswordHash, @BusinessField, GETDATE(), 1, 0);
                SELECT SCOPE_IDENTITY();";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CompanyName", employer.CompanyName);
                    command.Parameters.AddWithValue("@INN", employer.INN);
                    command.Parameters.AddWithValue("@Email", employer.Email);
                    command.Parameters.AddWithValue("@Phone", employer.Phone);
                    command.Parameters.AddWithValue("@ContactPerson", employer.ContactPerson);
                    command.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                    command.Parameters.AddWithValue("@BusinessField", string.IsNullOrEmpty(employer.BusinessField) ? DBNull.Value : (object)employer.BusinessField);

                    var result = await command.ExecuteScalarAsync();
                    return Convert.ToInt32(result);
                }
            }
        }

        public async Task<EmployerModel> AuthenticateEmployer(string email, string password)
        {
            const string query = @"
                SELECT Id, CompanyName, INN, Email, Phone, ContactPerson, PasswordHash, BusinessField, RegistrationDate, IsVerified
                FROM Employers 
                WHERE Email = @Email AND IsActive = 1";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);

                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            string storedHash = reader["PasswordHash"].ToString();
                            if (VerifyPassword(password, storedHash))
                            {
                                return new EmployerModel
                                {
                                    Id = Convert.ToInt32(reader["Id"]),
                                    CompanyName = reader["CompanyName"].ToString(),
                                    INN = reader["INN"].ToString(),
                                    Email = reader["Email"].ToString(),
                                    Phone = reader["Phone"].ToString(),
                                    ContactPerson = reader["ContactPerson"].ToString(),
                                    BusinessField = reader["BusinessField"]?.ToString(),
                                    RegistrationDate = Convert.ToDateTime(reader["RegistrationDate"]),
                                    IsVerified = Convert.ToBoolean(reader["IsVerified"])
                                };
                            }
                        }
                    }
                }
            }
            return null;
        }

        public async Task<bool> IsCompanyEmailExists(string email)
        {
            const string query = "SELECT COUNT(1) FROM Employers WHERE Email = @Email";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);
                    int count = Convert.ToInt32(await command.ExecuteScalarAsync());
                    return count > 0;
                }
            }
        }

        public async Task<bool> IsINNExists(string inn)
        {
            const string query = "SELECT COUNT(1) FROM Employers WHERE INN = @INN";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@INN", inn);
                    int count = Convert.ToInt32(await command.ExecuteScalarAsync());
                    return count > 0;
                }
            }
        }

        #endregion

        #region Admin Methods

        public async Task<AdminModel> AuthenticateAdmin(string username, string password)
        {
            const string query = @"
                SELECT Id, Username, PasswordHash, FullName, Email, LastLoginDate
                FROM Admins 
                WHERE Username = @Username AND IsActive = 1";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);

                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            string storedHash = reader["PasswordHash"].ToString();
                            if (password == storedHash) // Для админа пока оставляем прямое сравнение
                            {
                                await UpdateAdminLastLogin(Convert.ToInt32(reader["Id"]));

                                return new AdminModel
                                {
                                    Id = Convert.ToInt32(reader["Id"]),
                                    Username = reader["Username"].ToString(),
                                    FullName = reader["FullName"]?.ToString(),
                                    Email = reader["Email"]?.ToString(),
                                    LastLoginDate = Convert.ToDateTime(reader["LastLoginDate"])
                                };
                            }
                        }
                    }
                }
            }
            return null;
        }

        private async Task UpdateAdminLastLogin(int adminId)
        {
            const string query = "UPDATE Admins SET LastLoginDate = GETDATE() WHERE Id = @Id";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", adminId);
                    await command.ExecuteNonQueryAsync();
                }
            }
        }

        #endregion
    }
}

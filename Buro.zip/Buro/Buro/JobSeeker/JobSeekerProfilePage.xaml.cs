﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.JobSeeker
{
    /// <summary>
    /// Логика взаимодействия для JobSeekerProfilePage.xaml
    /// </summary>
    public partial class JobSeekerProfilePage : Page
    {
        private bool _isEditMode = false;
        private string _originalFullName;
        private string _originalEmail;
        private string _originalPhone;
        private string _originalCity;
        private string _originalProfession;
        private string _originalExperience;
        private string _originalEducation;
        private string _originalSkills;
        private string _originalSalary;
        private string _originalEmploymentType;

        public JobSeekerProfilePage()
        {
            InitializeComponent();
            LoadSampleData();
            DisableEditMode();
        }

        private void LoadSampleData()
        {
            // Сохраняем оригинальные данные
            _originalFullName = "Иванов Иван Иванович";
            _originalEmail = "ivanov@example.com";
            _originalPhone = "+7 (999) 123-45-67";
            _originalCity = "Москва";
            _originalProfession = "Разработчик C# / .NET";
            _originalExperience = "5 лет в разработке программного обеспечения";
            _originalEducation = "Высшее техническое образование";
            _originalSkills = "C#, .NET Core, ASP.NET, SQL Server, Entity Framework";
            _originalSalary = "150000";
            _originalEmploymentType = "Полная занятость";

            // Загружаем данные в поля
            FullNameTextBox.Text = _originalFullName;
            EmailTextBox.Text = _originalEmail;
            PhoneTextBox.Text = _originalPhone;
            CityTextBox.Text = _originalCity;
            ProfessionTextBox.Text = _originalProfession;
            ExperienceTextBox.Text = _originalExperience;
            EducationTextBox.Text = _originalEducation;
            SkillsTextBox.Text = _originalSkills;
            SalaryTextBox.Text = _originalSalary;
            EmploymentTypeTextBox.Text = _originalEmploymentType;
        }

        private void EnableEditMode()
        {
            _isEditMode = true;

            // Разрешаем редактирование полей
            FullNameTextBox.IsReadOnly = false;
            EmailTextBox.IsReadOnly = false;
            PhoneTextBox.IsReadOnly = false;
            CityTextBox.IsReadOnly = false;
            ProfessionTextBox.IsReadOnly = false;
            ExperienceTextBox.IsReadOnly = false;
            EducationTextBox.IsReadOnly = false;
            SkillsTextBox.IsReadOnly = false;
            SalaryTextBox.IsReadOnly = false;
            EmploymentTypeTextBox.IsReadOnly = false;

            // Меняем стили полей для режима редактирования
            ChangeTextBoxStyle(FullNameTextBox, true);
            ChangeTextBoxStyle(EmailTextBox, true);
            ChangeTextBoxStyle(PhoneTextBox, true);
            ChangeTextBoxStyle(CityTextBox, true);
            ChangeTextBoxStyle(ProfessionTextBox, true);
            ChangeTextBoxStyle(ExperienceTextBox, true);
            ChangeTextBoxStyle(EducationTextBox, true);
            ChangeTextBoxStyle(SkillsTextBox, true);
            ChangeTextBoxStyle(SalaryTextBox, true);
            ChangeTextBoxStyle(EmploymentTypeTextBox, true);

            // Показываем кнопки сохранения/отмены
            EditButtonsPanel.Visibility = Visibility.Visible;

            // Меняем текст кнопки редактирования
            EditProfileButton.Content = "✏️ Редактируется...";
            EditProfileButton.IsEnabled = false;
        }

        private void DisableEditMode()
        {
            _isEditMode = false;

            // Запрещаем редактирование полей
            FullNameTextBox.IsReadOnly = true;
            EmailTextBox.IsReadOnly = true;
            PhoneTextBox.IsReadOnly = true;
            CityTextBox.IsReadOnly = true;
            ProfessionTextBox.IsReadOnly = true;
            ExperienceTextBox.IsReadOnly = true;
            EducationTextBox.IsReadOnly = true;
            SkillsTextBox.IsReadOnly = true;
            SalaryTextBox.IsReadOnly = true;
            EmploymentTypeTextBox.IsReadOnly = true;

            // Возвращаем стандартные стили полей
            ChangeTextBoxStyle(FullNameTextBox, false);
            ChangeTextBoxStyle(EmailTextBox, false);
            ChangeTextBoxStyle(PhoneTextBox, false);
            ChangeTextBoxStyle(CityTextBox, false);
            ChangeTextBoxStyle(ProfessionTextBox, false);
            ChangeTextBoxStyle(ExperienceTextBox, false);
            ChangeTextBoxStyle(EducationTextBox, false);
            ChangeTextBoxStyle(SkillsTextBox, false);
            ChangeTextBoxStyle(SalaryTextBox, false);
            ChangeTextBoxStyle(EmploymentTypeTextBox, false);

            // Скрываем кнопки сохранения/отмены
            EditButtonsPanel.Visibility = Visibility.Collapsed;

            // Возвращаем текст кнопки редактирования
            EditProfileButton.Content = "✏️ Редактировать";
            EditProfileButton.IsEnabled = true;
        }

        private void ChangeTextBoxStyle(TextBox textBox, bool isEditMode)
        {
            if (isEditMode)
            {
                // Стиль для режима редактирования
                textBox.Background = new SolidColorBrush(Color.FromRgb(61, 61, 61)); // #3D3D3D
                textBox.BorderBrush = new SolidColorBrush(Color.FromRgb(13, 115, 119)); // #0D7377
                textBox.Foreground = Brushes.White;
            }
            else
            {
                // Стиль для режима просмотра
                textBox.Background = new SolidColorBrush(Color.FromRgb(45, 45, 45)); // #2D2D2D
                textBox.BorderBrush = new SolidColorBrush(Color.FromRgb(61, 61, 61)); // #3D3D3D
                textBox.Foreground = new SolidColorBrush(Color.FromRgb(204, 204, 204)); // #CCCCCC
            }
        }

        private void EditProfileButton_Click(object sender, RoutedEventArgs e)
        {
            EnableEditMode();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateForm())
            {
                // Сохраняем оригинальные данные
                _originalFullName = FullNameTextBox.Text;
                _originalEmail = EmailTextBox.Text;
                _originalPhone = PhoneTextBox.Text;
                _originalCity = CityTextBox.Text;
                _originalProfession = ProfessionTextBox.Text;
                _originalExperience = ExperienceTextBox.Text;
                _originalEducation = EducationTextBox.Text;
                _originalSkills = SkillsTextBox.Text;
                _originalSalary = SalaryTextBox.Text;
                _originalEmploymentType = EmploymentTypeTextBox.Text;

                // Отключаем режим редактирования
                DisableEditMode();

                // Показываем сообщение об успешном сохранении
                MessageBox.Show("Профиль успешно сохранен!",
                              "Сохранено",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);

                // Здесь должна быть логика сохранения в базу данных
                SaveProfileToDatabase();
            }
        }

        private bool ValidateForm()
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(FullNameTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите ваше ФИО",
                              "Ошибка валидации",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                FullNameTextBox.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите ваш email",
                              "Ошибка валидации",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                EmailTextBox.Focus();
                return false;
            }

            if (!IsValidEmail(EmailTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите корректный email",
                              "Ошибка валидации",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                EmailTextBox.Focus();
                EmailTextBox.SelectAll();
                return false;
            }

            if (string.IsNullOrWhiteSpace(ProfessionTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите вашу профессию",
                              "Ошибка валидации",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                ProfessionTextBox.Focus();
                return false;
            }

            return true;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void SaveProfileToDatabase()
        {
            // Здесь должна быть логика сохранения профиля в базу данных
            // Временная заглушка
            var profileData = new
            {
                FullName = FullNameTextBox.Text,
                Email = EmailTextBox.Text,
                Phone = PhoneTextBox.Text,
                City = CityTextBox.Text,
                Profession = ProfessionTextBox.Text,
                Experience = ExperienceTextBox.Text,
                Education = EducationTextBox.Text,
                Skills = SkillsTextBox.Text,
                Salary = SalaryTextBox.Text,
                EmploymentType = EmploymentTypeTextBox.Text,
                LastUpdated = System.DateTime.Now
            };

            // В реальном приложении:
            // Database.SaveProfile(profileData);
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Восстанавливаем оригинальные данные
            FullNameTextBox.Text = _originalFullName;
            EmailTextBox.Text = _originalEmail;
            PhoneTextBox.Text = _originalPhone;
            CityTextBox.Text = _originalCity;
            ProfessionTextBox.Text = _originalProfession;
            ExperienceTextBox.Text = _originalExperience;
            EducationTextBox.Text = _originalEducation;
            SkillsTextBox.Text = _originalSkills;
            SalaryTextBox.Text = _originalSalary;
            EmploymentTypeTextBox.Text = _originalEmploymentType;

            // Отключаем режим редактирования
            DisableEditMode();

            MessageBox.Show("Изменения отменены. Данные восстановлены.",
                          "Отмена",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        // Метод для загрузки данных профиля из базы
        public void LoadProfileFromDatabase(string userId)
        {
            // В реальном приложении здесь будет загрузка данных из базы
            // Пример:
            // var profile = Database.GetProfile(userId);
            // FullNameTextBox.Text = profile.FullName;
            // EmailTextBox.Text = profile.Email;
            // и т.д.
        }

        // Метод для получения данных профиля
        public object GetProfileData()
        {
            return new
            {
                FullName = FullNameTextBox.Text,
                Email = EmailTextBox.Text,
                Phone = PhoneTextBox.Text,
                City = CityTextBox.Text,
                Profession = ProfessionTextBox.Text,
                Experience = ExperienceTextBox.Text,
                Education = EducationTextBox.Text,
                Skills = SkillsTextBox.Text,
                Salary = SalaryTextBox.Text,
                EmploymentType = EmploymentTypeTextBox.Text
            };
        }

        // Метод для проверки заполненности профиля
        public bool IsProfileComplete()
        {
            return !string.IsNullOrWhiteSpace(FullNameTextBox.Text) &&
                   !string.IsNullOrWhiteSpace(EmailTextBox.Text) &&
                   !string.IsNullOrWhiteSpace(ProfessionTextBox.Text);
        }

        // Метод для обновления данных извне (например, из анкеты)
        public void UpdateProfileData(string fullName, string email, string phone, string city,
                                     string profession, string experience, string education,
                                     string skills, string salary, string employmentType)
        {
            FullNameTextBox.Text = fullName;
            EmailTextBox.Text = email;
            PhoneTextBox.Text = phone;
            CityTextBox.Text = city;
            ProfessionTextBox.Text = profession;
            ExperienceTextBox.Text = experience;
            EducationTextBox.Text = education;
            SkillsTextBox.Text = skills;
            SalaryTextBox.Text = salary;
            EmploymentTypeTextBox.Text = employmentType;

            // Сохраняем как оригинальные данные
            _originalFullName = fullName;
            _originalEmail = email;
            _originalPhone = phone;
            _originalCity = city;
            _originalProfession = profession;
            _originalExperience = experience;
            _originalEducation = education;
            _originalSkills = skills;
            _originalSalary = salary;
            _originalEmploymentType = employmentType;
        }
    }
}

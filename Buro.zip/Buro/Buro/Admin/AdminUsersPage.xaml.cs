﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminUsersPage.xaml
    /// </summary>
    public partial class AdminUsersPage : Page
    {
        public AdminUsersPage()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            // Инициализация фильтра по ролям
            var roles = new List<string>
            {
                "Все роли",
                "Администратор",
                "Соискатель",
                "Работодатель"
            };

            RoleFilterComboBox.ItemsSource = roles;
            RoleFilterComboBox.SelectedIndex = 0;

            // Инициализация фильтра по статусу
            var statuses = new List<string>
            {
                "Все статусы",
                "Активен",
                "Заблокирован",
                "Не подтвержден",
                "Верифицирован"
            };

            StatusFilterComboBox.ItemsSource = statuses;
            StatusFilterComboBox.SelectedIndex = 0;
        }

        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Форма добавления нового пользователя:\n\n" +
                          "1. Выберите тип пользователя\n" +
                          "2. Заполните основные данные\n" +
                          "3. Назначьте права доступа",
                          "Добавление пользователя",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchText = SearchTextBox.Text.Trim();
            string role = RoleFilterComboBox.SelectedItem as string;
            string status = StatusFilterComboBox.SelectedItem as string;

            MessageBox.Show($"Поиск пользователей:\n\n" +
                          $"Текст: {searchText}\n" +
                          $"Роль: {role}\n" +
                          $"Статус: {status}",
                          "Результаты поиска",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ViewUserButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Просмотр подробной информации о пользователе:\n\n" +
                          "• Основная информация\n" +
                          "• История действий\n" +
                          "• Статистика\n" +
                          "• Настройки доступа",
                          "Просмотр пользователя",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void EditUserButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Редактирование данных пользователя:\n\n" +
                          "• Изменение личных данных\n" +
                          "• Смена роли\n" +
                          "• Настройка прав доступа\n" +
                          "• Изменение статуса",
                          "Редактирование пользователя",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void DeleteUserButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите удалить этого пользователя?\n\n" +
                                       "Все данные пользователя будут удалены безвозвратно.",
                                       "Удаление пользователя",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show("Пользователь удален успешно.",
                              "Удаление завершено",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }
        }
    }
}
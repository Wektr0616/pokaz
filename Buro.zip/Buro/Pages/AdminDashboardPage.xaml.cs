﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Buro.Entity;

namespace Buro.Pages
{
    public partial class AdminDashboardPage : Page
    {
        private EmploymentBureauEntities _context;
        private string _currentSection = "Users";
        private object _selectedItem = null;
        private bool _isEditing = false;
        private int _deleteItemId = 0;

        // Фильтры для комиссий
        private DateTime? _filterDateFrom = null;
        private DateTime? _filterDateTo = null;
        private string _filterCompanyName = "";

        // Словарь для хранения текстовых полей формы
        private Dictionary<string, TextBox> _textBoxes = new Dictionary<string, TextBox>();
        private Dictionary<string, PasswordBox> _passwordBoxes = new Dictionary<string, PasswordBox>();
        private Dictionary<string, ComboBox> _comboBoxes = new Dictionary<string, ComboBox>();
        private Dictionary<string, CheckBox> _checkBoxes = new Dictionary<string, CheckBox>();

        public AdminDashboardPage()
        {
            InitializeComponent();
            _context = EmploymentBureauEntities.GetContext();
            Loaded += Page_Loaded;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            object currentUser = App.Current.Properties["CurrentUser"];
            if (currentUser != null)
            {
                User user = currentUser as User;
                if (user != null)
                {
                    AdminNameText.Text = user.Email;
                }
            }

            LoadData();
            LoadStatistics();
        }

        // ═══════════════════════════════════════════════════════════════
        // УПРАВЛЕНИЕ ВИДИМОСТЬЮ СТОЛБЦОВ
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Настраивает видимость столбцов DataGrid в зависимости от текущей секции
        /// </summary>
        private void ConfigureGridColumns()
        {
            // Сначала показываем все столбцы
            ColID.Visibility = Visibility.Visible;
            ColTitle.Visibility = Visibility.Visible;
            ColSubtitle.Visibility = Visibility.Visible;
            ColCommission.Visibility = Visibility.Visible;
            ColStatus.Visibility = Visibility.Visible;
            ColDate.Visibility = Visibility.Visible;
            ColActions.Visibility = Visibility.Visible;

            switch (_currentSection)
            {
                case "Users":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Header = "СТАТУС";
                    ColDate.Header = "ДАТА";
                    break;

                case "Candidates":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Visibility = Visibility.Collapsed;
                    ColDate.Header = "ДАТА";
                    break;

                case "Employers":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Visibility = Visibility.Collapsed;
                    ColDate.Header = "ДАТА";
                    break;

                case "Vacancies":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Header = "СТАТУС";
                    ColDate.Header = "ДАТА";
                    break;

                case "Resumes":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Header = "СТАТУС";
                    ColDate.Header = "ДАТА";
                    break;

                case "Responses":
                    ColCommission.Visibility = Visibility.Collapsed;
                    ColStatus.Header = "СТАТУС";
                    ColDate.Header = "ДАТА";
                    break;

                case "Commissions":
                    ColCommission.Visibility = Visibility.Visible;
                    ColStatus.Header = "СТАТУС ОПЛАТЫ";
                    ColDate.Header = "ДАТА";
                    break;
            }
        }

        /// <summary>
        /// Обработчик загрузки DataGrid — дополнительная проверка видимости столбцов
        /// </summary>
        private void AdminDataGrid_Loaded(object sender, RoutedEventArgs e)
        {
            ConfigureGridColumns();
        }

        // Переключение меню
        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null) return;

            UsersMenu.Style = (Style)FindResource("MenuButton");
            CandidatesMenu.Style = (Style)FindResource("MenuButton");
            EmployersMenu.Style = (Style)FindResource("MenuButton");
            VacanciesMenu.Style = (Style)FindResource("MenuButton");
            ResumesMenu.Style = (Style)FindResource("MenuButton");
            ResponsesMenu.Style = (Style)FindResource("MenuButton");
            CommissionsMenu.Style = (Style)FindResource("MenuButton");

            btn.Style = (Style)FindResource("MenuButtonActive");

            _currentSection = btn.Tag.ToString();

            // Управляем видимостью кнопки фильтра
            FilterButton.Visibility = (_currentSection == "Commissions") ? Visibility.Visible : Visibility.Collapsed;

            HidePanels();
            LoadData();
            LoadStatistics();
        }

        private void HidePanels()
        {
            EditPanel.Visibility = Visibility.Collapsed;
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            DataPanel.Visibility = Visibility.Visible;
            ClearFormDictionaries();
        }

        private void ClearFormDictionaries()
        {
            _textBoxes.Clear();
            _passwordBoxes.Clear();
            _comboBoxes.Clear();
            _checkBoxes.Clear();
        }

        // ═══════════════════════════════════════════════════════════════
        // ЗАГРУЗКА СТАТИСТИКИ
        // ═══════════════════════════════════════════════════════════════
        private void LoadStatistics()
        {
            try
            {
                StatUsers.Text = _context.Users.Count().ToString();
                StatCandidates.Text = _context.Candidates.Count().ToString();
                StatEmployers.Text = _context.Employers.Count().ToString();
                StatVacancies.Text = _context.Vacancies.Count().ToString();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Stats error: {ex.Message}");
            }
        }

        // Загрузка данных
        private void LoadData()
        {
            try
            {
                _selectedItem = null;

                // Скрываем финансовые карточки по умолчанию
                CommissionProfitPanel.Visibility = Visibility.Collapsed;

                switch (_currentSection)
                {
                    case "Users":
                        LoadUsers();
                        break;
                    case "Candidates":
                        LoadCandidates();
                        break;
                    case "Employers":
                        LoadEmployers();
                        break;
                    case "Vacancies":
                        LoadVacancies();
                        break;
                    case "Resumes":
                        LoadResumes();
                        break;
                    case "Responses":
                        LoadResponses();
                        break;
                    case "Commissions":
                        LoadCommissions();
                        break;
                }

                ConfigureGridColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        // ViewModel для карточек
        public class DataCardViewModel
        {
            public int ID { get; set; }
            public string Title { get; set; }
            public string Subtitle { get; set; }
            public string Info1 { get; set; }
            public string Info2 { get; set; }
            public string Info3 { get; set; }
            public string Description { get; set; }
            public string DateInfo { get; set; }
            public string ExtraInfo { get; set; }
            public bool HasStatus { get; set; }
            public string StatusText { get; set; }
            public SolidColorBrush StatusColor { get; set; }
            public string CommissionInfo { get; set; }
            public string ProfitInfo { get; set; }
        }

        private void LoadUsers()
        {
            PageTitle.Text = "Управление пользователями";

            var users = _context.Users.Select(u => new
            {
                u.UserID,
                u.Email,
                u.Phone,
                RoleName = u.Role.RoleName,
                u.RegistrationDate,
                u.IsActive
            }).ToList();

            var cards = users.Select(u => new DataCardViewModel
            {
                ID = u.UserID,
                Title = u.Email,
                Subtitle = $"Роль: {u.RoleName}",
                Info1 = u.Phone,
                Info2 = "",
                Info3 = "",
                Description = "",
                DateInfo = $"Зарегистрирован: {u.RegistrationDate:dd.MM.yyyy}",
                ExtraInfo = u.IsActive == true ? "Активен" : "Неактивен",
                HasStatus = true,
                StatusText = u.IsActive == true ? "Активен" : "Неактивен",
                StatusColor = u.IsActive == true ? new SolidColorBrush(Colors.Green) : new SolidColorBrush(Colors.Gray),
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
            DataGridTitle.Text = "Список пользователей";
        }

        private void LoadCandidates()
        {
            PageTitle.Text = "Управление соискателями";

            var candidates = _context.Candidates.Select(c => new
            {
                c.CandidateID,
                c.FullName,
                c.Profession,
                c.ExperienceYears,
                c.Education,
                c.CreatedDate,
                Email = c.User.Email,
                Phone = c.User.Phone
            }).ToList();

            var cards = candidates.Select(c => new DataCardViewModel
            {
                ID = c.CandidateID,
                Title = c.FullName,
                Subtitle = c.Profession ?? "Профессия не указана",
                Info1 = $"Опыт: {c.ExperienceYears ?? 0} лет",
                Info2 = c.Education ?? "",
                Info3 = "",
                Description = $"Email: {c.Email} | Тел: {c.Phone}",
                DateInfo = $"Создан: {c.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = "",
                HasStatus = false,
                StatusText = "",
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
            DataGridTitle.Text = "Список соискателей";
        }

        private void LoadEmployers()
        {
            PageTitle.Text = "Управление работодателями";

            var employers = _context.Employers.Select(e => new
            {
                e.EmployerID,
                e.CompanyName,
                e.INN,
                e.ContactPerson,
                e.Industry,
                e.CreatedDate,
                Email = e.User.Email
            }).ToList();

            var cards = employers.Select(e => new DataCardViewModel
            {
                ID = e.EmployerID,
                Title = e.CompanyName,
                Subtitle = $"ИНН: {e.INN}",
                Info1 = e.Industry ?? "",
                Info2 = "",
                Info3 = "",
                Description = $"Контакт: {e.ContactPerson} | Email: {e.Email}",
                DateInfo = $"Создан: {e.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = "",
                HasStatus = false,
                StatusText = "",
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
            DataGridTitle.Text = "Список работодателей";
        }

        private void LoadVacancies()
        {
            PageTitle.Text = "Управление вакансиями";

            var vacancies = _context.Vacancies.Select(v => new
            {
                v.VacancyID,
                v.Position,
                EmployerName = v.Employer.CompanyName,
                v.SalaryFrom,
                v.SalaryTo,
                v.City,
                v.IsActive,
                v.CreatedDate,
                v.Description
            }).ToList();

            var cards = vacancies.Select(v => new DataCardViewModel
            {
                ID = v.VacancyID,
                Title = v.Position,
                Subtitle = v.EmployerName,
                Info1 = v.SalaryFrom.HasValue && v.SalaryTo.HasValue
                    ? $"{v.SalaryFrom:N0} - {v.SalaryTo:N0} ₽"
                    : v.SalaryFrom.HasValue ? $"от {v.SalaryFrom:N0} ₽"
                    : v.SalaryTo.HasValue ? $"до {v.SalaryTo:N0} ₽" : "ЗП по договоренности",
                Info2 = v.City ?? "Город не указан",
                Info3 = "",
                Description = v.Description ?? "",
                DateInfo = $"Создана: {v.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = "",
                HasStatus = true,
                StatusText = v.IsActive == true ? "Активна" : "Не активна",
                StatusColor = v.IsActive == true ? new SolidColorBrush(Colors.Green) : new SolidColorBrush(Colors.Gray),
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
            DataGridTitle.Text = "Список вакансий";
        }

        private void LoadResumes()
        {
            PageTitle.Text = "Управление резюме";

            var resumes = _context.Resumes.Select(r => new
            {
                r.ResumeID,
                r.Title,
                CandidateName = r.Candidate.FullName,
                r.SalaryExpectation,
                r.EmploymentType,
                r.IsVisible,
                r.Status,
                r.CreatedDate,
                r.Skills
            }).ToList();

            var cards = resumes.Select(r => new DataCardViewModel
            {
                ID = r.ResumeID,
                Title = r.Title,
                Subtitle = r.CandidateName,
                Info1 = r.SalaryExpectation.HasValue ? $"ЗП: {r.SalaryExpectation:N0} ₽" : "ЗП не указана",
                Info2 = r.EmploymentType ?? "",
                Info3 = "",
                Description = r.Skills ?? "",
                DateInfo = $"Создано: {r.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = $"Статус: {r.Status}",
                HasStatus = true,
                StatusText = r.IsVisible == true ? "Видимое" : "Скрыто",
                StatusColor = r.IsVisible == true ? new SolidColorBrush(Colors.Blue) : new SolidColorBrush(Colors.Gray),
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
            DataGridTitle.Text = "Список резюме";
        }

        private void LoadResponses()
        {
            PageTitle.Text = "Управление откликами";

            var responses = _context.CandidateResponses.Select(r => new
            {
                r.ResponseID,
                CandidateName = r.Candidate.FullName,
                VacancyName = r.Vacancy.Position,
                EmployerName = r.Vacancy.Employer.CompanyName,
                r.Status,
                r.ResponseDate,
                r.EmployerComment
            }).ToList();

            var cards = responses.Select(r => new DataCardViewModel
            {
                ID = r.ResponseID,
                Title = r.CandidateName,
                Subtitle = $"→ {r.VacancyName}",
                Info1 = r.EmployerName,
                Info2 = "",
                Info3 = "",
                Description = r.EmployerComment ?? "",
                DateInfo = $"Отклик: {r.ResponseDate:dd.MM.yyyy HH:mm}",
                ExtraInfo = "",
                HasStatus = true,
                StatusText = r.Status,
                StatusColor = GetStatusColor(r.Status),
                CommissionInfo = ""
            }).ToList();

            AdminDataGrid.ItemsSource = cards;
            PageSubtitle.Text = $"Всего записей: {cards.Count}";
            DataGridTitle.Text = "Список откликов";
        }

        // ═══════════════════════════════════════════════════════════════
        // РАЗДЕЛ КОМИССИЙ С ФИЛЬТРАЦИЕЙ И ПРИБЫЛЬЮ
        // ═══════════════════════════════════════════════════════════════
        private void LoadCommissions()
        {
            PageTitle.Text = "Управление комиссиями";
            // Базовый запрос
            var query = _context.CommissionHistories.AsQueryable();
            // Применяем фильтры
            if (_filterDateFrom.HasValue)
            {
                query = query.Where(c => c.CreatedDate >= _filterDateFrom.Value);
            }
            if (_filterDateTo.HasValue)
            {
                var dateTo = _filterDateTo.Value.AddDays(1).AddSeconds(-1);
                query = query.Where(c => c.CreatedDate <= dateTo);
            }
            if (!string.IsNullOrWhiteSpace(_filterCompanyName))
            {
                query = query.Where(c => c.Employer != null && c.Employer.CompanyName.Contains(_filterCompanyName));
            }
            var commissions = query
                .Select(ch => new
                {
                    ch.CommissionID,
                    CandidateName = ch.Candidate.FullName,
                    EmployerName = ch.Employer.CompanyName,
                    VacancyPosition = ch.Vacancy.Position,
                    ch.AnnualSalary,
                    ch.CommissionPercent,
                    ch.CommissionAmount,
                    ch.PaymentStatus,
                    ch.PaymentDate,
                    ch.InvoiceNumber,
                    ch.CreatedDate,
                    ch.Notes
                })
                .OrderByDescending(c => c.CreatedDate)
                .ToList();
            // ═══════════════════════════════════════════════
            // ФИНАНСОВЫЕ КАРТОЧКИ
            // ═══════════════════════════════════════════════
            var totalProfit = commissions.Sum(x => x.CommissionAmount);
            var paidProfit = commissions.Where(x => x.PaymentStatus == "Оплачено").Sum(x => x.CommissionAmount);
            var pendingProfit = commissions.Where(x => x.PaymentStatus == "Ожидает оплаты").Sum(x => x.CommissionAmount);
            var cancelledProfit = commissions.Where(x => x.PaymentStatus == "Отменено").Sum(x => x.CommissionAmount);
            StatTotalProfit.Text = $"{totalProfit:N0} ₽";
            StatPaidProfit.Text = $"{paidProfit:N0} ₽";
            StatPendingProfit.Text = $"{pendingProfit:N0} ₽";
            StatCancelledProfit.Text = $"{cancelledProfit:N0} ₽";
            // Показываем панель финансовых карточек
            CommissionProfitPanel.Visibility = Visibility.Visible;
            var cards = commissions.Select(c => new DataCardViewModel
            {
                ID = c.CommissionID,
                Title = $"{c.CandidateName} → {c.EmployerName}",
                Subtitle = c.VacancyPosition,
                Info1 = $"💰 Комиссия: {c.CommissionAmount:N0} ₽ ({c.CommissionPercent}%)",
                Info2 = $"📅 Годовой оклад: {c.AnnualSalary:N0} ₽",
                Info3 = $"🏢 {c.EmployerName}",
                Description = c.Notes ?? "",
                DateInfo = c.PaymentDate.HasValue
                    ? $"Оплачено: {c.PaymentDate:dd.MM.yyyy}"
                    : $"Создано: {c.CreatedDate:dd.MM.yyyy}",
                ExtraInfo = c.PaymentStatus,
                HasStatus = true,
                StatusText = c.PaymentStatus,
                StatusColor = GetCommissionStatusColor(c.PaymentStatus),
                CommissionInfo = $"{c.CommissionAmount:N0} ₽",
                ProfitInfo = $"Прибыль: {c.CommissionAmount:N0} ₽"
            }).ToList();
            AdminDataGrid.ItemsSource = cards;
            // Упрощённый подзаголовок — цифры теперь в карточках
            var sb = new StringBuilder();
            sb.Append($"Всего записей: {cards.Count}");
            if (_filterDateFrom.HasValue || _filterDateTo.HasValue || !string.IsNullOrWhiteSpace(_filterCompanyName))
            {
                sb.Append("  [Фильтры: ");
                var filters = new List<string>();
                if (_filterDateFrom.HasValue) filters.Add($"с {_filterDateFrom.Value:dd.MM.yyyy}");
                if (_filterDateTo.HasValue) filters.Add($"по {_filterDateTo.Value:dd.MM.yyyy}");
                if (!string.IsNullOrWhiteSpace(_filterCompanyName)) filters.Add($"компания: {_filterCompanyName}");
                sb.Append(string.Join(", ", filters));
                sb.Append("]");
            }
            PageSubtitle.Text = sb.ToString();
            DataGridTitle.Text = "История комиссий за трудоустройства";
        }
        // ═══════════════════════════════════════════════════════════════
        // УЛУЧШЕННАЯ ФИЛЬТРАЦИЯ КОМИССИЙ — ТОЛЬКО DatePicker
        // ═══════════════════════════════════════════════════════════════
        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            ShowCommissionFilters();
        }

        private void ShowCommissionFilters()
        {
            EditPanel.Visibility = Visibility.Visible;
            DataPanel.Visibility = Visibility.Collapsed;
            EditPanelTitle.Text = "🔍 Фильтрация комиссий";
            SaveButton.Content = "Применить фильтры";
            SaveButton.Click -= SaveButton_Click;
            SaveButton.Click += ApplyCommissionFilters_Click;

            EditFormContainer.Children.Clear();
            ClearFormDictionaries();

            // === Дата "с" — только DatePicker ===
            var dateFromPanel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };
            dateFromPanel.Children.Add(new TextBlock
            {
                Text = "Дата с:",
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            });

            var dateFromPicker = new DatePicker
            {
                Name = "DateFromPicker",
                SelectedDate = _filterDateFrom,
                DisplayDateEnd = DateTime.Today,
                Language = System.Windows.Markup.XmlLanguage.GetLanguage("ru-RU"),
                Padding = new Thickness(10),
                BorderBrush = new SolidColorBrush(Colors.LightGray),
                BorderThickness = new Thickness(1),
                FontSize = 14
            };
            dateFromPanel.Children.Add(dateFromPicker);
            EditFormContainer.Children.Add(dateFromPanel);

            // === Дата "по" — только DatePicker ===
            var dateToPanel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };
            dateToPanel.Children.Add(new TextBlock
            {
                Text = "Дата по:",
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            });

            var dateToPicker = new DatePicker
            {
                Name = "DateToPicker",
                SelectedDate = _filterDateTo,
                DisplayDateEnd = DateTime.Today,
                Language = System.Windows.Markup.XmlLanguage.GetLanguage("ru-RU"),
                Padding = new Thickness(10),
                BorderBrush = new SolidColorBrush(Colors.LightGray),
                BorderThickness = new Thickness(1),
                FontSize = 14
            };
            dateToPanel.Children.Add(dateToPicker);
            EditFormContainer.Children.Add(dateToPanel);

            // === Название компании ===
            AddFormField("Название компании:", "CompanyName", _filterCompanyName);

            // === Быстрые фильтры по дате ===
            var quickFilterPanel = new StackPanel { Margin = new Thickness(0, 10, 0, 10) };
            quickFilterPanel.Children.Add(new TextBlock
            {
                Text = "Быстрый выбор периода:",
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 8),
                Foreground = new SolidColorBrush(Colors.DarkSlateGray)
            });

            var quickButtonsWrap = new WrapPanel { Orientation = Orientation.Horizontal };

            string[] quickFilters = { "Сегодня", "Вчера", "Неделя", "Месяц", "Год", "Всё время" };
            foreach (var filter in quickFilters)
            {
                var quickBtn = new Button
                {
                    Content = filter,
                    Margin = new Thickness(0, 0, 8, 8),
                    Padding = new Thickness(12, 6, 12, 6),
                    Background = new SolidColorBrush(Color.FromRgb(240, 240, 240)),
                    Foreground = new SolidColorBrush(Colors.DarkSlateGray),
                    BorderThickness = new Thickness(1),
                    BorderBrush = new SolidColorBrush(Colors.LightGray),
                    Cursor = System.Windows.Input.Cursors.Hand,
                    FontSize = 12
                };
                quickBtn.Click += (s, ev) => ApplyQuickDateFilter(filter, dateFromPicker, dateToPicker);
                quickButtonsWrap.Children.Add(quickBtn);
            }

            quickFilterPanel.Children.Add(quickButtonsWrap);
            EditFormContainer.Children.Add(quickFilterPanel);

            // === Кнопка сброса ===
            var resetPanel = new StackPanel { Margin = new Thickness(0, 15, 0, 0) };
            var resetButton = new Button
            {
                Content = "🔄 Сбросить все фильтры",
                Background = new SolidColorBrush(Colors.Gray),
                Foreground = new SolidColorBrush(Colors.White),
                Padding = new Thickness(15, 10, 15, 10),
                BorderThickness = new Thickness(0),
                Cursor = System.Windows.Input.Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Left,
                FontSize = 13
            };
            resetButton.Click += ResetFilters_Click;
            resetPanel.Children.Add(resetButton);
            EditFormContainer.Children.Add(resetPanel);

            // === Информация о текущих фильтрах ===
            if (_filterDateFrom.HasValue || _filterDateTo.HasValue || !string.IsNullOrWhiteSpace(_filterCompanyName))
            {
                var currentFilterPanel = new Border
                {
                    Background = new SolidColorBrush(Color.FromRgb(232, 245, 233)),
                    CornerRadius = new CornerRadius(8),
                    Padding = new Thickness(15),
                    Margin = new Thickness(0, 15, 0, 0),
                    BorderBrush = new SolidColorBrush(Color.FromRgb(129, 199, 132)),
                    BorderThickness = new Thickness(1)
                };

                var currentFilterStack = new StackPanel();
                currentFilterStack.Children.Add(new TextBlock
                {
                    Text = "📋 Текущие фильтры:",
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(Color.FromRgb(27, 94, 32)),
                    Margin = new Thickness(0, 0, 0, 8)
                });

                var filtersList = new StringBuilder();
                if (_filterDateFrom.HasValue) filtersList.AppendLine($"• С: {_filterDateFrom.Value:dd.MM.yyyy}");
                if (_filterDateTo.HasValue) filtersList.AppendLine($"• По: {_filterDateTo.Value:dd.MM.yyyy}");
                if (!string.IsNullOrWhiteSpace(_filterCompanyName)) filtersList.AppendLine($"• Компания: {_filterCompanyName}");

                currentFilterStack.Children.Add(new TextBlock
                {
                    Text = filtersList.ToString().TrimEnd(),
                    Foreground = new SolidColorBrush(Color.FromRgb(46, 125, 50)),
                    LineHeight = 20
                });

                currentFilterPanel.Child = currentFilterStack;
                EditFormContainer.Children.Add(currentFilterPanel);
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // БЫСТРЫЕ ФИЛЬТРЫ ПО ДАТЕ
        // ═══════════════════════════════════════════════════════════════

        private void ApplyQuickDateFilter(string filterType, DatePicker fromPicker, DatePicker toPicker)
        {
            DateTime today = DateTime.Today;

            switch (filterType)
            {
                case "Сегодня":
                    _filterDateFrom = today;
                    _filterDateTo = today;
                    break;
                case "Вчера":
                    _filterDateFrom = today.AddDays(-1);
                    _filterDateTo = today.AddDays(-1);
                    break;
                case "Неделя":
                    _filterDateFrom = today.AddDays(-7);
                    _filterDateTo = today;
                    break;
                case "Месяц":
                    _filterDateFrom = today.AddMonths(-1);
                    _filterDateTo = today;
                    break;
                case "Год":
                    _filterDateFrom = today.AddYears(-1);
                    _filterDateTo = today;
                    break;
                case "Всё время":
                    _filterDateFrom = null;
                    _filterDateTo = null;
                    break;
            }

            if (fromPicker != null)
                fromPicker.SelectedDate = _filterDateFrom;

            if (toPicker != null)
                toPicker.SelectedDate = _filterDateTo;
        }

        // ═══════════════════════════════════════════════════════════════
        // ПРИМЕНЕНИЕ И СБРОС ФИЛЬТРОВ
        // ═══════════════════════════════════════════════════════════════

        private void ApplyCommissionFilters_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var fromPicker = FindVisualChild<DatePicker>(EditFormContainer, "DateFromPicker");
                var toPicker = FindVisualChild<DatePicker>(EditFormContainer, "DateToPicker");

                _filterDateFrom = fromPicker?.SelectedDate;
                _filterDateTo = toPicker?.SelectedDate;

                if (_filterDateFrom.HasValue && _filterDateTo.HasValue && _filterDateFrom > _filterDateTo)
                {
                    MessageBox.Show("Дата 'с' не может быть позже даты 'по'.",
                        "Ошибка диапазона",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                _filterCompanyName = GetTextValue("CompanyName");

                SaveButton.Click -= ApplyCommissionFilters_Click;
                SaveButton.Click += SaveButton_Click;

                HidePanels();
                LoadCommissions();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка применения фильтров: " + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ResetFilters_Click(object sender, RoutedEventArgs e)
        {
            _filterDateFrom = null;
            _filterDateTo = null;
            _filterCompanyName = "";

            SaveButton.Click -= ApplyCommissionFilters_Click;
            SaveButton.Click += SaveButton_Click;

            HidePanels();
            LoadCommissions();

            MessageBox.Show("Все фильтры сброшены. Показаны все записи.", "Информация",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Вспомогательный метод для поиска элемента в визуальном дереве
        private T FindVisualChild<T>(DependencyObject parent, string name) where T : FrameworkElement
        {
            if (parent == null) return null;

            int childCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is T typedChild && typedChild.Name == name)
                    return typedChild;

                var result = FindVisualChild<T>(child, name);
                if (result != null)
                    return result;
            }
            return null;
        }

        private SolidColorBrush GetCommissionStatusColor(string status)
        {
            switch (status?.ToLower())
            {
                case "оплачено":
                    return new SolidColorBrush(Colors.Green);
                case "ожидает оплаты":
                    return new SolidColorBrush(Colors.Orange);
                case "отменено":
                    return new SolidColorBrush(Colors.Gray);
                default:
                    return new SolidColorBrush(Colors.Blue);
            }
        }

        private SolidColorBrush GetStatusColor(string status)
        {
            switch (status?.ToLower())
            {
                case "новый":
                    return new SolidColorBrush(Colors.Blue);
                case "на рассмотрении":
                    return new SolidColorBrush(Colors.Orange);
                case "приглашен на собеседование":
                    return new SolidColorBrush(Colors.Purple);
                case "принят на работу":
                    return new SolidColorBrush(Colors.Green);
                case "отклонен":
                    return new SolidColorBrush(Colors.Red);
                default:
                    return new SolidColorBrush(Colors.Gray);
            }
        }

        // Обработчики кнопок карточек
        private void EditItem_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null) return;

            int id = (int)btn.Tag;
            EditItemById(id);
        }

        private void ViewItem_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null) return;

            int id = (int)btn.Tag;
            MessageBox.Show($"Просмотр записи ID: {id}", "Просмотр", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void DeleteItem_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null) return;

            _deleteItemId = (int)btn.Tag;

            string name = "Unknown";
            var item = AdminDataGrid.ItemsSource as List<DataCardViewModel>;
            if (item != null)
            {
                var card = item.FirstOrDefault(x => x.ID == _deleteItemId);
                if (card != null) name = card.Title;
            }

            DeleteConfirmText.Text = $"Вы уверены, что хотите удалить '{name}'?\n\nЭто действие нельзя отменить!";
            DeleteConfirmPanel.Visibility = Visibility.Visible;
            DataPanel.Visibility = Visibility.Collapsed;
        }

        private void EditItemById(int id)
        {
            _isEditing = true;
            _selectedItem = new { ID = id };

            EditPanel.Visibility = Visibility.Visible;
            DataPanel.Visibility = Visibility.Collapsed;
            EditPanelTitle.Text = "Редактирование записи";
            SaveButton.Content = "💾 Сохранить изменения";
            SaveButton.Click -= ApplyCommissionFilters_Click;
            SaveButton.Click += SaveButton_Click;

            BuildEditForm(id);
        }

        // Кнопка добавления
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentSection == "Commissions")
            {
                ShowCommissionFilters();
                return;
            }

            _isEditing = false;
            _selectedItem = null;

            EditPanel.Visibility = Visibility.Visible;
            DataPanel.Visibility = Visibility.Collapsed;
            EditPanelTitle.Text = "Добавление новой записи";
            SaveButton.Content = "➕ Добавить запись";
            SaveButton.Click -= ApplyCommissionFilters_Click;
            SaveButton.Click += SaveButton_Click;

            BuildEditForm(0);
        }

        // Построение формы редактирования/добавления
        private void BuildEditForm(int id)
        {
            EditFormContainer.Children.Clear();
            ClearFormDictionaries();

            if (_currentSection == "Users")
            {
                BuildUserForm(id);
            }
            else if (_currentSection == "Candidates")
            {
                BuildCandidateForm(id);
            }
            else if (_currentSection == "Employers")
            {
                BuildEmployerForm(id);
            }
            else if (_currentSection == "Vacancies")
            {
                BuildVacancyForm(id);
            }
            else if (_currentSection == "Resumes")
            {
                BuildResumeForm(id);
            }
            else if (_currentSection == "Responses")
            {
                BuildResponseForm(id);
            }
            else if (_currentSection == "Commissions")
            {
                BuildCommissionForm(id);
            }
        }

        // Форма пользователя
        private void BuildUserForm(int id)
        {
            string email = "";
            string phone = "";
            string roleName = "Candidate";
            bool isActive = true;

            if (_isEditing && id > 0)
            {
                var user = _context.Users.Find(id);
                if (user != null)
                {
                    email = user.Email;
                    phone = user.Phone;
                    roleName = user.Role.RoleName;
                    isActive = user.IsActive ?? true;
                }
            }

            AddFormField("Email:", "Email", email);
            AddFormField("Телефон:", "Phone", phone);
            AddPasswordField("Пароль (оставьте пустым, чтобы не менять):", "Password");

            var roles = _context.Roles.Select(r => r.RoleName).ToList();
            AddComboBoxField("Роль:", "Role", roles, roleName);

            AddCheckBoxField("Активен:", "IsActive", isActive);
        }

        // Форма соискателя
        private void BuildCandidateForm(int id)
        {
            string fullName = "";
            string profession = "";
            string experience = "";
            string education = "";
            string email = "";
            string phone = "";

            if (_isEditing && id > 0)
            {
                var candidate = _context.Candidates.Find(id);
                if (candidate != null)
                {
                    fullName = candidate.FullName;
                    profession = candidate.Profession;
                    experience = candidate.ExperienceYears?.ToString() ?? "";
                    education = candidate.Education;
                    email = candidate.User.Email;
                    phone = candidate.User.Phone;
                }
            }

            if (!_isEditing)
            {
                AddFormField("Email:", "Email", "");
                AddFormField("Телефон:", "Phone", "");
                AddPasswordField("Пароль:", "Password");
            }
            else
            {
                AddFormField("Email:", "Email", email, true);
                AddFormField("Телефон:", "Phone", phone, true);
            }

            AddFormField("ФИО:", "FullName", fullName);
            AddFormField("Профессия:", "Profession", profession);
            AddFormField("Опыт работы (лет):", "Experience", experience);
            AddFormField("Образование:", "Education", education);
        }

        // Форма работодателя
        private void BuildEmployerForm(int id)
        {
            string companyName = "";
            string inn = "";
            string contactPerson = "";
            string industry = "";
            string email = "";
            string phone = "";

            if (_isEditing && id > 0)
            {
                var employer = _context.Employers.Find(id);
                if (employer != null)
                {
                    companyName = employer.CompanyName;
                    inn = employer.INN;
                    contactPerson = employer.ContactPerson;
                    industry = employer.Industry;
                    email = employer.User.Email;
                    phone = employer.User.Phone;
                }
            }

            if (!_isEditing)
            {
                AddFormField("Email:", "Email", "");
                AddFormField("Телефон:", "Phone", "");
                AddPasswordField("Пароль:", "Password");
            }
            else
            {
                AddFormField("Email:", "Email", email, true);
                AddFormField("Телефон:", "Phone", phone, true);
            }

            AddFormField("Название компании:", "CompanyName", companyName);
            AddFormField("ИНН:", "INN", inn);
            AddFormField("Контактное лицо:", "ContactPerson", contactPerson);
            AddFormField("Отрасль:", "Industry", industry);
        }

        // Форма вакансии
        private void BuildVacancyForm(int id)
        {
            string position = "";
            string salaryFrom = "";
            string salaryTo = "";
            string city = "";
            string description = "";
            string requirements = "";
            bool isActive = true;
            int selectedEmployerId = 0;

            if (_isEditing && id > 0)
            {
                var vacancy = _context.Vacancies.Find(id);
                if (vacancy != null)
                {
                    position = vacancy.Position;
                    salaryFrom = vacancy.SalaryFrom?.ToString() ?? "";
                    salaryTo = vacancy.SalaryTo?.ToString() ?? "";
                    city = vacancy.City;
                    isActive = vacancy.IsActive ?? true;
                    selectedEmployerId = vacancy.EmployerID;
                    description = vacancy.Description ?? "";
                    requirements = vacancy.Requirements ?? "";
                }
            }

            var employers = _context.Employers.Select(e => new { Id = e.EmployerID, Text = e.CompanyName }).ToList<dynamic>();
            AddEmployerComboBox("Работодатель:", "Employer", employers, selectedEmployerId);

            AddFormField("Должность:", "Position", position);
            AddFormField("Зарплата от:", "SalaryFrom", salaryFrom);
            AddFormField("Зарплата до:", "SalaryTo", salaryTo);
            AddFormField("Город:", "City", city);
            AddFormField("Описание:", "Description", description, false, true);
            AddFormField("Требования:", "Requirements", requirements, false, true);
            AddCheckBoxField("Активна:", "IsActive", isActive);
        }

        // Форма резюме
        private void BuildResumeForm(int id)
        {
            string title = "";
            string salary = "";
            string status = "Опубликовано";
            bool isVisible = true;

            if (_isEditing && id > 0)
            {
                var resume = _context.Resumes.Find(id);
                if (resume != null)
                {
                    title = resume.Title;
                    salary = resume.SalaryExpectation?.ToString() ?? "";
                    status = resume.Status;
                    isVisible = resume.IsVisible ?? true;
                }
            }

            AddFormField("Название резюме:", "Title", title);
            AddFormField("Ожидаемая зарплата:", "Salary", salary);

            var statuses = new List<string> { "Опубликовано", "На проверке", "Черновик", "Архив" };
            AddComboBoxField("Статус:", "Status", statuses, status);

            AddCheckBoxField("Видимое для работодателей:", "IsVisible", isVisible);
        }

        // Форма отклика
        private void BuildResponseForm(int id)
        {
            string status = "";
            string comment = "";

            if (_isEditing && id > 0)
            {
                var response = _context.CandidateResponses.Find(id);
                if (response != null)
                {
                    status = response.Status;
                    comment = response.EmployerComment;
                }
            }

            var statuses = new List<string> { "Новый", "На рассмотрении", "Приглашен на собеседование", "Отклонен", "Принят на работу" };
            AddComboBoxField("Статус отклика:", "Status", statuses, status);

            AddFormField("Комментарий работодателя:", "Comment", comment, false, true);
        }

        // Форма комиссии
        private void BuildCommissionForm(int id)
        {
            string candidateName = "";
            string employerName = "";
            string vacancyPosition = "";
            string annualSalary = "";
            string commissionPercent = "";
            string commissionAmount = "";
            string paymentStatus = "Ожидает оплаты";
            string paymentDate = "";
            string invoiceNumber = "";
            string notes = "";

            if (_isEditing && id > 0)
            {
                var commission = _context.CommissionHistories.Find(id);
                if (commission != null)
                {
                    candidateName = commission.Candidate.FullName;
                    employerName = commission.Employer.CompanyName;
                    vacancyPosition = commission.Vacancy.Position;
                    annualSalary = commission.AnnualSalary.ToString();
                    commissionPercent = commission.CommissionPercent.ToString();
                    commissionAmount = commission.CommissionAmount.ToString();
                    paymentStatus = commission.PaymentStatus;
                    paymentDate = commission.PaymentDate?.ToString("yyyy-MM-dd") ?? "";
                    invoiceNumber = commission.InvoiceNumber ?? "";
                    notes = commission.Notes ?? "";
                }
            }

            AddFormField("Кандидат:", "CandidateName", candidateName, true);
            AddFormField("Работодатель:", "EmployerName", employerName, true);
            AddFormField("Вакансия:", "VacancyPosition", vacancyPosition, true);

            AddFormField("Годовой оклад (₽):", "AnnualSalary", annualSalary);
            AddFormField("Процент комиссии (%):", "CommissionPercent", commissionPercent);
            AddFormField("Сумма комиссии (₽):", "CommissionAmount", commissionAmount);

            var statuses = new List<string> { "Ожидает оплаты", "Оплачено", "Отменено" };
            AddComboBoxField("Статус оплаты:", "PaymentStatus", statuses, paymentStatus);

            AddFormField("Дата оплаты (ГГГГ-ММ-ДД):", "PaymentDate", paymentDate);
            AddFormField("Номер счёта/акта:", "InvoiceNumber", invoiceNumber);
            AddFormField("Примечания:", "Notes", notes, false, true);
        }

        // Вспомогательные методы создания полей формы
        private void AddFormField(string label, string fieldName, string value, bool isReadOnly = false, bool isMultiline = false)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };

            var labelBlock = new TextBlock
            {
                Text = label,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            };
            panel.Children.Add(labelBlock);

            Control inputControl;

            if (isMultiline)
            {
                inputControl = new TextBox
                {
                    Name = fieldName,
                    Text = value,
                    TextWrapping = TextWrapping.Wrap,
                    AcceptsReturn = true,
                    Height = 80,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                    Padding = new Thickness(10),
                    BorderBrush = new SolidColorBrush(Colors.LightGray),
                    BorderThickness = new Thickness(1),
                    IsReadOnly = isReadOnly,
                    Background = isReadOnly ? new SolidColorBrush(Colors.LightGray) : new SolidColorBrush(Colors.White)
                };
            }
            else
            {
                inputControl = new TextBox
                {
                    Name = fieldName,
                    Text = value,
                    Padding = new Thickness(10),
                    BorderBrush = new SolidColorBrush(Colors.LightGray),
                    BorderThickness = new Thickness(1),
                    IsReadOnly = isReadOnly,
                    Background = isReadOnly ? new SolidColorBrush(Colors.LightGray) : new SolidColorBrush(Colors.White)
                };
            }

            panel.Children.Add(inputControl);
            EditFormContainer.Children.Add(panel);

            _textBoxes[fieldName] = inputControl as TextBox;
        }

        private void AddPasswordField(string label, string fieldName)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };

            panel.Children.Add(new TextBlock
            {
                Text = label,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            });

            var passwordBox = new PasswordBox
            {
                Name = fieldName,
                Padding = new Thickness(10),
                BorderBrush = new SolidColorBrush(Colors.LightGray),
                BorderThickness = new Thickness(1)
            };

            panel.Children.Add(passwordBox);
            EditFormContainer.Children.Add(panel);

            _passwordBoxes[fieldName] = passwordBox;
        }

        private void AddComboBoxField(string label, string fieldName, List<string> items, string selectedValue)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };

            panel.Children.Add(new TextBlock
            {
                Text = label,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            });

            var comboBox = new ComboBox
            {
                Name = fieldName,
                Padding = new Thickness(10),
                BorderBrush = new SolidColorBrush(Colors.LightGray),
                BorderThickness = new Thickness(1)
            };

            foreach (var item in items)
            {
                comboBox.Items.Add(item);
            }

            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                if (comboBox.Items[i].ToString() == selectedValue)
                {
                    comboBox.SelectedIndex = i;
                    break;
                }
            }

            if (comboBox.SelectedIndex < 0 && comboBox.Items.Count > 0)
                comboBox.SelectedIndex = 0;

            panel.Children.Add(comboBox);
            EditFormContainer.Children.Add(panel);

            _comboBoxes[fieldName] = comboBox;
        }

        private void AddEmployerComboBox(string label, string fieldName, List<dynamic> items, int selectedId)
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 15) };

            panel.Children.Add(new TextBlock
            {
                Text = label,
                FontWeight = FontWeights.SemiBold,
                Margin = new Thickness(0, 0, 0, 5)
            });

            var comboBox = new ComboBox
            {
                Name = fieldName,
                Padding = new Thickness(10),
                BorderBrush = new SolidColorBrush(Colors.LightGray),
                BorderThickness = new Thickness(1),
                DisplayMemberPath = "Text",
                SelectedValuePath = "Id"
            };

            foreach (var item in items)
            {
                comboBox.Items.Add(item);
            }

            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                dynamic item = comboBox.Items[i];
                if (item.Id == selectedId)
                {
                    comboBox.SelectedIndex = i;
                    break;
                }
            }

            if (comboBox.SelectedIndex < 0 && comboBox.Items.Count > 0)
                comboBox.SelectedIndex = 0;

            panel.Children.Add(comboBox);
            EditFormContainer.Children.Add(panel);

            _comboBoxes[fieldName] = comboBox;
        }

        private void AddCheckBoxField(string label, string fieldName, bool isChecked)
        {
            var panel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 10, 0, 10)
            };

            var checkBox = new CheckBox
            {
                Name = fieldName,
                IsChecked = isChecked,
                Margin = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center
            };

            var labelBlock = new TextBlock
            {
                Text = label,
                VerticalAlignment = VerticalAlignment.Center
            };

            panel.Children.Add(checkBox);
            panel.Children.Add(labelBlock);
            EditFormContainer.Children.Add(panel);

            _checkBoxes[fieldName] = checkBox;
        }

        // Сохранение данных
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateForm())
                    return;

                if (_isEditing)
                {
                    UpdateExistingRecord();
                    MessageBox.Show("Изменения успешно сохранены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    CreateNewRecord();
                    MessageBox.Show("Новая запись успешно добавлена!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                HidePanels();
                LoadData();
                LoadStatistics();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateForm()
        {
            if (_currentSection == "Users" || (!_isEditing && (_currentSection == "Candidates" || _currentSection == "Employers")))
            {
                if (string.IsNullOrWhiteSpace(GetTextValue("Email")))
                {
                    MessageBox.Show("Email обязателен для заполнения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                if (!_isEditing && string.IsNullOrWhiteSpace(GetPasswordValue("Password")))
                {
                    MessageBox.Show("Пароль обязателен для новых записей!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }
            }

            if (_currentSection == "Commissions")
            {
                if (string.IsNullOrWhiteSpace(GetTextValue("AnnualSalary")))
                {
                    MessageBox.Show("Годовой оклад обязателен для заполнения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }
                if (string.IsNullOrWhiteSpace(GetTextValue("CommissionPercent")))
                {
                    MessageBox.Show("Процент комиссии обязателен для заполнения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }
            }

            return true;
        }

        private void CreateNewRecord()
        {
            if (_currentSection == "Users")
            {
                CreateUser();
            }
            else if (_currentSection == "Candidates")
            {
                CreateCandidate();
            }
            else if (_currentSection == "Employers")
            {
                CreateEmployer();
            }
            else if (_currentSection == "Vacancies")
            {
                CreateVacancy();
            }
            else if (_currentSection == "Commissions")
            {
                CreateCommission();
            }
        }

        private void UpdateExistingRecord()
        {
            dynamic item = _selectedItem;
            int id = item.ID;

            if (_currentSection == "Users")
            {
                UpdateUser(id);
            }
            else if (_currentSection == "Candidates")
            {
                UpdateCandidate(id);
            }
            else if (_currentSection == "Employers")
            {
                UpdateEmployer(id);
            }
            else if (_currentSection == "Vacancies")
            {
                UpdateVacancy(id);
            }
            else if (_currentSection == "Resumes")
            {
                UpdateResume(id);
            }
            else if (_currentSection == "Responses")
            {
                UpdateResponse(id);
            }
            else if (_currentSection == "Commissions")
            {
                UpdateCommission(id);
            }
        }

        // Методы создания записей
        private void CreateUser()
        {
            string email = GetTextValue("Email");

            if (_context.Users.Any(u => u.Email == email))
                throw new Exception("Пользователь с таким email уже существует!");

            string roleName = GetComboValue("Role");
            var role = _context.Roles.FirstOrDefault(r => r.RoleName == roleName);
            if (role == null)
                throw new Exception("Роль не найдена!");

            var user = new User
            {
                Email = email,
                Phone = GetTextValue("Phone"),
                PasswordHash = GetPasswordValue("Password"),
                RoleID = role.RoleID,
                IsActive = GetCheckValue("IsActive"),
                RegistrationDate = DateTime.Now
            };

            _context.Users.Add(user);
            _context.SaveChanges();
        }

        private void CreateCandidate()
        {
            string email = GetTextValue("Email");

            if (_context.Users.Any(u => u.Email == email))
                throw new Exception("Пользователь с таким email уже существует!");

            var user = new User
            {
                Email = email,
                Phone = GetTextValue("Phone"),
                PasswordHash = GetPasswordValue("Password"),
                RoleID = 2,
                IsActive = true,
                RegistrationDate = DateTime.Now
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            var candidate = new Candidate
            {
                CandidateID = user.UserID,
                FullName = GetTextValue("FullName"),
                Profession = GetTextValue("Profession"),
                ExperienceYears = ParseInt(GetTextValue("Experience")),
                Education = GetTextValue("Education"),
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now
            };

            _context.Candidates.Add(candidate);
            _context.SaveChanges();
        }

        private void CreateEmployer()
        {
            string email = GetTextValue("Email");

            if (_context.Users.Any(u => u.Email == email))
                throw new Exception("Пользователь с таким email уже существует!");

            var user = new User
            {
                Email = email,
                Phone = GetTextValue("Phone"),
                PasswordHash = GetPasswordValue("Password"),
                RoleID = 3,
                IsActive = true,
                RegistrationDate = DateTime.Now
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            var employer = new Employer
            {
                EmployerID = user.UserID,
                CompanyName = GetTextValue("CompanyName"),
                INN = GetTextValue("INN"),
                ContactPerson = GetTextValue("ContactPerson"),
                Industry = GetTextValue("Industry"),
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now
            };

            _context.Employers.Add(employer);
            _context.SaveChanges();
        }

        private void CreateVacancy()
        {
            int employerId = GetEmployerComboValue("Employer");

            var vacancy = new Vacancy
            {
                EmployerID = employerId,
                Position = GetTextValue("Position"),
                SalaryFrom = ParseDecimal(GetTextValue("SalaryFrom")),
                SalaryTo = ParseDecimal(GetTextValue("SalaryTo")),
                City = GetTextValue("City"),
                Description = GetTextValue("Description"),
                Requirements = GetTextValue("Requirements"),
                IsActive = GetCheckValue("IsActive"),
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now
            };

            _context.Vacancies.Add(vacancy);
            _context.SaveChanges();
        }

        private void CreateCommission()
        {
            var successfulResponses = _context.CandidateResponses
                .Where(r => r.Status == "Принят на работу")
                .Select(r => new { r.ResponseID, r.CandidateID, r.VacancyID, r.Vacancy.EmployerID })
                .ToList();

            if (!successfulResponses.Any())
                throw new Exception("Нет успешных трудоустройств для создания комиссии!");

            var response = successfulResponses.First();

            decimal annualSalary = ParseDecimal(GetTextValue("AnnualSalary")) ?? 0;
            decimal percent = ParseDecimal(GetTextValue("CommissionPercent")) ?? 15;

            if (percent == 0)
            {
                var settings = _context.CommissionSettings.FirstOrDefault(s => s.IsActive == true);
                if (settings != null)
                    percent = settings.CommissionPercent;
                else
                    percent = 15;
            }

            var activeSettings = _context.CommissionSettings.FirstOrDefault(s => s.IsActive == true);
            if (activeSettings != null)
            {
                if (activeSettings.MinCommission.HasValue && percent < activeSettings.MinCommission.Value)
                    percent = activeSettings.MinCommission.Value;
                if (activeSettings.MaxCommission.HasValue && percent > activeSettings.MaxCommission.Value)
                    percent = activeSettings.MaxCommission.Value;
            }

            decimal commissionAmount = annualSalary * (percent / 100);

            var commission = new CommissionHistory
            {
                ResponseID = response.ResponseID,
                CandidateID = response.CandidateID,
                EmployerID = response.EmployerID,
                VacancyID = response.VacancyID,
                AnnualSalary = annualSalary,
                CommissionPercent = percent,
                CommissionAmount = commissionAmount,
                PaymentStatus = GetComboValue("PaymentStatus"),
                PaymentDate = string.IsNullOrEmpty(GetTextValue("PaymentDate"))
                    ? (DateTime?)null
                    : DateTime.Parse(GetTextValue("PaymentDate")),
                InvoiceNumber = GetTextValue("InvoiceNumber"),
                Notes = GetTextValue("Notes"),
                CreatedDate = DateTime.Now
            };

            _context.CommissionHistories.Add(commission);
            _context.SaveChanges();
        }

        // Методы обновления записей
        private void UpdateUser(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null) throw new Exception("Пользователь не найден!");

            string newEmail = GetTextValue("Email");

            if (newEmail != user.Email && _context.Users.Any(u => u.Email == newEmail))
                throw new Exception("Email уже используется другим пользователем!");

            user.Email = newEmail;
            user.Phone = GetTextValue("Phone");

            string newPassword = GetPasswordValue("Password");
            if (!string.IsNullOrWhiteSpace(newPassword))
            {
                user.PasswordHash = newPassword;
            }

            string roleName = GetComboValue("Role");
            var role = _context.Roles.FirstOrDefault(r => r.RoleName == roleName);
            if (role != null)
                user.RoleID = role.RoleID;

            user.IsActive = GetCheckValue("IsActive");

            _context.SaveChanges();
        }

        private void UpdateCandidate(int id)
        {
            var candidate = _context.Candidates.Find(id);
            if (candidate == null) throw new Exception("Соискатель не найден!");

            candidate.FullName = GetTextValue("FullName");
            candidate.Profession = GetTextValue("Profession");
            candidate.ExperienceYears = ParseInt(GetTextValue("Experience"));
            candidate.Education = GetTextValue("Education");
            candidate.UpdatedDate = DateTime.Now;

            _context.SaveChanges();
        }

        private void UpdateEmployer(int id)
        {
            var employer = _context.Employers.Find(id);
            if (employer == null) throw new Exception("Работодатель не найден!");

            employer.CompanyName = GetTextValue("CompanyName");
            employer.INN = GetTextValue("INN");
            employer.ContactPerson = GetTextValue("ContactPerson");
            employer.Industry = GetTextValue("Industry");
            employer.UpdatedDate = DateTime.Now;

            _context.SaveChanges();
        }

        private void UpdateVacancy(int id)
        {
            var vacancy = _context.Vacancies.Find(id);
            if (vacancy == null) throw new Exception("Вакансия не найдена!");

            vacancy.EmployerID = GetEmployerComboValue("Employer");
            vacancy.Position = GetTextValue("Position");
            vacancy.SalaryFrom = ParseDecimal(GetTextValue("SalaryFrom"));
            vacancy.SalaryTo = ParseDecimal(GetTextValue("SalaryTo"));
            vacancy.City = GetTextValue("City");
            vacancy.Description = GetTextValue("Description");
            vacancy.Requirements = GetTextValue("Requirements");
            vacancy.IsActive = GetCheckValue("IsActive");
            vacancy.UpdatedDate = DateTime.Now;

            _context.SaveChanges();
        }

        private void UpdateResume(int id)
        {
            var resume = _context.Resumes.Find(id);
            if (resume == null) throw new Exception("Резюме не найдено!");

            resume.Title = GetTextValue("Title");
            resume.SalaryExpectation = ParseDecimal(GetTextValue("Salary"));
            resume.Status = GetComboValue("Status");
            resume.IsVisible = GetCheckValue("IsVisible");
            resume.UpdatedDate = DateTime.Now;

            _context.SaveChanges();
        }

        private void UpdateResponse(int id)
        {
            var response = _context.CandidateResponses.Find(id);
            if (response == null) throw new Exception("Отклик не найден!");

            response.Status = GetComboValue("Status");


            string comment = GetTextValue("Comment");
            response.EmployerComment = string.IsNullOrWhiteSpace(comment) ? null : comment;

            _context.SaveChanges();
        }

        private void UpdateCommission(int id)
        {
            var commission = _context.CommissionHistories.Find(id);
            if (commission == null) throw new Exception("Запись комиссии не найдена!");

            decimal annualSalary = ParseDecimal(GetTextValue("AnnualSalary")) ?? commission.AnnualSalary;
            decimal percent = ParseDecimal(GetTextValue("CommissionPercent")) ?? commission.CommissionPercent;

            commission.AnnualSalary = annualSalary;
            commission.CommissionPercent = percent;
            commission.CommissionAmount = annualSalary * (percent / 100);
            commission.PaymentStatus = GetComboValue("PaymentStatus");

            string paymentDateStr = GetTextValue("PaymentDate");
            commission.PaymentDate = string.IsNullOrEmpty(paymentDateStr)
                ? (DateTime?)null
                : DateTime.Parse(paymentDateStr);

            commission.InvoiceNumber = GetTextValue("InvoiceNumber");
            commission.Notes = GetTextValue("Notes");
            commission.UpdatedDate = DateTime.Now;

            _context.SaveChanges();
        }

        // Вспомогательные методы получения значений из формы
        private string GetTextValue(string fieldName)
        {
            if (_textBoxes.ContainsKey(fieldName))
                return _textBoxes[fieldName].Text ?? "";
            return "";
        }

        private string GetPasswordValue(string fieldName)
        {
            if (_passwordBoxes.ContainsKey(fieldName))
                return _passwordBoxes[fieldName].Password ?? "";
            return "";
        }

        private string GetComboValue(string fieldName)
        {
            if (_comboBoxes.ContainsKey(fieldName))
                return _comboBoxes[fieldName].SelectedItem?.ToString() ?? "";
            return "";
        }

        private int GetEmployerComboValue(string fieldName)
        {
            if (_comboBoxes.ContainsKey(fieldName) && _comboBoxes[fieldName].SelectedItem != null)
            {
                dynamic item = _comboBoxes[fieldName].SelectedItem;
                return item.Id;
            }
            return 0;
        }

        private bool GetCheckValue(string fieldName)
        {
            if (_checkBoxes.ContainsKey(fieldName))
                return _checkBoxes[fieldName].IsChecked == true;
            return false;
        }

        private int? ParseInt(string value)
        {
            int result;
            if (int.TryParse(value, out result))
                return result;
            return null;
        }

        private decimal? ParseDecimal(string value)
        {
            decimal result;
            if (decimal.TryParse(value, out result))
                return result;
            return null;
        }

        // Удаление
        private void ConfirmDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                switch (_currentSection)
                {
                    case "Users":
                        var user = _context.Users.Find(_deleteItemId);
                        if (user != null)
                        {
                            // Удаляем связанную запись из Admins если есть
                            var admin = _context.Admins.FirstOrDefault(a => a.AdminID == user.UserID);
                            if (admin != null) _context.Admins.Remove(admin);
                            // Удаляем связанную запись из Candidates если есть
                            var candidate = _context.Candidates.FirstOrDefault(c => c.CandidateID == user.UserID);
                            if (candidate != null)
                            {
                                // Удаляем резюме кандидата
                                var resumes = _context.Resumes.Where(r => r.CandidateID == candidate.CandidateID).ToList();
                                foreach (var r in resumes)
                                {
                                    var candResponses = _context.CandidateResponses.Where(cr => cr.ResumeID == r.ResumeID).ToList();
                                    _context.CandidateResponses.RemoveRange(candResponses);
                                    var empResponses = _context.EmployerResponses.Where(er => er.ResumeID == r.ResumeID).ToList();
                                    _context.EmployerResponses.RemoveRange(empResponses);
                                }
                                _context.Resumes.RemoveRange(resumes);
                                // Удаляем отклики кандидата
                                var candResps = _context.CandidateResponses.Where(cr => cr.CandidateID == candidate.CandidateID).ToList();
                                _context.CandidateResponses.RemoveRange(candResps);
                                var empResps = _context.EmployerResponses.Where(er => er.CandidateID == candidate.CandidateID).ToList();
                                _context.EmployerResponses.RemoveRange(empResps);
                                // Удаляем комиссии кандидата
                                var commissions = _context.CommissionHistories.Where(ch => ch.CandidateID == candidate.CandidateID).ToList();
                                _context.CommissionHistories.RemoveRange(commissions);
                                _context.Candidates.Remove(candidate);
                            }
                            // Удаляем связанную запись из Employers если есть
                            var employer = _context.Employers.FirstOrDefault(emp => emp.EmployerID == user.UserID);
                            if (employer != null)
                            {
                                // Удаляем вакансии работодателя
                                var vacancies = _context.Vacancies.Where(v => v.EmployerID == employer.EmployerID).ToList();
                                foreach (var v in vacancies)
                                {
                                    var candRespsV = _context.CandidateResponses.Where(cr => cr.VacancyID == v.VacancyID).ToList();
                                    _context.CandidateResponses.RemoveRange(candRespsV);
                                    var empRespsV = _context.EmployerResponses.Where(er => er.VacancyID == v.VacancyID).ToList();
                                    _context.EmployerResponses.RemoveRange(empRespsV);
                                    var commsV = _context.CommissionHistories.Where(ch => ch.VacancyID == v.VacancyID).ToList();
                                    _context.CommissionHistories.RemoveRange(commsV);
                                }
                                _context.Vacancies.RemoveRange(vacancies);
                                // Удаляем отклики работодателя
                                var empRespsE = _context.EmployerResponses.Where(er => er.EmployerID == employer.EmployerID).ToList();
                                _context.EmployerResponses.RemoveRange(empRespsE);
                                // Удаляем комиссии работодателя
                                var commsE = _context.CommissionHistories.Where(ch => ch.EmployerID == employer.EmployerID).ToList();
                                _context.CommissionHistories.RemoveRange(commsE);
                                _context.Employers.Remove(employer);
                            }
                            _context.Users.Remove(user);
                        }
                        break;
                    case "Candidates":
                        var candDel = _context.Candidates.Find(_deleteItemId);
                        if (candDel != null)
                        {
                            // Удаляем резюме
                            var resumesDel = _context.Resumes.Where(r => r.CandidateID == candDel.CandidateID).ToList();
                            foreach (var r in resumesDel)
                            {
                                var candRespsR = _context.CandidateResponses.Where(cr => cr.ResumeID == r.ResumeID).ToList();
                                _context.CandidateResponses.RemoveRange(candRespsR);
                                var empRespsR = _context.EmployerResponses.Where(er => er.ResumeID == r.ResumeID).ToList();
                                _context.EmployerResponses.RemoveRange(empRespsR);
                            }
                            _context.Resumes.RemoveRange(resumesDel);
                            // Удаляем отклики
                            var candRespsDel = _context.CandidateResponses.Where(cr => cr.CandidateID == candDel.CandidateID).ToList();
                            _context.CandidateResponses.RemoveRange(candRespsDel);
                            var empRespsDel = _context.EmployerResponses.Where(er => er.CandidateID == candDel.CandidateID).ToList();
                            _context.EmployerResponses.RemoveRange(empRespsDel);
                            // Удаляем комиссии
                            var commsDel = _context.CommissionHistories.Where(ch => ch.CandidateID == candDel.CandidateID).ToList();
                            _context.CommissionHistories.RemoveRange(commsDel);
                            _context.Candidates.Remove(candDel);
                        }
                        break;
                    case "Employers":
                        var empDel = _context.Employers.Find(_deleteItemId);
                        if (empDel != null)
                        {
                            // Удаляем вакансии
                            var vacsDel = _context.Vacancies.Where(v => v.EmployerID == empDel.EmployerID).ToList();
                            foreach (var v in vacsDel)
                            {
                                var candRespsV = _context.CandidateResponses.Where(cr => cr.VacancyID == v.VacancyID).ToList();
                                _context.CandidateResponses.RemoveRange(candRespsV);
                                var empRespsV = _context.EmployerResponses.Where(er => er.VacancyID == v.VacancyID).ToList();
                                _context.EmployerResponses.RemoveRange(empRespsV);
                                var commsV = _context.CommissionHistories.Where(ch => ch.VacancyID == v.VacancyID).ToList();
                                _context.CommissionHistories.RemoveRange(commsV);
                            }
                            _context.Vacancies.RemoveRange(vacsDel);
                            // Удаляем отклики работодателя
                            var empRespsEDel = _context.EmployerResponses.Where(er => er.EmployerID == empDel.EmployerID).ToList();
                            _context.EmployerResponses.RemoveRange(empRespsEDel);
                            // Удаляем комиссии работодателя
                            var commsEDel = _context.CommissionHistories.Where(ch => ch.EmployerID == empDel.EmployerID).ToList();
                            _context.CommissionHistories.RemoveRange(commsEDel);
                            _context.Employers.Remove(empDel);
                        }
                        break;
                    case "Vacancies":
                        var vacDel = _context.Vacancies.Find(_deleteItemId);
                        if (vacDel != null)
                        {
                            // Удаляем отклики на вакансию
                            var candRespsVac = _context.CandidateResponses.Where(cr => cr.VacancyID == vacDel.VacancyID).ToList();
                            _context.CandidateResponses.RemoveRange(candRespsVac);
                            var empRespsVac = _context.EmployerResponses.Where(er => er.VacancyID == vacDel.VacancyID).ToList();
                            _context.EmployerResponses.RemoveRange(empRespsVac);
                            // Удаляем комиссии по вакансии
                            var commsVac = _context.CommissionHistories.Where(ch => ch.VacancyID == vacDel.VacancyID).ToList();
                            _context.CommissionHistories.RemoveRange(commsVac);
                            _context.Vacancies.Remove(vacDel);
                        }
                        break;
                    case "Resumes":
                        var resDel = _context.Resumes.Find(_deleteItemId);
                        if (resDel != null)
                        {
                            // Удаляем отклики с этим резюме
                            var candRespsRes = _context.CandidateResponses.Where(cr => cr.ResumeID == resDel.ResumeID).ToList();
                            _context.CandidateResponses.RemoveRange(candRespsRes);
                            var empRespsRes = _context.EmployerResponses.Where(er => er.ResumeID == resDel.ResumeID).ToList();
                            _context.EmployerResponses.RemoveRange(empRespsRes);
                            _context.Resumes.Remove(resDel);
                        }
                        break;
                    case "Responses":
                        var respDel = _context.CandidateResponses.Find(_deleteItemId);
                        if (respDel != null) _context.CandidateResponses.Remove(respDel);
                        break;
                    case "Commissions":
                        var commDel = _context.CommissionHistories.Find(_deleteItemId);
                        if (commDel != null) _context.CommissionHistories.Remove(commDel);
                        break;
                }
                _context.SaveChanges();
                HidePanels();
                LoadData();
                LoadStatistics();
                MessageBox.Show("Запись успешно удалена!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException dbEx)
            {
                string innerMsg = dbEx.InnerException?.Message ?? dbEx.Message;
                MessageBox.Show("Ошибка при удалении (внешние ключи): " + innerMsg, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при удалении: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void CancelDelete_Click(object sender, RoutedEventArgs e)
        {
            DeleteConfirmPanel.Visibility = Visibility.Collapsed;
            DataPanel.Visibility = Visibility.Visible;
            _deleteItemId = 0;
        }

        // Остальные обработчики
        private void CancelEdit_Click(object sender, RoutedEventArgs e)
        {
            SaveButton.Click -= ApplyCommissionFilters_Click;
            SaveButton.Click += SaveButton_Click;
            HidePanels();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
            LoadStatistics();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string search = SearchTextBox.Text.ToLower();
            if (string.IsNullOrWhiteSpace(search))
            {
                LoadData();
                return;
            }

            var allItems = AdminDataGrid.ItemsSource as List<DataCardViewModel>;
            if (allItems == null) return;

            var filteredList = allItems.Where(item =>
                item.Title.ToLower().Contains(search) ||
                item.Subtitle.ToLower().Contains(search) ||
                item.Info1.ToLower().Contains(search) ||
                item.Info2.ToLower().Contains(search) ||
                item.Description.ToLower().Contains(search)
            ).ToList();

            AdminDataGrid.ItemsSource = filteredList;
            PageSubtitle.Text = $"Найдено: {filteredList.Count}";
        }

        // ═══════════════════════════════════════════════════════════════
        // ОБНОВЛЁННАЯ СТАТИСТИКА С ФИНАНСАМИ
        // ═══════════════════════════════════════════════════════════════
        private void StatisticsButton_Click(object sender, RoutedEventArgs e)
        {
            LoadStatistics();

            var totalPaid = _context.CommissionHistories
                .Where(c => c.PaymentStatus == "Оплачено")
                .Sum(c => (decimal?)c.CommissionAmount) ?? 0;

            var pendingCommission = _context.CommissionHistories
                .Where(c => c.PaymentStatus == "Ожидает оплаты")
                .Sum(c => (decimal?)c.CommissionAmount) ?? 0;

            var totalCommission = _context.CommissionHistories
                .Sum(c => (decimal?)c.CommissionAmount) ?? 0;

            var sb = new StringBuilder();
            sb.AppendLine("📊 СТАТИСТИКА СИСТЕМЫ");
            sb.AppendLine();
            sb.AppendLine(string.Format("👤 Всего пользователей: {0}", _context.Users.Count()));
            sb.AppendLine(string.Format("   Администраторов: {0}", _context.Users.Count(u => u.RoleID == 1)));
            sb.AppendLine(string.Format("   Соискателей: {0}", _context.Users.Count(u => u.RoleID == 2)));
            sb.AppendLine(string.Format("   Работодателей: {0}", _context.Users.Count(u => u.RoleID == 3)));
            sb.AppendLine();
            sb.AppendLine(string.Format("🎓 Соискателей: {0}", _context.Candidates.Count()));
            sb.AppendLine(string.Format("🏢 Компаний: {0}", _context.Employers.Count()));
            sb.AppendLine(string.Format("📋 Вакансий: {0} (активных: {1})",
                _context.Vacancies.Count(),
                _context.Vacancies.Count(v => v.IsActive == true)));
            sb.AppendLine(string.Format("📄 Резюме: {0}", _context.Resumes.Count()));
            sb.AppendLine(string.Format("📨 Откликов: {0}", _context.CandidateResponses.Count()));
            sb.AppendLine();
            sb.AppendLine("💰 ФИНАНСОВАЯ СТАТИСТИКА:");
            sb.AppendLine(string.Format("   Всего комиссий: {0}", _context.CommissionHistories.Count()));
            sb.AppendLine(string.Format("   Оплачено: {0:N0} ₽", totalPaid));
            sb.AppendLine(string.Format("   Ожидает оплаты: {0:N0} ₽", pendingCommission));
            sb.AppendLine(string.Format("   Общий доход агентства: {0:N0} ₽", totalCommission));
            sb.AppendLine();
            sb.AppendLine(string.Format("   Средний чек: {0:N0} ₽",
                _context.CommissionHistories.Any() ? _context.CommissionHistories.Average(c => c.CommissionAmount) : 0));

            MessageBox.Show(sb.ToString(), "Статистика", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                App.Current.Properties["CurrentUser"] = null;
                Manager.MainFrame.Navigate(new LoginPage());
            }
        }
    }
}
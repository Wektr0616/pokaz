﻿using Buro.JobSeeker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buro.Employer
{
    /// <summary>
    /// Логика взаимодействия для EmployerDashboard.xaml
    /// </summary>
    public partial class EmployerDashboard : Page
    {
        private MainWindow _mainWindow;

        public EmployerDashboard(MainWindow mainWindow, string companyName)
        {
            InitializeComponent();
            _mainWindow = mainWindow;

            // Устанавливаем название компании
            CompanyNameText.Text = companyName;

            // Загружаем первую страницу по умолчанию
            LoadProfilePage();
        }

        private void LoadProfilePage()
        {
            ContentFrame.Navigate(new EmployerProfilePage());
        }

        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new EmployerProfilePage());
        }

        private void MyVacanciesButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new MyVacanciesPage());
        }

        private void CreateVacancyButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new CreateVacancyPage());
        }

        private void SearchCandidatesButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new SearchCandidatesPage());
        }

        private void ResponsesButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new CandidateResponsesPage());
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            // Возврат на главную страницу
            _mainWindow.NavigateToMainPage();
        }
    }
}

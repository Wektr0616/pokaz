﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Buro.Employer;
using Buro.JobSeeker;
using System.Windows.Navigation;


namespace Buro.JobSeeker
{
    /// <summary>
    /// Логика взаимодействия для JobSeekerDashboard.xaml
    /// </summary>
    public partial class JobSeekerDashboard : Page
    {
        private MainWindow _mainWindow;

        public JobSeekerDashboard(MainWindow mainWindow, string userName)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            
            // Устанавливаем имя пользователя
            UserNameText.Text = userName;
            
            // Инициализация навигации
            InitializeNavigation();
        }

        private void InitializeNavigation()
        {
            // Подписываемся на события навигации
            ContentFrame.Navigated += ContentFrame_Navigated;
            
            // Загружаем первую страницу по умолчанию
            LoadProfilePage();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            // Дополнительная инициализация при загрузке страницы
            UpdateStatistics();
        }

        private void UpdateStatistics()
        {
            // Здесь можно обновить статистику из базы данных
            // Временные данные для примера
            // В реальном приложении здесь будет загрузка статистики из БД
        }

        private void LoadProfilePage()
        {
            ContentFrame.Navigate(new JobSeekerProfilePage());
        }

        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new JobSeekerProfilePage());
        }

        private void VacanciesButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new VacanciesPage());
        }

        private void MyResumeButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new MyResumePage());
        }

        private void ResponsesButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new EmployerResponsesPage());
        }

        private void ApplicationsButton_Click(object sender, RoutedEventArgs e)
        {
            ContentFrame.Navigate(new MyApplicationsPage());
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            // Подтверждение выхода
            var result = MessageBox.Show("Вы уверены, что хотите выйти?", 
                                       "Выход из системы", 
                                       MessageBoxButton.YesNo, 
                                       MessageBoxImage.Question);
            
            if (result == MessageBoxResult.Yes)
            {
                // Возврат на главную страницу
                _mainWindow.NavigateToMainPage();
            }
        }

        // Обработчик события навигации Frame
        private void ContentFrame_Navigated(object sender, NavigationEventArgs e)
        {
            // Можно добавить логику при навигации, например:
            // - Обновление заголовка
            // - Обновление состояния кнопок меню
            // - Логирование навигации
            
            UpdateActiveButtonState(e.Content);
        }

        private void UpdateActiveButtonState(object content)
        {
            // Сбрасываем все кнопки
            ResetMenuButtons();

            // Определяем, какая страница активна и подсвечиваем соответствующую кнопку
            if (content is JobSeekerProfilePage)
            {
                SetButtonActive(ProfileButton);
            }
            else if (content is VacanciesPage)
            {
                SetButtonActive(VacanciesButton);
            }
            else if (content is MyResumePage)
            {
                SetButtonActive(MyResumeButton);
            }
            else if (content is EmployerResponsesPage)
            {
                SetButtonActive(ResponsesButton);
            }
            else if (content is MyApplicationsPage)
            {
                SetButtonActive(ApplicationsButton);
            }
        }

        private void ResetMenuButtons()
        {
            // Сбрасываем стили всех кнопок меню к стандартным
            var buttons = new[] { ProfileButton, VacanciesButton, MyResumeButton, 
                                ResponsesButton, ApplicationsButton };

            foreach (var button in buttons)
            {
                if (button != null)
                {
                    // Возвращаем стандартные цвета
                    button.Background = System.Windows.Media.Brushes.Transparent;
                    button.Foreground = System.Windows.Media.Brushes.LightGray;
                }
            }
        }

        private void SetButtonActive(Button button)
        {
            if (button != null)
            {
                // Устанавливаем активные цвета
                button.Background = new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromRgb(45, 45, 45)); // Темно-серый
                button.Foreground = System.Windows.Media.Brushes.White;
            }
        }

        // Метод для обновления имени пользователя (если нужно изменить)
        public void UpdateUserName(string newName)
        {
            UserNameText.Text = newName;
        }

        // Метод для обновления статистики
        public void UpdateStatistics(int applicationsSent, int invitationsReceived)
        {
            // Здесь можно обновить текст статистики
            // Например, если бы у нас были TextBlock'и для статистики:
            // ApplicationsCountText.Text = $"Откликов отправлено: {applicationsSent}";
            // InvitationsCountText.Text = $"Приглашений: {invitationsReceived}";
        }
    }
}